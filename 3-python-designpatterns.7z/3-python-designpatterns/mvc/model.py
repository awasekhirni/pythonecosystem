import json 

class Product(object):
    def __init__(self,product_id,product_name,product_desc,product_price):
        self.product_id=product_id 
        self.product_name=product_name
        self.product_desc=product_desc
        self.product_price=product_price

    def productDetails(self):
        return ("%s %s %s %s" % (self.product_id,self.product_name, self.product_desc, self.product_price))

    
    @classmethod 
    #returns a list of all products as a list 
    def getAllrecords(self):
        database=open("db.txt","r")
        result=[]
        json_list=json.loads(database.read())
        for item in json_list:
            item =json.loads(item)
            product=Product(item['product_id'],item['product_name'],item['product_desc'],item['product_price'])
            result.append(product)
        return result

    