"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#MVC design pattern 

class Model:
    def db_data(self):
        data = 'Model Data'
        return data 
    

class View:
    def render(self,data):
        print('Rendering model on view:',data)


class Controller:
    def __init__(self):
        self.mymodel=Model()
        self.myview=View()
    

    def present(self):
        print('Controller, managing model and view')
        data = self.mymodel.db_data()
        self.myview.render(data)


mycontroller=Controller()
mycontroller.present()