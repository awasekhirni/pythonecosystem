from model import Product 
def showAllView(list):
    print("we have the following items in database:"%len(list))
    for item in list:
        print(item.productDetails())
    
def startView():
    print("MVC View ")

def endView():
    print("finished printing")

