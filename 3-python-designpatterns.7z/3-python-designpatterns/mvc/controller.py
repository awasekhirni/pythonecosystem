from model import Product 
import view 

def printAll():
    products_in_db=Product.getAllrecords()
    return view.showAllView(products_in_db)


def start():
    view.startView()
    printAll();


if __name__=="__main__":
    start()
    