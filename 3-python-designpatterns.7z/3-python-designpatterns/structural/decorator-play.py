"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#used to dynamically add a new feature to an object without changing its implementation
# it differs from inheritance becuase the new feature is added only to that particular object, not to the entire subclass 
#attach additional responsibilities to an object dynamically. 
# provide a flexible alternative to subclassing for extending functionality 
#client-specified embellishment of a core object by recursively wrapping it 

# would like to add behavior or state to individual objects at run-time. 
# inheritance is not feasible because it is static and is applied to an entire class

from __future__  import print_function 

class TextTag(object):
    def __init__(self,text):
        self._text=text 

    def render(self):
        return self._text 


class BoldWrapper(TextTag):
    def __init__(self,wrapped):
        self._wrapped=wrapped 

    def render(self):
        return "<b>{}</b>".format(self._wrapped.render())

class ItalicWrapper(TextTag):
    def __init__(self,wrapped):
        self._wrapped=wrapped 

    def render(self):
        return "<i>{}</i>".format(self._wrapped.render())


if __name__=='__main__':
    hello_fool=TextTag('Hello,You fool i love you')
    hello_jaanu=ItalicWrapper(BoldWrapper(hello_fool))
    print('before:',hello_fool.render())
    print('after:',hello_jaanu.render())


