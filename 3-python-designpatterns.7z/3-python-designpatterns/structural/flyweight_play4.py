import weakref 
import sys
class Card(object):
    _CardPool=weakref.WeakValueDictionary()

    def __new__(cls,value,suit):
        obj=Card._CardPool.get(value+suit,None)
        if not obj:
            obj=object.__new__(cls)
            Card._CardPool[value + suit]=obj 
            obj.value, obj.suit=value,suit 
        return obj 


def compute_object_size(obj,seen=None):
    """compute the object size in a recursive manner"""
    size=sys.getsizeof(obj)
    if seen is None:
        seen=set()
    obj_id=id(obj)
    if obj_id in seen:
        return 0 
    seen.add(obj_id)
    if isinstance(obj,dict):
        size+=sum([compute_object_size(v,seen) for v in obj.values()])
        size+=sum([compute_object_size(k,seen) for k in obj.keys()])
    elif hasattr(obj,'__dict__'):
        size+=compute_object_size(obj.__dict__,seen)
    elif hasattr(obj,'__iter__') and not isinstance(obj,(str,bytes,bytearray)):
        size+=sum([compute_object_size(i,seen) for i in obj])
    return size 


if __name__=="__main__":
    c1=Card("9","h")
    c2=Card("8","h")
    c3=Card("2","s")
    c4=Card("2","s")        

    print(c1==c2)
    print(c3==c4)
    print(compute_object_size(c1))
    print(compute_object_size(c2))




