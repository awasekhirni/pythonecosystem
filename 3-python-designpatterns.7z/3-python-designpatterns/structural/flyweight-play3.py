class Flyweight:
    def Operation(self,extrinsicState):
        raise NotImplementedError("Operation() must be defined in subclass")


class ConcreteFlyweight(Flyweight):
    def __init__(self,key):
        if(key=="flyweight1"):
            self.intrinsicState=101
        elif key=="flyweight2":
            self.intrinsicState=102
        elif key=="flyweight3":
            self.intrinsicState=103

    def Operation(self,extrinsicState):
        print("Inside ConcreteFlyweight:Operation()")
        print("Intrinsic State=%s, ExtrinsicState=%s"%(self.intrinsicState,extrinsicState))


class UnsharedConcreteFlyweight(Flyweight):
    def __init__(self,value):
        self.allState=value 

    def Operation(self,extrinsicState):
        print("Inside UnsharedConcreteFlyweight:Operation()")
        print("All State=%s, Extrinsic State=%s"%(self.allState,extrinsicState))


class FlyweightFactory:
    def __init__(self):
        self.flyweightPool={}

    def GetFlyweight(self,key):
        if self.flyweightPool.__contains__(key):
            print("flywieght from existing pool")
            return self.flyweightPool[key]
        else:
            obj=ConcreteFlyweight(key)
            self.flyweightPool[key]=obj 
            print("New Flyweight in pool")
            return obj 


if __name__=="__main__":
    fwfo=FlyweightFactory()
    fwf1=fwfo.GetFlyweight("flyweight1")
    fwf1.Operation(10)
    
