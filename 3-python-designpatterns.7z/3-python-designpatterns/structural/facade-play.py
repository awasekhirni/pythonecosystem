"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#facade design pattern 

#provide a unified interface to a set of interfaces in a sub system 
# it provides a higher-level interface that makes the subsystem easier to use 
#applicable to objects

# use 
#1.to provide a simple interface to a complex sub-system 
#2.when many dependencies exist between clients and the implementation classes of an abstraction 
#3. to add a layer to your subsystems, we use facabe to define an entry point to each subsystem level 

class _IgnitionSystem(object):
    @staticmethod 
    def produce_spark():
        return True

class _Engine(object):
    def __init__(self):
        self.revs_per_minute=0 
    
    def turnon(self):
        self.revs_per_minute=2000 

    def turnoff(self):
        self.revs_per_minute=0 

class _FuelTank(object):
    def __init__(self,level=30):
        self._level=level 

    @property
    def get_level(self):
        return self._level 

    
    def set_level(self,level):
        self._level=level 


class _DashboardLight(object):
    def __init__(self, is_on=False):
        self._is_on=is_on 

    def __str__(self):
        return self.__class__.__name__ 

   
    def get_is_on(self):
        return self._is_on
  
    def set_is_on(self,status):
        self._is_on=status

    def status_check(self):
        if self._is_on:
            print("{}: ON".format(str(self)))
        else:
            print("{}: OFF".format(str(self)))


class _HandbrakeLight(_DashboardLight):
    pass 


class _FoglampLight(_DashboardLight):
    pass 

class _Dashboard(object):
    def __init__(self):
        self.lights = {"handbreak": _HandbrakeLight(), "fog": _FoglampLight()}
    
    def show(self):
        for light in self.lights.values():
            light.status_check()


#Facade

class Car(object):
    def __init__(self):
        self.myignition_system=_IgnitionSystem()
        self.myengine=_Engine()
        self.myfuel_tank = _FuelTank()
        self.mydashboard=_Dashboard()

    @property 
    def km_per_litre(self):
        return 22.0 
    
    def consume_fuel(self,km):
        litres = min(self.myfuel_tank.get_level, km/self.km_per_litre)
        self.myfuel_tank.set_level(litres) 

    def start(self):
        print("\nStarting....")
        self.mydashboard.show()
        if self.myignition_system.produce_spark():
            self.myengine.turnon()
        else:
            print("can't start. faulty ignition system")
    

    def has_enough_fuel(self,km,km_per_litre):
        litres_needed= km/km_per_litre
        if self.myfuel_tank.get_level>litres_needed:
            return True 
        else:
            return False 

    def drive(self,km=100):
        if self.myengine.revs_per_minute>0:
            while self.has_enough_fuel(km,self.km_per_litre):
                self.consume_fuel(km)
                print("Drove {}km".format(km))
                print("{:2f}l of fuel still left".format(self.myfuel_tank.get_level))
            else:
                print("Cannot drive. the engine is turned off!!")
    
    def park(self):
        print("Lets park the vehicle safely ")
        self.mydashboard.lights["handbreak"].is_on=True 
        self.mydashboard.show()
        self.myengine.turnoff()

    
    def switch_fog_lights(self,status):
        print("Switching on for lights:{}".format(status))
        boolean=True if status=="ON" else False 
        self.mydashboard.lights["fog"].is_on=boolean 
        self.mydashboard.show()

    def fill_up_tank(self):
        print("This is a check for fuel tank level")
        self.myfuel_tank.level=100 


# the main function is the client 

def main():
    elantra= Car()
    elantra.start()
    elantra.drive()
    elantra.switch_fog_lights("ON")
    elantra.switch_fog_lights("OFF")
    elantra.park()
    elantra.fill_up_tank()
    
    elantra.start()
    elantra.drive()


if __name__=="__main__":
    main()

