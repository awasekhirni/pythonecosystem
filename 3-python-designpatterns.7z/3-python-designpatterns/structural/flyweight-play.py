"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#flyweight design pattern 

#applies to objects and uses sharing to support large numbers of fine-grained objects 
# used to reduce memory usage when you need to create a large number of similar objects 

#uses
#one instance of a class can be used to provide many virtual instances. 
#when all of the following are true 
#an application uses a large number of objects 
#storage costs are high because of the sheer quanity of objects
#most object state can be made extrinsic 
#many groups of objects may be replaced by relatively few shared objects once extrinsic state is removed 
# the application doesnot depend on object identity 

#Need to create large number of objects.

#Because of the large number when memory cost is a constraint.

#When most of the object attribute can be made external and shared.

#Its better when extrinsic state can be computed rather than stored.

#python new-style classes have a dictionary to store instance data. 
#new style classes support slots 

import weakref 
class CarModel:
    _models=weakref.WeakValueDictionary()

    def __new__(cls,model_name, *args, **kwargs):
        model = cls._models.get(model_name)
        if not model:
            model=super().__new__(cls)
            cls.__models[model_name]=model 
        return model 
    
    def __init__(self, model_name, air=False, tilt=False, cruise_control=False, power_locks=False, alloy_wheels=False, usb_charger=False):
        if not hasattr(self,"initted"):
            self.model_name=model_name
            self.air=air 
            self.tilt=tilt 
            self.cruise_control=cruise_control 
            self.power_locks=power_locks
            self.alloy_wheels = alloy_wheels 
            self.usb_charger = usb_charger 
            self.initted=True 

    def check_serial(self,serial_number):
        print(" this serial_no {0} on the {1} at this time".format(serial_number, self.model_name))




class Car:
    """constructor for car"""
    def __init__(self,model,color,serial):
        self.model=model 
        self.color=color 
        self.serial=serial 
    
    def check_serial(self):
        return self.model.check_serial(self.serial)



#client 

def main():
    dx=CarModel("FIT DX")
    lx=CarModel("FIT Lx", air=True, cruise_control=True, power_locks=True, tilt=True)
    elantra=Car(dx,"sky blue", "KA03MA0003")
    vento=Car(dx,'black', "AP02MA2373")
    rapid=Car(dx,"gold","KA04MA5373")



if __name__=="__main__":
    main()

