"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#Adapter Design Pattern 
#convert the interface of a class into another interface the client expects. 
# it lets classes work together that couldn't work otherwise, because of incompatible interfaces
#it allows to use a client with an incompatible interface by an adapter that does the conversion 

#Adapter can be applied on classed and also on object. 
#a class adapter uses multiple inheritance to adapt one interface to another 
#object adapter uses object composition to combine classes with different interfaces. 


#when to use 
# you want to use an existing class and its interface does not match with what you need 
# to create a reusable class that cooperates with classes that dont necessarily have compatible interfaces

class EuroSocketInterface:
    def voltage(self):
         pass 

    def live(self):
        pass

    def neutral(self):
        pass 

    def earth(self):
        pass 


#Adaptee 
class Socket(EuroSocketInterface):
    def voltage(self):
        return 230

    def live(self):
        return 1
    
    def neutral(self):
        return -1 
    
    def earth(self):
        return 0 


#Target Interface 
class USASocketInterface:
    def voltage(self):pass
    def live(self):pass 
    def neutral(self):pass 
    def earth(self):pass 
    
#the adapter 
class Adapter(USASocketInterface):
    __socket=None 
    def __init__(self,socket):
        self.socket=socket 
    
    def voltage(self):
        return 110
    
    def live(self):
        return self.__socket.live()

    def netural(self):
        return self.__socket.neutral()


#client 
class Microwave:
    __power=None 

    def __init__(self,power):
        self.__power=power 

    
    def cook(self):
        if self.__power.voltage()>110:
            print("its cooked")
        else:
            if self.__power.live==1 and self.__power.neutral()==-1:
                print("still needs to cook")
            else:
                print("No power")


def main():
    #plugin 
    mysocket=Socket()
    adapter=Adapter(mysocket)
    panasonic_oven=Microwave(adapter)

    #cooking 
    panasonic_oven.cook()

    return 0

if __name__=="___main__":
    main()


    
