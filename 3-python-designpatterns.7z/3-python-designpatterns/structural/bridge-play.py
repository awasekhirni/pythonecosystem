"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#decouple an abstraction from its implementation so that the two can vary independently. 
# it deals with the composition of objects 

# ACT AS A BRIDGE BETWEEN TWO CLASS HIERARCHIES 
# split a concept into two independent class hierarchies.  

## when to use 
# 1. avoid a permanent binding between an abstraction and its implementation 
#2. both the abstractions and their implementations should be extensible by subclassing 
#3.changes in the implementation of an abstraction should have no impact on clients 
# 4. hide the implementation of an abstraction completely from clients 

from abc import ABC, abstractmethod 

#Abstract interface used by the client 
class MobileApp(ABC):
    def __init__(self, implementation):
        #encapsulate an instance of a concrete implementation class 
        self._implementation = implementation 

    def __str__(self):
        return 'Interace:{};Implementation:{}'.format(
            self.__class__.__name__, self._implementation.__class__.__name__)


    @abstractmethod 
    def show_view(self):
        pass 



#concrete interface 1 
# FreeMobileApp 
class FreeMobileApp(MobileApp):
    def show_view(self):
        ads=self._implementation.get_ads()
        text=self._implementation.get_excerpt()
        call_to_action = self._implementation.get_call_to_action()
        print(ads)
        print(text)
        print(call_to_action)


class PaidMobileApp(MobileApp):
    def show_view(self):
        text=self._implementation.get_article()
        print(text)


#Abstract implementation decoupled from the client 
class Implementation (ABC):
    def get_excerpt(self):
        return 'excerpt from the article'

    def get_article(self):
        return "Full Article"

    def get_ads(self):
        return 'some ads'

    @abstractmethod 
    def get_call_to_action(self):
        pass 


#concrete implementation 
class ImplementationA(Implementation):
    def get_call_to_action(self):
        return "Pay 100USD per month to remove ads"


class ImplementationB(Implementation):
    def get_call_to_action(self):
        return "get paid 10USD for viewing ads!"


    



#client 
def main():
    freeapp=FreeMobileApp(ImplementationB())
    print(freeapp)
    freeapp.show_view()

    paidapp=PaidMobileApp(ImplementationA())
    print(paidapp)
    paidapp.show_view()




if __name__=="__main__":
    main()
