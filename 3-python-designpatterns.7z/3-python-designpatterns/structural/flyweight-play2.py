"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#flyweight design pattern 

#applies to objects and uses sharing to support large numbers of fine-grained objects 
# used to reduce memory usage when you need to create a large number of similar objects 

#uses
#one instance of a class can be used to provide many virtual instances. 
#when all of the following are true 
#an application uses a large number of objects 
#storage costs are high because of the sheer quanity of objects
#most object state can be made extrinsic 
#many groups of objects may be replaced by relatively few shared objects once extrinsic state is removed 
# the application doesnot depend on object identity 

from abc import ABC, abstractmethod 

#flyweight factory 
class Shape_Factory:
    color_map={}

    @staticmethod 
    def get_color(color):
        try:
            color_obj=Shape_Factory.color_map[color]
        except KeyError:
            color_obj=Color(color)
            Shape_Factory.color_map[color]=color_obj
            print("Creating Color:"+color)

        return color_obj



#flyweight 
class Shape(ABC):

    def __init__(self,color):
        self.color_obj=Shape_Factory.get_color(color)

    @abstractmethod 
    def draw(self):
        pass 

#shared flyweight 
class Color:
    color=''
    def __init__(self,color):
        self.color=color

    def __str__(self):
        return self.color 


#unshared concrete flyweight 
class Circle(Shape):
    def __init__(self,color,x,y,radius):
        super().__init__(color)
        self.x=x
        self.y=y
        self.radius=radius 

    def draw(self):
        print("Circle: \ncolor:", self.color_obj, "\nx:", self.x, "\ny:", self.y, "\nradius:", self.radius)



if __name__=="__main__":
    my_circles=[]

    circle = Circle("black", x=10, y=20, radius=30)
    circle.draw()
    my_circles.append(circle)

    circle = Circle("black", x=40, y=50, radius=60)
    circle.draw()
    my_circles.append(circle)
    print()

    circle = Circle("red", x=70, y=80, radius=90)
    circle.draw()
    my_circles.append(circle)

    print("\n\nMy circles:\n")
    for circle in my_circles:
        circle.draw()
        print()