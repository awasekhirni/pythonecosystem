"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#composite design pattern 
#composite objects into tree structures to represent part-whole hierarchies. 
#composite lets clients treat individual objects and compositions of objects uniformly 
#  

#when to use 
#1. you want to represent part-whole hierarchies of objects 
#2- clients are able to ignore the difference between compositions of objects and individual objects 
#3- need to build recursive tree data structures so that the elements of the tree can have sub-elements 
#4-helps to realize these hierarchical structures in a hassle-free manner 

class Graphic:
    def render(self):
        raise NotImplementedError("You should implement this:render")
    
    def removerFeature(self):
        raise NotImplementedError("You have not implemented this:removeFeature")

    def addfeature(self):
        raise NotImplementedError("You have not implemented: addFeature")



class Line(Graphic):
    def __init__(self,name):
        self.name=name 
    
    def render(self):
        print("Line:{}".format(self.name))


class Rectangle(Graphic):
    def __init__(self,name):
        self.name=name 

    def render(self):
        print("Rectangle:{}".format(self.name))


class Text(Graphic):
    def __init__(self,name):
        self.name=name 

    def render(self):
        print("Text:{}".format(self.name))


#composite  
class Picture(Graphic):
    def __init__(self):
        self.graphics=[]

    def render(self):
        for graphic in self.graphics:
            graphic.render()

    def addFeature(self,graphic):
        self.graphics.append(graphic)


    def removeFeature(self,graphic):
        self.graphics.remove(graphic)




if __name__=='__main__':
    line1=Line("straightline")
    rect1=Rectangle("border-rectangle")
    text1=Text("Hello,you fool i love you")

    picto=Picture()
    picto.addFeature(line1)
    picto.addFeature(rect1)
    picto.addFeature(text1)

    picto.render()