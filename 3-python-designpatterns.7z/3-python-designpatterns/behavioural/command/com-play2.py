#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.


from __future__ import print_function 
import os 
from os.path import lexists

class MoveFileCommand(object):
    def __init__(self,src,dest):
        self.src=src 
        self.dest=dest 

    def execute(self):
        self.rename(self.src,self.dest)

    
    def undo(self):
        self.rename(self.dest,self.src)

    
    def rename(self,src,dest):
        print(u"renaming %s to %s"%(src,dest))
        os.rename(src,dest)

    

def main():
    command_stack=[]

    command_stack.append(MoveFileCommand('sak-cv.doc','sak-resume.doc'))
    command_stack.append(MoveFileCommand('srk-cv.pdf','sak-cv.doc'))

    assert not lexists('sak-cv.doc')
    assert not lexists('sak-resume.doc')
    assert not lexists('srk-cv.doc')
    try:
        with open('sak-cv.doc','w'):
            pass 

        for cmd in command_stack:
            cmd.execute()

        
        for cmd in reversed(command_stack):
            cmd.undo()

    finally:
        os.unlink('sak-cv.doc')


if __name__=="__main__":
    main()

