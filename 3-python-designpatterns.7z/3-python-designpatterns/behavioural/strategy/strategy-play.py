#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.
#it defines a family of algorithms, encapsulates each one, and makes them interchangeable.
# it lets the algorithm vary independently from clients that use it. 

#usage 
# many related classes differ only in their behaviour 
# you need different variants of an algorithm 
# an algorithm uses data that clients shouldnt know about 

import abc 
from typing import Type 

class Order:
    pass 

class Strategy(metaclass=abc.ABCMeta):
    @abc.abstractmethod 
    def calculate(self,order:Order)->float:
        """calculates order's shipping cost"""
    

class FedExStrategy(Strategy):
    def calculate(self,order:Order)->float:
        return 3.00 


class PostalStrategy(Strategy):
    def calculate(self,order:Order)->float:
        return 5.00 


class UPSStrategy(Strategy):
    def calculate(self,order:Order)->float:
        return 4.00



class ChooseStrategy:
    @classmethod 
    def setup_class(cls)-> None:
        cls.order=Order()

    def _choice_strategy(self,cls:Type[Strategy],expected_cost:float)->None:
        strategy=cls()
        cost=ShippingCost(strategy)
        assert cost.shipping_cost(self.order)==expected_cost 

    def test_fed_ex_strategy(self)-> None:
        self._choice_strategy(FedExStrategy,3.00)
    

    def test_postal_strategy(self)->None:
        self._choice_strategy(PostalStrategy,5.00)

    def test_ups_strategy(self)->None:
        self._choice_strategy(UPSStrategy,4.00)

class ShippingCost:
    def __init__(self,strategy:Strategy)->None:
        self._strategy=strategy 

    
    def shipping_cost(self,order)->float:
        return self._strategy.calculate(order)


if __name__=="__main__":
   print("Strategy design pattern")