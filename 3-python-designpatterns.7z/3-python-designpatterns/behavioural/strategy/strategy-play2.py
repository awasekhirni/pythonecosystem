

#strategy design pattern demo 2 
import sys 

class Strategy:
    def algorithmInterface(self):
        pass 


class ServantLeadership(Strategy):
    def __init__(self):
        Strategy.__init__(self)

    def algorithmInterface(self):
        print("Servant Leadership Management Style")


class AuthoritarianNarcist(Strategy):
    def __init__(self):
        Strategy.__init__(self)

    def algorithmInterface(self):
        print("Grumpy Authoritarian Narcistic Management Style ")

    
class DemocraticLeadership(Strategy):
    def __init__(self):
        Strategy.__init__(self)

    def algorithmInterface(self):
        print("A leadership style that takes into the merits of various democratic opinions")


class Context:
    def __init__(self,strategy):
        self._strategy=strategy 

    def contextInterface(self):
        self._strategy.algorithmInterface()



if __name__=="__main__":
    electedRep=ServantLeadership()
    context=Context(electedRep)
    context.contextInterface()