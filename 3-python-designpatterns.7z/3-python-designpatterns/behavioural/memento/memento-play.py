#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.

#Memento Design pattern 
#without violating encapsulation, captures and externalizes an object's internal state so that the object can be restored to this state later

#usage 
#a snapshot of an object's state must be saved sot aht it can be restored to that state later 
#a direct interface to obtaining the state would expose implementation details and break the object's encapsulation

class Memento:
    def __init__(self,value):
        self.state=value 

    def setState(self,value):
        self.state=value 
    
    def getState(self):
        return self.state 
    

class Originator:
    def setState(self,value):
        self.state=value 
    
    def getState(self):
        return self.state 
    
    def createMemento(self):
        return (Memento(self.state))

    def setMemento(self,memento):
        print("Going to previous state")
        self.state=memento.getState()


class Caretaker:
    def __init__(self,originatorobj):
        self.memento=None 
        self.origin=originatorobj

    def execute(self):
        self.memento=self.origin.createMemento()
        self.origin.setState(0)

    def unexecute(self):
        self.origin.setMemento(self.memento)


if __name__=="__main__":
    orgi=Originator()
    orgi.setState(1)
    print(" the state value is: ", orgi.getState())

    ct=Caretaker(orgi)
    ct.execute()
    print("the state value is:", orgi.getState())
    ct.unexecute() 
    print(" the state value is:", orgi.getState())
