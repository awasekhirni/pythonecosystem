#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.

#state design pattern 

#the pattern allows an object to alter its behaviour when its internal state changes 
#the object will appear to change its class 

#usage 
# when an objects behaviour depends on its state and it must change its behaviour at run-time depending on that state 
# operations have large, multipart conditional statements that depend on the object' state 

#allow an object to alter its behaviour when its internal state changes. 
#The object will appear to change its class.

class EngineState(object):
    name="state"
    allowed=[]

    def switch(self,state):
        """Switch to a  new state"""
        if state.name in self.allowed:
            print("Current:",self,'=>switching to new state',state.name)
            self.__class__=state 
        else:
            print("Current:",self,'=>switchign to',state.name,'not possible')

    
    def __str__(self):
        return self.name 


class TurnedOff(EngineState):
    name="Engine_Turned_Off"
    allowed=["Ignition_On"]

class IngitionOn(EngineState):
    """State of being powered on and running"""
    name="Ignition_on"
    allowed=["Engine_Turned_Off","Parking","Towed"]

class Parking(EngineState):
    """Parking Mode"""
    name="Parking"
    allowed=["Ignition_On","Engine_Turned_Off"]

class Towed(EngineState):
    """Engine dead, garage repair"""
    name="Towed"
    allowed=["Engine_Turned_Off"]


class Truck(object):
    """A class representing truck object"""

    def __init__(self, model="VOLVO"):
        self.model=model 
        self.state=Parking()

    def changeMode(self,state):
        """Changing the state of the computer"""
        self.state.switch(state)



if __name__=="__main__":
    garuda=Truck()
    garuda.changeMode(IngitionOn)
    garuda.changeMode(Parking)
    garuda.changeMode(TurnedOff)
    garuda.changeMode(Towed)



