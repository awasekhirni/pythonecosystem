#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.

#mediator patten 

# it defines an object that encapsulates how a set of objects interact 
# it promotes loose coupling by keeping objects from referring to each other explicitly and lets you vary their interaction independently


# usage 
# a set of objects communicate in a well-defined but complex ways 
# reusing an object is diffcult because it refers to and communicates with many other objects 
# a behaviour thats distributed between several classes should be customizable without a lot of subclassing 

class ForeignColleague:
    def __init__(self,mediator,identity):
        self.mediator=mediator 
        self._id = identity

    def getID(self):
        return self._id 

    def send(self,message):
        pass 

    def receive(self,message):
        pass 

    

class SolidColleague(ForeignColleague):
    def __init__(self,mediator,identity):
        super().__init__(mediator,identity)


    def send(self,message):
        print("Message"+message+"sent by Colleague"+str(self._id))

    def receive(self,message):
        print("Message"+message+"received by Colleage"+str(self._id))



#mediator 
class Mediator:
    def add(self,colleague):
        pass 

    def distribute(self,sender,message):
        pass 

    
#implementation of mediator 
class SolidMediator(Mediator):
    def __init__(self):
        Mediator.__init__(self)
        self._members=[]

        def add(self,colleague):
            self._members.append(colleague)

        def distribute(self,sender,message):
            for member in self._members:
                if member.getID()!=sender.getID():
                    member.receive(message)



if __name__=="__main__":
    brkr=SolidMediator()

    indianClassmate=SolidColleague(ForeignColleague,1001)
    chineeseClassmate=SolidColleague(ForeignColleague,9991)

    brkr.add(indianClassmate)
    brkr.add(chineeseClassmate)
    
    indianClassmate.send("Namaste JI, kaise hain!")
    chineeseClassmate.send("Ni Hao! Saishe!!")
