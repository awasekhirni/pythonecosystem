#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.
#defines a representation for its grammar along with an interpreter that uses the representation to 
#interpet sentences in the language.

#usage 
#efficiency is not a critical concern
# when the grammar is simple 

class AbstractExpression:
    def interpret(self,context):
        raise NotImplementedError("Interpreter must be defined int he class")

class TerminalExpression(AbstractExpression):
    def interpret(self,context):
        print("Inside Terminal Expression:Interpret()")


class NonTerminalExpression(AbstractExpression):
    def interpret(self,context):
        print("inside non-terminal expression:interpret()")


class Context:
    def __init__(self,value):
        self.expression=value

    def setExpression(self,value):
        self.expression=value 

    def getExpression(self):
        return self.expression 


if __name__=="__main__":
    contextObject=Context("AAABABABABABAJSJDJE")
    expressionList=[]

    expressionList.append(NonTerminalExpression())
    expressionList.append(TerminalExpression())
    expressionList.append(TerminalExpression())

    for expr in expressionList:
        expr.interpret(contextObject)