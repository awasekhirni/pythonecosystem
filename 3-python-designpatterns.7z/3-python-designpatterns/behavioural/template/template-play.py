#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.

#Template method design pattern 

# it defines the skeleton of an algorithm in an operation, deferring some steps to subclasses 
# it lets subclasses redefine certain steps of an algorithm without changing the algorithm's structure. 

# it defines a basic algorithm in a base class using abstract operation where subclasses can override the concrete behaviour. 
# it keeps the outline of algorithm in a seperate method. 

#usage 
# to implement the invariant parts of an algorithm once and leave it up to subclasses to implement the behaviour that can vary 
# when common behaviour among subclasses should be factored and localized in a common class to avoid code duplication
# to control subclasses extensions 


class BuildEngine:
    def procureParts(self):pass 
    def assembleParts(self):pass 
    def testAssembly(self):pass 
    def prerunTest(self):pass 
    

    def testDrive(self):
        self.procureParts()
        self.assembleParts()
        self.testAssembly()
        self.prerunTest()



class BuildCarEngine(BuildEngine):
    def procureParts(self):
        print("Procure parts from OEM Car Part Manufacturers") 

    def assembleParts(self):
        print("Assemble Car Parts")
    
    def testAssembly(self):
        print("Test Car Engine Assembly")

    def prerunTest(self):
        print("pre-run car engine assembly testing")



class BuildTruckEngine(BuildEngine):
    def procureParts(self):
        print("Procure parts from OEM Truck Part Manufacturers") 

    def assembleParts(self):
        print("Assemble Truck Parts")
    
    def testAssembly(self):
        print("Test Truck Engine Assembly")

    def prerunTest(self):
        print("pre-run truck engine assembly testing")




class BuildAeroEngine(BuildEngine):
    def procureParts(self):
        print("Procure parts from OEM Aero Part Manufacturers") 

    def assembleParts(self):
        print("Assemble Aero Parts")
    
    def testAssembly(self):
        print("Test Aero Engine Assembly")

    def prerunTest(self):
        print("pre-run aero engine assembly testing")




if __name__=="__main__":
    bombardier=BuildAeroEngine()
    bombardier.testDrive() 

    elantra=BuildCarEngine()
    elantra.testDrive() 

    volvo=BuildTruckEngine()
    volvo.testDrive()

