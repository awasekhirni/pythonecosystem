#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.

class ContentFilter(object):
    def __init__(self,filters=None):
        self.filters=list()
        if filters is not None:
            self._filters +=filters 

    def filter(self,content):
        for filter in self._filters:
            content =filter(content)
        return content 
    

if __name__=="__main__":
    filter=ContentFilter([offensive_filter,ads_filter,porno_video_filter])
    filtered_content=filter.filter(content)
    