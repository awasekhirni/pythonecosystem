#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.
#chain of responsibility 

# it avoids coupling the send of a request to its receiver by giving more than one object 
# a chance to handle request. 
# it chains the receiving objects and passes the request along the chain until an object handles it. 
# deals with relationships between objects 

##when to use 
# more than one object may handle a request, and the handler should be ascertained automatically
# to issue a request to one of the several objects without specifying the receiver explicitly
# the set of objects that can handle a request should be specified dynamically.


# used to create a system  that can serve different requests in a hierarchical manner. 

# often used in the context of graphical user interfaces, where one widget may contain several other widgets. 

class Event:
    def __init__(self,name):
        self.name=name 


class Widget:
    def __init__(self,parent=None):
        self.__parent=parent 
    
    def Handle(self,event):
        handler='Handle_'+event.name 
        if hasattr(self,handler):
            method=getattr(self,handler)
            method(event)
        elif self.__parent:
            self.__parent.Handle(event)
        elif hasattr(self,'HandleDefault'):
            self.HandleDefault(event)


class MainWindow(Widget):
    def Handle_close(self,event):
        print('MainWindow:'+event.name)
    def HandleDefault(self,event):
        print("Default"+event.name)



class SendDialog(Widget):
    def Handle_paint(self,event):
        print("SendDialog"+event.name)


class MsgText(Widget):
    def Handle_down(self,event):
        print("MessageText"+event.name)



if __name__=="__main__":
    mw=MainWindow()
    sd=SendDialog(mw)
    msg=MsgText(sd)
    edown=Event("down event triggered ")
    msg.Handle(edown)
    eodd=Event("Odd Event Triggered")
    msg.Handle(eodd)


