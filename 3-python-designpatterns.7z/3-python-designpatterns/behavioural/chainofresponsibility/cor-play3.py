import sys

class Handler:
    def __init__(self):
        self._successor=None 
    
    def setHandler(self,successor):
        self._successor=successor 
    
    def handleRequest(self):
        if(self._successor is not None):
            self._successor.handleRequest()


class ConcreteHandler1(Handler):
    def __init__(self):
        Handler.__init__(self)
        self._can_handle=False 
    
    def handleRequest(self):
        if (self._can_handle):
            print("Handled by concrete handler 1")
        else:
            print("cannot be handled by handler 1")
            super().handleRequest()



class ConcreteHandler2(Handler):
    def __init__(self):
        Handler.__init__(self)
        self._can_handle=True
    
    def handleRequest(self):
        if(self._can_handle):
            print("Handled by concrete handler 2")
        else:
            print("cannot be handled by handler 2")
            super().handleRequest()



if __name__=="__main__":
    hdlr1=ConcreteHandler1()
    hdlr2=ConcreteHandler2()

    hdlr1.setHandler(hdlr2)
    hdlr1.handleRequest()

        