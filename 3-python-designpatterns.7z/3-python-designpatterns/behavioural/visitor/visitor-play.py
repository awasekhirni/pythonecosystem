#Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research I Pvt Ltd.

#visitor design pattern 

# it represents an operation to be performed on the elements of an object structure. 
# it lets you define a new operation without changing the classes of the elements on which it operates. 

#usage 
#1. an object structure contains many classes of objects with differing interfaces, and we wish to perform operation on these object that depend on their concrete classes. 
#2. many distinct and unrelated operations need to be performed on objects in an object structure, and we would like to avoid polluting their classes with these operations. 
#3. the classes defining the object structure rarely change, but you often want to define new operations over the structure. 

# assumption is that we have a primary class hierarchy that is fixed. from another user/vendor and we cannot make any changes to that hierarchy. 
# the intent is add new polymorphic methods to that hierarchy.

# allows us to create a separate class hierarchy of type visitor to virtualize the operations performed upon the primary type. 
# the objects of the primary type simply "accept" the visitor, then call the visitors dynamically bound member function 


from __future__ import generators 
import random

#the flower hierarchy cannot be changed

class Flower(object):
    def accept(self,visitor):
        visitor.visit(self)
    
    def pollinate(self,pollinator):
        print(self, "pollinated by", pollinator)

    def eat(self,eater):
        print(self,"eaten by",eater)

    def __str__(self):
        return self.__class__.__name__ 

    
class Gladiolus(Flower):pass 
class Runuculus(Flower):pass 
class Chrysanthemum(Flower):pass 

class Visitor:
    def __str__(self):
        return self.__class__.__name__


class Bug(Visitor):pass 
class Pollinator(Bug):pass 
class Predator(Bug):pass 

#ability to do "Bees" activities:
class Bee(Pollinator):
    def visit(self,flower):
        flower.pollinate(self)


#Add the ability to do "Fly activities "

class Fly(Pollinator):
    def visit(self,flower):
        flower.pollinate(self)


#add the ability to do "Worm" activites 
class Worm(Predator):
    def visit(self,flower):
        flower.eat(self)



def flowerGen(n):
    flwrs=Flower.__subclasses__()
    for i in range(n):
        yield random.choice(flwrs)()


def main():
    bee=Bee()
    fly=Fly()
    worm=Worm()
    for flower in flowerGen(10):
        flower.accept(bee)
        flower.accept(fly)
        flower.accept(worm)




if __name__=="__main__":
    main()