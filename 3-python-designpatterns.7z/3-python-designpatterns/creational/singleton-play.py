"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#Singleton Pattern 
# restricts the instantiation of a class to one object 
# ensure a class only has one instance and provide a global access to it. 
#often used as a part another design pattern facade and flyweight 

#when to use 
#- there must be exactly one instance of a class and it must be accessible to clients from a well-known access-point 
# when the sole instance should be extensible by subclassing and clients should be able to use an extended instance without modifying their code 

class Singleton(object):
    def __new__(cls):
        if not hasattr(cls,'instance'):
            cls.instance=super(Singleton,cls).__new__(cls)
        return cls.instance 
    
#create instance demo 
s1=Singleton()
print("My first object", s1)

s2=Singleton()
print("My Second Object",s2)


#example 2
import sqlite3 

class MetaSingleton(type):
    _instances={}

    def __call_(cls,*args,**kwargs):
        if cls not in cls._instances:
            cls._instances[cls]=super(MetaSingleton, cls).__call__(*args,**kwargs)
        return cls._instances[cls]

class Database(metaclass=MetaSingleton):
    connection = None
    def connect(self):
        if self.connection is None:
            self.connection = sqlite3.connect("db.sqllite3")
            self.cursorobj = self.connection.cursor()
        return self.cursorobj


db1 = Database().connect()
db2 = Database().connect()

print ("Connection db1", db1)
print ("Connection db2", db2)


#example lazy instantiation 

class LaxySingleton:
    __instance=None 
    def __init__(self):
        if not LaxySingleton.__instance:
            print("__init__method called")
        else:
            print("Instance already created",self.getInstance())

    
    @classmethod 
    def get_Instance(cls):
        if not cls.__instance:
            cls.__instance=LaxySingleton()
        return cls.__instance 


#class is initialized and object is not created yet
s=LaxySingleton()

print('object created:', Singleton.getInstance())

#instance already created
s1=LaxySingleton()