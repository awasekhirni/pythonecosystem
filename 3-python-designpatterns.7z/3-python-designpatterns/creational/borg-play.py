


#Monostate Pattern/Borg Pattern 
# A way to implement singleton behaviour, but instead of having only on instance of a class, there are multiple instances that share the same state. 
#focus is on sharing state instead of sharing instance identity 

#In python, instance attributes are stored in a attribute dictionary called __dict__. 
# each instance has its own dictionary, 
#borg pattern modifies this so that all instances have the same dictionary 

class Borg(object):
    __shared_state={}
    
    def __init_(self):
        self.__dict__=self.__shared_state
        self.state="Init"

    
    def __str__(self):
        return self.state 


class BenBorg(Borg):
    pass 



if __name__=="__main__":
    bb1=Borg()
    bb2=Borg()


    bb1.state="Idle"
    bb2.state="Running"

    print('bb1: {0}'.format(bb1))
    print('bb2: {0}'.format(bb2))

    

    print('bb1: {0}'.format(bb1))
    print('bb2: {0}'.format(bb2))

    print('bb1 id: {0}'.format(id(bb1)))
    print('bb2 id: {0}'.format(id(bb2)))

    bb3 = BenBorg()
    bb3.state = 'Stop'

    print('bb1: {0}'.format(bb1))
    print('bb2: {0}'.format(bb2))
    print('bb3: {0}'.format(bb3))  