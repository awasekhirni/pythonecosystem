"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#abstract factory pattern 

#---abstract shape classes -- 
class Shape2DInterface():
    def draw(self):
        pass 

class Shape3DInterface():
    def build(self):
        pass 
    
#concrete shape classes 
class Circle(Shape2DInterface):
    def draw(self):
        print("Cicle:Draw")

class Square(Shape2DInterface):
    def draw(self):
        print("Square:Draw")


class Sphere(Shape3DInterface):
    def build(self):
        print("Sphere:Build")


class Cube(Shape3DInterface):
    def build(self):
        print("Cube:Build")

#Abstract shape factory 
class ShapeFactoryInterface:
    def getShape(self):
        pass

##Abstract shape factory 
class Shape2DFactory(ShapeFactoryInterface):
    @staticmethod 
    def getShape(sides):
        if sides==1:
            return Circle()
        if sides==4:
            return Square()
        assert 0, " Bad 2D Shape creation: Shape not defined"+sides+"sides"


#Abstract shape factory 
class Shape3DFactory(ShapeFactoryInterface):
    @staticmethod 
    def getShape(sides):
        """Sides refer to faces in three dimension"""
        if sides==1:
            return Sphere()
        if sides ==6:
            return Cube()
        assert 0, "Bad 3D Shape creation: Shape not defined"+sides+"faces"



