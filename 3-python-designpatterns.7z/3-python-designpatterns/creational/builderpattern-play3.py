"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
import sys 

class EngineComposition:
    def __init__(self):
        self._engineBody=""
        self._engineFuelinjector=""
        self._enginePiston=""

    def makeEngineBody(self,enginebody):
        self._engineBody=enginebody 
    
    def makeFuelinjector(self,injector):
        self._engineFuelinjector=injector

    def makePiston(self,piston):
        self._enginePiston=piston 
    
    def getSpecification(self):
        return self._engineBody+" "+self._engineFuelinjector+" "+self._enginePiston 

#Building abstract interface for creating products 

class BuilderInterface:
    def __init__(self):
        self._product=EngineComposition()

    def getProductInfo(self):
        return self._product

    def buildEngine(self):
        pass 

    def buildInjector(self):
        pass 

    def buildPiston(self):
        pass

#Concrete Builders 
#create real products and stores them 
class CarEngineBuilder(BuilderInterface):
    def __init__(self):
        BuilderInterface.__init__(self)

    def buildEngine(self):
        self._product.makeEngineBody('vento')

    def buildInjector(self):
        self._product.makeFuelinjector('bosh fuel injector')

    def buildPiston(self):
        self._product.makePiston("4 pistons")


class TruckEngineBuilder(BuilderInterface):
    def __init__(self):
        BuilderInterface.__init__(self)

    def buildEngine(self):
        self._product.makeEngineBody('volvo')

    def buildInjector(self):
        self._product.makeFuelinjector('bosh fuel injector')

    def buildPiston(self):
        self._product.makePiston("8 pistons")
    

#director
#responsible for managing the correct sequence of object creation 
class Director:
    def __init__(self):
        self._builder=None 

    def setBuilder(self,builder):
        self._builder=builder 

    def getBuilder(self):
        return self._builder.getProductInfo()

    def construct(self):
        self._builder.buildEngine()
        self._builder.buildInjector()
        self._builder.buildPiston()
    

if __name__=="__main__":
    cex=CarEngineBuilder()
    tex=TruckEngineBuilder()

    dx=Director()
    dx.setBuilder(tex)
    dx.construct()

    vw=dx.getBuilder()
    print(vw.getSpecification())
  