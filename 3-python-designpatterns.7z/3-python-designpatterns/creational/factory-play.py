"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#Factory Pattern demo 
class ShapeInterface:
    def draw(self):
        pass 


class Circle(ShapeInterface):
    def draw(self):
        print("Draw a Cicle")

class Square(ShapeInterface):
    def draw(self):
        print("Draw a Square")

class Rectangle(ShapeInterface):
    def draw(self):
        print("Draw a Rectangle")


class ShapeFactory:
    @staticmethod 
    def getShape(type):
        if type=='circle':
            return Circle()
        if type=='square':
            return Square()
        assert 0, 'Could not find Shape'+type

#execution 
myshape=ShapeFactory()
newshapy=myshape.getShape('square')
print(newshapy)


#example 2 
class PlanInterface:
    def getRate(self):
        pass


class DomesticPlan(PlanInterface):
    def getRate(self):
        print("Domestic Plan rates are 50 USD")
    
class CommercialPlan(PlanInterface):
    def getRate(self):
        print("Commercial Plan rates are 100 USD")

class InstitutionalPlan(PlanInterface):
    def getRate(self):
        print("Institutional Plan rates are 250 USD")

class PlanFactory():
    @staticmethod 
    def getPlan(type):
        if(type=='domestic'):
            return DomesticPlan()
        if(type=='commercial'):
            return CommercialPlan()
        assert 0, 'Could not find Plan'+ type 

#execution 
myplan=PlanFactory()
nouvoplan=myplan.getPlan('domestic')
print(nouvoplan)


#example 3

class Animal(object):
    "Animal Base Class"
    def __init__(self,name="Animal", legs=0):
        self.name =name
        self.legs=legs 



class Lion(Animal):
    "Lion Class inheriting from Animal"

    def __init__(self,name,legs,type='carinvore'):
        Animal.__init__(self,name, legs)
        self.type=type 

    def roar(self):
        return "Lady gaga roars!!"



class Goat(Animal):
    "Goat class inheriting from Animal Class"
    def __init__(self,name,legs,type="herbivorous"):
        Animal.__init__(self,name,legs)
        self.type=type 

    def speak(self):
        return "Maeeh-Maeeh"


#create a get_animal factory to return different animal 
def get_animal(animal="lion"):
    animals=dict(lion=Lion("Lion",4,"carnivore"), goat=Goat("Goat", 4, "herbivore"))
    return animals[animal]


sherkhan=get_animal()
babasheep=get_animal("goat")
print(sherkhan.roar())
print(babasheep.speak())