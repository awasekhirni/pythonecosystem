
"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#builder pattern 
class Car:
    def __init__(self):
        self.__wheels=list()
        self.__engine=None 
        self.__body=None 
    
    

    def setBody(self,body):
        self.__body=body 
    
    def attachWheel(self,wheel):
        self.__wheels.append(wheel)

    def setEngine(self,engine):
        self.__engine=engine 

    def specification(self):
        print('body:%s'%self.__engine.horsepower)
        print('engine horsepower:%d'%self.__engine.horsepower)
        print('tire size:%d'% self.__wheels[0].size)

#class car parts 
class Wheel:
    size=None

class Engine:
    horsepower=None 

class Body:
    shape=None 

class Director:
    __builder=None 

    def setBuilder(self,builder):
        self.__builder=builder 

    def getCar(self):
        mycar=Car()
        

        #order of assembling the car 
        mybody=self.__builder.getBody()
        mycar.setBody(mybody)

        #fitting in the engine 
        myengine=self.__builder.getEngine()
        mycar.setEngine(myengine)

        #adding wheels 
        i=0
        while i<4:
            mywheel=self.__builder.getWheel()
            mycar.attachWheel(mywheel)
            i+=1
        return mycar 


#building interface 
class BuilderInterface:
    def getWheel(self):pass 
    def getEngine(self):pass 
    def getBody(self):pass 


class SedanBuilder(BuilderInterface):
    def getWheel(self):
        wheel=Wheel()
        wheel.size=19 
        return wheel 
    
    def getEngine(self):
        engine=Engine()
        engine.horsepower=250 
        return engine 

    def getBody(self):
        body=Body()
        body.shape="sedan"
        return body 


class TruckBuilder(BuilderInterface):
    def getWheel(self):
        wheel=Wheel()
        wheel.size=28
        return wheel 
    
    def getEngine(self):
        engine=Engine()
        engine.horsepower=500
        return engine 

    def getBody(self):
        body=Body()
        body.shape="Monster Truck"
        return body 

#Instantiation 

myd=Director()
myd.setBuilder(TruckBuilder)
myd.getCar()
myd.getCar().specification()

