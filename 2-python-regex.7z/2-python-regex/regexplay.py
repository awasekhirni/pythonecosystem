#program to check the validity of the password
# it should be minimum 10 alphanumeric characters 
#atleast 1 letter between [a-z] and 1 letter between [A-Z]
#atleast 1 character from [$#@]
#atleast 1 number 
#minimum length 10 characters
#maximum length 20 characters

#importing regular expression
import re
mypwd=input("please input my password")

status=True

while status:
    if(len(mypwd)<10 or len(mypwd)>20):
        break
    elif not re.search("[a-z]",mypwd):
        break
    elif not re.search("[A-Z]",mypwd):
        break
    elif not re.search("[0-9]",mypwd):
        break
    elif not re.search("[$#@]",mypwd):
        break
    elif not re.search("\s",mypwd):
        break
    else:
        print("Your password length is:", len(mypwd))
        print("Thank you for entering valid password")
        status=False 
        break 
if status:
    print("Not a Valid Password, please enter minimum 10 characters and maximum 20 characters")

    