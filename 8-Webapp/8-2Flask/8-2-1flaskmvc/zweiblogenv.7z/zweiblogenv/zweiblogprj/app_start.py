
#zweiblogprj start
import os 
from app_blogroutes import app 

if __name__=='__main__':
    app.debug=True 
    host=os.environ.get('IP', '127.0.0.1')
    #port to render 
    port = int(os.environ.get('PORT', 9090))
    app.run(host=host,port=port)

