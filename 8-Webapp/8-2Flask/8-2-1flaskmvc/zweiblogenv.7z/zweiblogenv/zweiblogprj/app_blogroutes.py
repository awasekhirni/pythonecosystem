
from flask import Flask,render_template_string, render_template 

app=Flask(__name__)

@app.route('/')
def indexView():
    return "Welcome to  SycliQ Blog"


@app.route('/bookreview')
def postView():
    book_name="Atlas Shrugged!"
    renderbook=""""
    <html>
        <h1> Insights into the {{book_name}} </h1>
    </html>
    
    """
    view_render=render_template_string(renderbook,book_name=book_name)
    return view_render



@app.route('/bookreviewlist')
def postListView():
    language_info="English"
    bookslist=""""
    <html>
    <h1>Please find enclosed here with Review of the books in {{language_info}} Literature</h1>
        <ol>
        {% for book in books  %}
        <li> {{book}}</li>
        {% endfor %}
        </ol>
    </html>
    
    """

    books=["Fountain Head","Atlas Shrugged","Killing the mocking Bird","Escape from Banana Republic","Killing the Fascist:Hitler"]

    books_print=render_template_string(bookslist,language_info=language_info, books=books) 

    return books_print



@app.route('/authorslist')
def authorListView():
    language_info="English"
    authors=["Ayn Rand","Syed Awase Khirni","Syed Ameese Sadath","Syed Rayyan Awais","Syed Shagufta Khan"]
    
    authors_view=render_template('authors_list.html', language_info=language_info, authors=authors)
    
    return authors_view


#dynamic routes
@app.route("/publisher/<string:name>/")
def getPublisherName(name):
    return name 


@app.route("/publisherinfo/<string:name>/<string:country>/")
def getPubliserInfo(name,country):
    return ("The Publisher :"+name+" "+ "is from "+country)


@app.route('/multi/<a>/<b>/<c>/')
def getMultiVariable(a,b,c):
    context={'a': 'alpha', 'o': 'omega', 'g': 'gamma'}
    return render_template('multivariable.html',context=context)

    