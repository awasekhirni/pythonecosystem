#importing the flask module in the project 
#WSGI Application
from flask import Flask

app=Flask(__name__)


@app.route('/')
def hello_world():
    return 'Welcome to TPRI/SYCLIQ Flask Demo Application EINSPROJECT by Dr. Awase Syed'



@app.route('/hello/<user>')
def hello_username(user):
    return 'Hello %s!' % user 


#htmlviewrendering 
@app.route('/pythonframeworks')
def display_frameworks():
    myviewrender="""
    <html>
        <h1>List of Python Framworks</h1>
        {framework_ol}
    </html>
    """ 

    frameworkslist=['Flask','Django','TurboGears','CherryPy','Web2Py','Pylons','Bottle','Quixote']

    render_framework="<ol>"
    render_framework +="\n".join([
        "<li>{framework}</li>".format(framework=framework) for framework in frameworkslist]
        )
    render_framework+="</ul>"
    print(frameworkslist)
    return myviewrender.format(framework_ol=render_framework)