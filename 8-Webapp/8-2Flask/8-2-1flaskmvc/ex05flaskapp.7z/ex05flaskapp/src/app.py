from flask import Flask, render_template,abort  
#import the db
from model import db 


#constructor 
app=Flask(__name__)
#index controller action method 
@app.route("/")
def index():
    return render_template('index.html')

#product list controller action method 
@app.route('/products')
def product_list():
    productlist=db
    return render_template("productlist.html",products=productlist)

#product detail controller action method
@app.route('/products/<int:index>')
def product_view(index):
    try:
        product=db[index]
        return render_template('productdetail.html',product=product)
    except IndexError:
        abort(404)
