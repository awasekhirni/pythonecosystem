import json 

def load_db():
    with open("data/ebayproducts.json") as b:
        return json.load(b)


db=load_db()