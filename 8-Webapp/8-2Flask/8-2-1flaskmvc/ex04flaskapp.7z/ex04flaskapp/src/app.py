from flask import Flask, render_template 
#import the db
from model import db 

#constructor for flask
app=Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/bookcard")
def book_view():
    booklist=db
    return render_template("booklist.html", books=booklist)

