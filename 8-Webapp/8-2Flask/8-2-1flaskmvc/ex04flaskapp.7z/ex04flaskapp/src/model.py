import json 

def load_db():
    with open("data/books.json") as b:
        return json.load(b)


db=load_db()