from flask import render_template, flash,redirect,url_for,abort,request 
from prj import app,db,login_manager 
from prj.models import *


#render your views here 

@app.route('/')
@app.route('/index')
def index():
    return render_template('home/index.html')


