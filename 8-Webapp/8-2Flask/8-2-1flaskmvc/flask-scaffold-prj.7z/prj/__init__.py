import os 
from flask import Flask  
from flask_sqlalchemy import SQLAlchemy 
from flask_login import LoginManager 
from flask_moment import Moment 

basedir =os.path.abspath(os.path.dirname(__file__))

app=Flask(__name__)

#now lets add this as secret key 
APP_SECRET_KEY=os.urandom(128)
app.config['SECRET_KEY']=APP_SECRET_KEY 

#SQLAlchemy Configurations 
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///'+os.path.join(basedir,'dreiproject.db')

#enable and disable SQLAlchemy to track modifications
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#app
app.config['DEBUG'] =True
#initializing SQLAlchemy 
db = SQLAlchemy(app)

#Authentication Configuration 
login_manager=LoginManager()
login_manager.session_protection= "strong"
login_manager.login_view = "login"
login_manager.init_app(app)

#for displaying timestamps 
moment =Moment(app)

import prj.models 
import prj.views