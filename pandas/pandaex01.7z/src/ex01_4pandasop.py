import pandas as pd 

crime_frame=pd.read_csv('./src/estimated_crimes.csv')

#print the top 5 rows datasets 
print("top five records:\n", crime_frame.head())

crime_subframe=pd.read_csv('./src/estimated_crimes.csv', usecols=['year','state_name','population','violent_crime','property_crime'])

#filtering data 
crime_subframe2017=crime_subframe.query('year==2017')
#remove rows with null data 
crime_subframe2017NN=crime_subframe2017[crime_subframe2017['state_name'].notnull()]

#compute crime rate per capita 
def crime_per_capita(row,number_of_people):
    ttl_crimes=row['violent_crime']+row['property_crime']
    population=row['population']
    count=(ttl_crimes/population)*number_of_people
    return count 

#create a new column 
crime_subframe2017NN=crime_subframe2017NN.apply(crime_per_capita,args=(1000,),axis=1)
print("post operation:\n", crime_subframe2017NN.head())

# descriptive statistics 
print('descriptive statistics:\n', crime_subframe2017NN.describe())

# #compute the national average 
# ttl_ppl=crime_subframe2017NN['population'].sum()
# ttl_crimes=+crime_subframe2017NN['violent_crime'].sum()+ crime_subframe2017NN['property_crime'].sum()
# national_avg_percap=(ttl_crimes/ttl_ppl)*1000

# #def compute_diff(row)
# def compute_diff(row):
#     diff= row['crime_per_1000']-national_avg_percap
#     return diff 

# crime_subframe2017NN["diff_of_national_avg"]=crime_subframe2017NN.apply(compute_diff,axis=1)

# # compute percentage diff compared to the national average
# def compute_percent(row):
#     percent = (row['crime_per_1000']/national_avg_percap)*100
#     if percent > 100:
#         return "+" + str(int(percent-100)) + "%"
#     return "-" + str(100 - int(percent)) + "%"


# crime_subframe2017NN['percent_diff_national']= crime_subframe2017NN(compute_percent,axis=1)

# print(crime_subframe2017NN)