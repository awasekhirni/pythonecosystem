#import datatable as dt
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt

# #version of datables
# print("version of datatables:", dt.__version__)
# alphalist=list('abcdefghijklmnopqrstuvwxyz')
# alphaarr=np.arange(26)
# alphaframe=pd.DataFrame(dict(col1=alphalist,col2=alphaarr))
# print('alphaframe:',alphaframe)

#reading customer churn data 
customer_df=pd.read_csv('./src/Churn_Modelling.csv',nrows=5000)
#print head rows 
print('customer_dataframe:',customer_df.head())
#printing the shape of the dataset 
print("customer_churn shape:",customer_df.shape)
#check for missing value 
print("check for missing data:", customer_df.isna().sum())
#if missing value we replace missing data with mean()
#avg_val=customer_df['column'].mean()
#customer_df['column'].fillna(value=avg,inplace=True)
#drop missing values 
#customer_df.dropna(axis=0,how='any',inplace=True)
#selecting rows based on conditions 
cust_france_churn=customer_df[(customer_df.Geography=='France')& (customer_df.Exited==1)]
print("customer-france-churn:",cust_france_churn.Geography.value_counts())

#plotting salary 
customer_df['EstimatedSalary'].plot(kind='hist',figsize=(8,5))
plt.show()
#describing the conditions 
customer_df['Tenure'].isin([4,6,9,10])[:3]
#groupby operations 
print("groupby operations:",customer_df[['Geography',"Gender",'Exited']].groupby(['Geography','Gender']).mean())
print("groupby operations with multiple aggregate functions:",customer_df[['Geography',"Gender",'Exited']].groupby(['Geography','Gender']).agg(['mean','count']))

#descriptive statistics 
print("descriptive_statistics:",customer_df.describe())


# different aggregate functions to diffeent groups

df_summary = customer_df[['Geography','Exited','Balance']].groupby('Geography')\
.agg({'Exited':'sum', 'Balance':'mean'}) 
df_summary.rename(columns={'Exited':'# of churned customers', 'Balance':'Average Balance of Customers'},inplace=True)
print("aggregation_by_groups:",df_summary)

#mockup-data uk


df_ukframe=pd.read_csv('./src/uk-500.csv')
#set a numeric id for use as an index 
df_ukframe['id']=[np.random.randint(0,1000) for x in range(df_ukframe.shape[0])]
#printing partial head 
print("head of the datasets::\n",df_ukframe.head(5))
#selecting single rows using iloc and dataframe 
print("first row of the data frame:\n", df_ukframe.iloc[0])
print("last row of the data frame:\n", df_ukframe.iloc[-1])

#selecting the columns using iloc and dataframe 
print("first column of the data frame:\n",df_ukframe.iloc[:,0])
print("last column of the data frame:\n",df_ukframe.iloc[:,-1])

#label based extraction of the columns 
print("label based column extraction:\n",df_ukframe.set_index("last_name",inplace=True))
print("head of the datasets:",df_ukframe.head())
print("info:", df_ukframe.loc['Andrade'])
print("info:", df_ukframe.loc[['Andrade','Veness'],['first_name','address','city']])
print("info:", df_ukframe.loc[df_ukframe['first_name'] == 'Antonio', 'city':'email'])
print("endswith operation",df_ukframe.loc[df_ukframe['email'].str.endswith("hotmail.com")] )
print("has operations:",df_ukframe.loc[df_ukframe['first_name'].isin(['France', 'Tyisha', 'Eric'])] )

# Select rows with first name Antonio AND hotmail email addresses
df_ukframe.loc[df_ukframe['email'].str.endswith("gmail.com") & (df_ukframe['first_name'] == 'Antonio')] 
 
# select rows with id column between 100 and 200, and just return 'postal' and 'web' columns
df_ukframe.loc[(df_ukframe['id'] > 100) & (df_ukframe['id'] <= 200), ['postal', 'web']] 
 
# A lambda function that yields True/False values can also be used.
# Select rows where the company name has 4 words in it.
df_ukframe.loc[df_ukframe['company_name'].apply(lambda x: len(x.split(' ')) == 4)] 
 
# Selections can be achieved outside of the main .loc for clarity:
# Form a separate variable with your selections:
idx = df_ukframe['company_name'].apply(lambda x: len(x.split(' ')) == 4)

#change the index to be based on the id column
df_ukframe.set_index('id',inplace=True)
#select the row with 'id = 450
print("retrieve the row with id 450:\n",df_ukframe.iloc[450])

#descriptive statistics 
print("descriptive_statistics:",df_ukframe.describe())


#########################
#phone dataset 
import dateutil
phone_frame=pd.read_csv('./src/phone_data.csv')
print("top5 records:\n", phone_frame.head(5))
#convert date from string to datetime 
phone_frame['date']=phone_frame['date'].apply(dateutil.parser.parse,dayfirst=True)
#count of the rows in the dataset 
print("count of rows:\n",phone_frame['item'].count())
#longest phone call 
print("longest phone call:\n",phone_frame['duration'].max())
#no of entries for each month 
print("entry log per month:\n",phone_frame['month'].value_counts())
#no of non-null unique network entries 
print("non-null unique network entries:",phone_frame['network'].nunique())

#summarizing groups in the datafrmae 
print("summarized groups:\n", phone_frame.groupby(['month']).groups.keys())
#len 
print("length:\n",len(phone_frame.groupby(['month']).groups['2014-11']))

# fetch the first month data 
print("firstmonth data:\n", phone_frame.groupby('month').first())
# Get the sum of the durations per month
print("sumo of the durations per month:\n",phone_frame.groupby('month')['duration'].sum())
# calls, sms and data entries per month 
print("calls, sms and data per month:\n", phone_frame.groupby(['month','item'])['date'].count())

# calls, text and data sent per month - split by network 
print("split by network, calls, text and data:\n", phone_frame.groupby(['month','network_type'])['date'].count())

# monthly duration sum 
print("monthly duration sum:\n",phone_frame.groupby('month')['duration'].sum())

print("monthly duration sum:\n",phone_frame.groupby('month')[['duration']].sum())


#aggregation operation 
print("aggregation:\n",phone_frame.groupby('month', as_index=False).agg({"duration":"sum"}))

#multiple statistics per group 
print(" monthly frame stats:\n", phone_frame.groupby(
   ['month', 'item']
).agg(
    {
         'duration':sum,    # Sum duration per group
         'network_type': "count",  # get the count of networks
         'date': 'first'  # get the first date per group
    }
))

#aggregation function 
print("multiple group:\n",phone_frame.groupby( ['month', 'item']).agg(
    {
        # Find the min, max, and sum of the duration column
        'duration': [min, max, sum],
        # find the number of network type entries
        'network_type': "count",
        # minimum, first, and number of unique dates
        'date': [min, 'first', 'nunique']
    }
))


print("named tuple aggregations:\n", phone_frame[phone_frame['item'] == 'call'].groupby('month').agg(
    # Get max of the duration column for each group
    max_duration=('duration', max),
    # Get min of the duration column for each group
    min_duration=('duration', min),
    # Get sum of the duration column for each group
    total_duration=('duration', sum),
    # Apply a lambda to date column
    num_days=("date", lambda x: (max(x) - min(x)).days)    
))


# memory usage 
print("memory usage:\n", phone_frame.memory_usage())