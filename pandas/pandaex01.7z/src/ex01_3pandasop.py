import pandas as pd 
import numpy as np 

#income data frame 
income_frame=pd.read_csv('./src/income.csv')
#fetching the list of coloumns 
print("columns of income frame:\n",income_frame.columns)
#list only a couple of coloumns from the list 
print("only few columns:\n",income_frame.columns[0:4])
#list the data types of each column 
print("datatypes of each column are:\n", income_frame.dtypes)
# to fetch the datatype of one single column
print("single column datatype:\n", income_frame['State'].dtypes)
#conversion of datatypes 
#income_frame.Y2009=income_frame.astype(float)
print("conversion of datatype:\n", income_frame.dtypes)
#view the dimensions or shape of the data 
print("dimensions or shape of the data:\n", income_frame.shape)
# to view the top 5 rows 
print("top 5 rows using head() function:\n", income_frame.head())

#income[0:5]
print("alternatively listing top 5 rows:\n", income_frame[0:5])

#creating a bivariate frequency distribution 
pd.crosstab(income_frame.Index, income_frame.State)
#frequency distirbution 
income_frame.Index.value_counts(ascending=True)

#sorting operation 
#income_frame.sort_values("State",ascending=False)
#income_frame.sort_values("State",ascending=False, inplace=True)
#income.Y2009.sort_values()

#create new variables 
income_frame['diffY08Y09']=income_frame.Y2008-income_frame.Y2009
print("difference of two years data:\n", income_frame['diffY08Y09'])
#compute income ratio 
income_frame.ratio=income_frame.Y2008/income_frame.Y2009 
print("income ratio:\n", income_frame.ratio)

#basic descriptive statistics 
print("basic descriptive statistics:\n", income_frame.describe())

print("mean:\n",income_frame.mean())
print("median:\n",income_frame.median())
print("aggregation:\n", income_frame.agg(['mean','median']))
print("custom function:\n",income_frame.loc[:,["Y2002","Y2008"]].max())
print("groupby operation:\n", income_frame.groupby("Index")["Y2002","Y2003"].min())
print("aggregate function:\n", income_frame.groupby("Index")["Y2002","Y2003"].agg(["min","max","mean"]))
print("group by more than one coloumn:\n", income_frame.groupby(["Index", "State"]).agg({"Y2002": ["min","max"],"Y2003" : "mean"}))
print("filtering operation:\n", income_frame[income_frame.Index == "A"])
print("filtering operation:\n", income_frame.loc[income_frame.Index == "A"])
#removing duplicate row data 
# income_frame.loc[income_frame.duplicated(keep='first')] # keeping the first occurence
# income_frame.loc[income_frame.duplicated(keep='last')] # keeping the last occurence


#hubble telescope data 
import matplotlib.pyplot as plt 
hubble_frame=pd.read_csv('./src/hubble_data.csv')
#printing the top 5 records 
print("top 5 records:\n", hubble_frame.head())
#print base characteristics
print("descriptive statistics:\n", hubble_frame.describe())


#titanic dataset 
titanic_frame=pd.read_csv('./src/titanic.csv')
#print the top 5 rows 
print("top 5 rows are:\n", titanic_frame.head())
#basic info about the dataset 
print("basic info:\n", titanic_frame.info())
#isnull check 
print("isnull check:", titanic_frame.isnull())

