import numpy as np 
import pandas as pd 


#check the version of the pandas installed 
print(pd.__version__)
print(pd.show_versions(as_json=True))

alphalist= list('abcedfghijklmnopqrstuvwxyz')
myarr = np.arange(26)
mydict = dict(zip(alphalist, myarr))


alt_ser1=pd.Series(alphalist)
alt_ser2=pd.Series(myarr)
alt_ser3=pd.Series(mydict)
print(alt_ser3.head())

#convert the index of a series into a column of a dataframe
alphabets=list('abcedfghijklmnopqrstuvwxyz')
alpharray=np.arange(26)
dictalpha=dict(zip(alphabets,alpharray))
seriesalpha=pd.Series(dictalpha)
alphadf=seriesalpha.to_frame
print("index of a series is:", alphadf)

#combine many series to form a dataframe 
oneseries = pd.Series(list('abcedfghijklmnopqrstuvwxyz'))
twoseries = pd.Series(np.arange(26))
output_series=pd.concat([oneseries,twoseries],axis=1)
#alternatively 
other_output=pd.DataFrame({'col1':oneseries,'col2':twoseries})
print("approach one:",output_series)
print("approach two:",other_output)

#assign name to the series index 
name_series = pd.Series(list('abcdefghijklmnopqrstuvwxyz'))
name_series.name='alphabets'
name_series.head()

#exclusion operation 
eins=pd.Series([12,33,374,384,28,37,289,489,85,128])
zwei=pd.Series([11,33,67,28,35,49,10,183,85,37,384])
exclusive_series=eins[~eins.isin(zwei)]
print("exclusion operations using two series data:",exclusive_series)

# extract unique items in both series A and B 
#union
unionAB=pd.Series(np.union1d(eins,zwei))
#intersection
intersectAB=pd.Series(np.intersect1d(eins,zwei))
#unique items 
uniqueser=unionAB[~unionAB.isin(intersectAB)]
#print the results 
print("union series:",unionAB)
print("intersection series:",intersectAB)
print("unique series:",uniqueser)

#compute the minimu,25th percentile, median, 75th and maximum of a series 
clickseries=pd.Series(np.random.normal(20,5,25))
print("user click series:",clickseries)
ein_state=np.random.RandomState(100)
user_series=pd.Series(ein_state.normal(20,5,25))
#compute the percentile 
base_stats=np.percentile(user_series,q=[0,25,50,75,100])
#print result 
print("base statistics of series:",base_stats)

# frequency counts of each unique value in a series 
scores_users=pd.Series(np.take(list('abcdefgh'),np.random.randint(8,size=30)))
print(scores_users)
#fetching frequency 
frequsr_series= scores_users.value_counts()
print("fetching the frequency of the user series:", frequsr_series)

#replace everything other than top 2 most frequent items 
np.random.RandomState(100)
u_serv=pd.Series(np.random.randint(1,10,[20]))
print(u_serv)
#fetchthe  top 2 frequent items 
print("top 2 frequent items in sereis:",u_serv.value_counts())
mytop2freqitems=u_serv[~u_serv.isin(u_serv.value_counts().index[:2])]
print("my top 2 frequent list:", mytop2freqitems)

#create a bin of numeric series to 10 groups of equal size 
cat_ser=pd.Series(np.random.random(20))
print(cat_ser)
ppcate=pd.qcut(cat_ser, q=[0.,.10,.20,.3,.4,.5,.6,.7,.8,.9,1], labels=['first','second','third','fourth','fifth','sixth','seventh','eight','nine','ten'])
print("categorized series:",ppcate)

# reshape the series into a dataframe with 3 rows and 5 columns
dfca=pd.Series(np.random.randint(1,10,15))
#3x5 array 
threefive=pd.DataFrame(dfca.values.reshape(3,5))
#printing the result 
print("reshaping the series data:",threefive)

#position of numbers that are multiple of 3 from a given series 
gseries= pd.Series(np.random.randint(1,100,10))
print(gseries)
#print("multiple of 3 are:", np.argwhere(gseries % 3==0))

#extract items at given positions from a series 
mypos=[0,3,9,15,23]
nt=pd.Series(list('abcdefghijklmnopqrstuvwxyz'))
print("position of the alphabets:",nt.take(mypos))

#stacking vertically and horizontally 
hvst= pd.Series(range(5))
lvst=pd.Series(list('abcde'))
#vertical stacking 
vert_out=hvst.append(lvst)
print("vertical stacking operation:", vert_out)
#horizontal stacking 
horz_out=pd.concat([hvst,lvst],axis=1)
print("horizontal stackign data frame:", horz_out)

#fetch the position of items of series A in another series B 
A_series=pd.Series([12,56,37,28,48,29,39,10,32,50,21,38,20,183,23])
B_series=pd.Series([29,39,10,38])
#fetching the positions 
print("position of B elements in A:",[np.where(i==A_series)[0].tolist()[0] for i in B_series])
#alternative approach 
print("position of B elements in A:", [pd.Index(A_series).get_loc(i) for i in B_series])


#compute the mean square error on a truth and predicted series 
webtruth=pd.Series(range(20))
webpred=pd.Series(range(20))+ np.random.random(20)
print(np.mean((webtruth-webpred)*2))

# convert the first character of each element in a series to uppercase 
sentencewords=pd.Series(['hello', 'you','fool','i','love','you','come','on','enjoy', 'the','joy','ride'])
#convert to titlecase
titlecase=sentencewords.map(lambda x: x.title())
uppercase=sentencewords.map(lambda y: y[0].upper()+y[1:])
utcase=pd.Series([i.title() for i in sentencewords])
print("title case result:",titlecase)
print("upper case result:",uppercase)
print("alternative approach:",utcase)

#compute the number of characters in each word in the series 
charcount_senword=sentencewords.map(lambda z:len(z))
print("character count in each word:", charcount_senword)

#compute the difference of diffeence betwen consequtive numbers of a series
scores=pd.Series([125,73,27,587,292,230,124,921,262,182,12,50,102,192,1239])
#solution 
print(scores.diff().tolist())
print(scores.diff().diff().tolist())

#converting a series of date-strings to a timeseries 
ts_d=pd.Series(['01 Jan 2010', '02-02-2011', '20120303', '2013/04/04', '2014-05-05', '2015-06-06T12:20'])
from dateutil.parser import parse 
cvd=ts_d.map(lambda g:parse(g))
avd=pd.to_datetime(ts_d)
print(cvd)
print(avd)

#extracting the day of the month, weeknumber, day of the year and day of the week
dom=cvd.dt.day.tolist()
print("day of the month:",dom)
wn=cvd.dt.weekofyear.tolist()
print("week number:",wn)
doy=cvd.dt.dayofyear.tolist()
print("day of year:",doy)
dow=cvd.dt.dayofweek.tolist()
print("day of the week:",dow)
print("day of the wekk:",cvd.dt.weekday.tolist())


#convert year-month string to dates corresponding to the 4th day of the month
monthlyseries=pd.Series(['Jan 2014','Feb 2013','Jan 2014','Feb 2014'])
#solution 1 
# from dateutil.parser import parse 
# parse the date 
myimp=monthlyseries.map(lambda y:parse(y))
ms_datestr=myimp.dt.year.astype('str') + '-' + myimp.dt.month.astype('str') + '-' + '04'
#formating 
[parse(i).strftime('%Y-%m-%d') for i in ms_datestr]
#alternative approach 
monthlyseries.map(lambda y:parse('04'+ y))


#filter words that contain atleast 2 vowels 
from collections import Counter 
twovowels = sentencewords.map(lambda y:sum([Counter(y.lower()).get(i,0) for i in list('aeiou')])>=2)
vlist=sentencewords[twovowels]

print("two vowel words list:",vlist)

#filtering valid emails from a series 
#using regular expressions
email_list=pd.Series(['morain@icloud.com',
'malvar@gmail.com',
'graham@live.com',
'jbailie at outlook.com',
'linuxhack optonline.net',
'cgreuter@optonline',
'hllam@att.net',
'pgolle@hotmail.com',
'mahbub@yahoo.com',
'loscar@icloud.com',
'simone@att.net',
'munjal@gmail.com'])

import re 
pattern='[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}'
e_mask=email_list.map(lambda z:bool(re.match(pattern,z)))
#valid list
val_list=email_list[e_mask]
# alternatively 
olist=email_list.str.findall(pattern,flags=re.IGNORECASE)
#another approach
nlist=[x[0] for x in [re.findall(pattern,email) for email in email_list] if len(x)>0]
print(val_list)
print(nlist)
print(olist)

# mean of a series grouped by another series 
fruitlist=pd.Series(np.random.choice(['apple','banana',"cherry","kiwi","mango","pineapple","cheeku","pears","plums","dragonfruit"], 100))
fruit_weights=pd.Series(np.linspace(1,100,100))
#weights by group 
fwgm=fruit_weights.groupby(fruitlist).mean()
print("weights grouped by fruits:",fwgm)


#compute euclidean distance/pythogorean distance between series 
euc1=pd.Series([125,73,27,587,292,230,124,921,262,182,12,50,102,192,1239])
euc2=pd.Series([278,120,292,293,494,201,202,58,290,401,582,120,130,201,30])
pygd=sum((euc1-euc2)**2)**.5
#alternatively 
eucd=np.linalg.norm(euc1-euc2)
print("pythogorean distance between series A and B is:", pygd)
print("pythogorean/euclidean distance between series A and B is:",eucd)


#identify al the local maxima/peaks in a numeric series 
nsdata=pd.Series([123,129,383,2928,918,384,905,302,294,467,391,482,184])
peakval=np.diff(np.sign(np.diff(nsdata)))
peak_mount=np.where(peakval==-2)[0]+1
print("peak mountains:",peak_mount)

#replace missing spaces in a string with the least frequest character 
junkstring="asjhlakqwuieqwenqjkljqwehkhjqweuiqwehiqwuioqiwpeonmqweoiiklmlkadsmmadaskj"
gener=pd.Series(list(junkstring))
char_freq=gener.value_counts()
print(char_freq)
least_freq=char_freq.dropna().index[-1]
"".join(junkstring.replace('',least_freq))


#create a time series starting "1947-01-01" 

fri_weekend=pd.Series(np.random.randint(1,26,26),pd.date_range('1947-01-01',periods=26,freq='W-FRI'))
print(fri_weekend)

missy_dates=pd.Series([1,10,3,np.nan],index=pd.to_datetime(['1947-10-10','1947-11-03', '1947-11-16','1947-11-25']))
print(missy_dates)
print(missy_dates.resample('D').ffill())

#compute autocorrelations of a numeric series 
nsm_ds=pd.Series(np.arange(20)+np.random.normal(1,10,20))
#solutions
autocorrelations = [nsm_ds.autocorr(i).round(2) for i in range(11)]
print(autocorrelations[1:])
print('Lag having highest correlation: ', np.argmax(np.abs(autocorrelations[1:]))+1)
bhdf=pd.read_csv('./src/BostonHousing.csv', chunksize=100)
bh_partial=pd.DataFrame()
for chunk in bhdf:
    bh_partial=bh_partial.append(chunk.iloc[0,:])

#print head
print(bh_partial.head())

#alternatively 
boshou=pd.read_csv('./src/BostonHousing.csv',chunksize=100)
howley=pd.concat([chunk.iloc[0] for chunk in boshou],axis=1)
towley=howley.transpose()
print(howley.head())
print(towley.head())


boston_h=pd.read_csv('./src/BostonHousing.csv', 
                 converters={'medv': lambda x: 'High' if float(x) > 25 else 'Low'})

print(boston_h.head())


#only fetching partial column data 
partial_bh=pd.read_csv('./src/BostonHousing.csv', usecols=['crim', 'medv','tax','ptratio'])
print(partial_bh.head())



#striding 
stridy=pd.Series(range(20))
def generate_strides(inpy,stride_len=5, window_len=5):
    n_strides=((inpy.size-window_len)//stride_len)+1
    return np.array([inpy[s:(s+window_len)] for s in np.arange(0, inpy.size, stride_len)[:n_strides]])

generate_strides(stridy, stride_len=2, window_len=4)


#base statistics data for a given dataset 
cars_data=pd.read_csv('./src/Cars93.csv')
#print information about rows and columns 
print(cars_data.shape)
print("datatype:",cars_data.dtypes)
#columns under each datatype 

print(cars_data.dtypes.value_counts())
#basic descriptive statistics 
cars_basestats=cars_data.describe()
#numpy array
cars_dfstats_arr=cars_data.values 
#conversion to list 
cars_dflist=cars_data.values.tolist()
print(" Base Descriptive Statistics:\n", cars_basestats)
#print(cars_dflist)
#print(cars_dfstats_arr)

#check for missing value 
mv_carsdata=pd.read_csv('./src/Cars93.csv')
print("missing value data- Cars 93:", mv_carsdata.isnull().values.any())
#counting the no columns with missing data 
no_missingval_each_col=mv_carsdata.apply(lambda x: x.isnull().sum())
no_missingval_each_col.argmax()
print("no of coumns with missing data:", no_missingval_each_col)
#replacing missing value of multiple numeric columns with the mean 
mv_replace_out=mv_carsdata[['Min.Price', 'Max.Price']] = mv_carsdata[['Min.Price', 'Max.Price']].apply(lambda x: x.fillna(x.mean()))
print("missing value replaced with mean value:",mv_replace_out)
#only print 10 columns in the result 
print("only 10 rows and columns:", pd.set_option('display.max_columns',10))
print("only 10 rows and columns:",pd.set_option('display.max_rows',10))
print("describe all options:", pd.describe_option())


#compute the 7th largest value of a column in a dataframe
mydf=pd.DataFrame(np.random.randint(1,30,30).reshape(10,-1),columns=list('abc'))
n=7 
print(mydf['a'].argsort()[::-1][n])


# finding and capping outliers from a series or data frame column
# remove 5% and 95% outliers 
axia_series=pd.Series(np.logspace(-2,2,30))

#filtering and capping operation 
def filter_cap_outlier(df,btmperc,topperc):
    btmperc,topperc=df.quantile([btmperc,topperc])
    print("bottom percentile:",btmperc, '%ile', 'low', '|',topperc,'%ile','high')
    df[df<btmperc]=btmperc 
    df[df>topperc]=topperc 
    return(df)

capper_frame=filter_cap_outlier(axia_series,0.05,0.95)
print("filtering and capping operation:", capper_frame)