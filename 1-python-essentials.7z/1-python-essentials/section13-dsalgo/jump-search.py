"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#JUMP Search 
# a searching algorithm for sorted arrays. 
# basic idea is to search fewer elements than a linear search 
import math 


def MyJumpSearchAlgo(myarray,x,n):
    """Jump Search Algorithm"""
    step = math.sqrt(n)

    prev=0
    while myarray[int(min(step,n)-1)]<x:
        prev=step 
        step+=math.sqrt(n)
        print(step)
        if prev >=n:
            return -1

    
    #doing a linear search for x in block beginning with prev
    while myarray[int(prev)]<x:
        prev +=1 
        #if we reach next block or end of the array, element is not present 
        if prev == min(step,n):
            return -1 

    #if the element is found 
    if myarray[int(prev)]==x:
        return prev       
        
        
    return -1


if __name__=="__main__":
    demoarray=[ 270, 881, 818, 22, 273, 581, 891, 1123, 2111, 
    411, 5153, 8229, 34144, 43233, 53775, 610 ]
    
    sdarr=sorted(demoarray)
    print(sdarr)
    x=2111
    n=len(demoarray)
    #find the index of the element in the array
    fetchindex=MyJumpSearchAlgo(sdarr,x,n)
    #print the index position where the element is located 
    print("the number searched for ",x,"is at index:","%.0f"%fetchindex)
