"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#Binary Search Algorithm 
# given a sorted array of n elements
# find the element 

#1.search is sorted array - by repeatedly dividign the search interval in half


def BinarySearch (myarr, lower, upper, x): 
  
    # Check base case 
    if upper >= lower: 
  
        mid = int(lower + (upper - lower)/2)
  
        # If element is present at the middle itself 
        if myarr[mid] == x: 
            return mid 
          
        # If element is smaller than mid, then it  
        # can only be present in left subarray 
        elif myarr[mid] > x: 
            return BinarySearch(myarr, lower, mid-1, x) 
  
        # Else the element can only be present  
        # in right subarray 
        else: 
            return BinarySearch(myarr, mid + 1, upper, x) 
  
    else: 
        # Element is not present in the array 
        return -1
  

if __name__ == "__main__":
    array=[ 2, 3674,3, 4, 10, 40,3674,474,47463,12,3737,111,27827,187178,3872872,1277812 ]
    s_array=sorted(array)
    print(s_array) 
    x=111
    y=len(s_array)-1
    fetchResult=BinarySearch(s_array,0,y,x)
    if fetchResult !=-1:
        print("Element is present at index %d" % fetchResult)
    else:
        print("Element is not present in the array")