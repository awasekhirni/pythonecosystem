"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#QuickSort
# a divide and conquer algorithm 
# it picks an element as pivot and partitions the given array around the picked pivot 
#different approaches 
#1.always pick first element as pivot 
#2. last element as pivot 
#3. random element as pivot 
# 4. median as pivot 

def partition(myarray,low,high):
    i=(low-1) #index of smaller eleemnt 
    pivot=myarray[high]

    for j in range(low,high):
        if myarray[j]<=pivot:
            i=i+1 
            myarray[i],myarray[j]=myarray[j],myarray[i]
    myarray[i+1],myarray[high] =myarray[high],myarray[i+1]
    return (i+1)


def quickSort_last(myarray,low,high):
    if low <high:
        pi=partition(myarray,low,high)

        quickSort_last(myarray, low,pi-1)
        quickSort_last(myarray,pi+1,high)


if __name__=="__main__":
    demoArray= [ 270, 881, 818, 22, 273, 581, 891, 1123, 2111, 
    411, 5153, 8229, 34144, 43233, 53775, 610 ]
    n=len(demoArray)
    quickSort_last(demoArray,0,n-1)
    print("QuickSorted Algo implementation:")
    for i in range(n):
        print("%d" % demoArray[i])



