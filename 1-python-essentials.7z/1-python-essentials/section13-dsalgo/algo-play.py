"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""


#stacks in python 
#stack is a container of objects that are inserted and removed accroding to the Last-IN-FIRST-OUT LIFO concept. 
#stacks can be implemented in python using lists.
# adding elements to a stack = push operation
# remove or delete an element = pop operation 

#(LastElement) -> 1001->2002->3003->4004->5005->6006(TopElement)
myStackedCards=[1001,2002,3003,4004,5005,6006]
myStackedCards.append(7007) # note that now top element is 7007
print(myStackedCards)

#removing elements from the stack 
myStackedCards.pop() # removed 7007
myStackedCards.pop() # removed 6006
print(myStackedCards)


#stack implementation 
class Stack(object):
    """Stack implementation in python"""
    def __init__(self,value=None,next=None):
        self.value=value 
        self.next = next 
    

    def push(self,value):
        oldstack = Stack(self.value,self.next)
        self.value =value 
        self.next =oldstack 
    
    def pop(self):
        outputval =self.value 
        self.value, self.next = self.next.value,self.next.next 
        return outputval 

    def isEmpty(self):
        if(self.value==None):
            return True 
        else:
            return False



stackedPlates=Stack()
stackedPlates.push(31312)
stackedPlates.push(12312312)
stackedPlates.push(72623)
print(stackedPlates)
stackedPlates.pop()
print(stackedPlates)
print(stackedPlates.isEmpty())


#alternative implementation of stack 
class AltStack(object):
    def __init__(self,value=None,next=None):
        self.value=value 
        self.next = next 

    def push(self,value):
        oldstack=AltStack(self.value,self.next)
        self.value = value 
        self.next = oldstack
    
    def pop(self):
        outptval=self.value 
        self.value,self.next = self.next.value, self.next.next 
        return outptval
    
    def peek(self):
        return self.value 
    

    def size(self):
        numelements=0
        nextval = self.next 
        while(nextval != None):
            nextval = nextval.next 
            numelements+=1
        return numelements 


    def isEmpty(self):
        if(self.value==None):
            return True 
        else:
            return False 
    

if __name__ =="__main__":
    mystack=AltStack()
    mystack.push(12)
    mystack.push(10)
    mystack.push(9)
    print("Size of the stack is:", mystack.size())
    mystack.push(213132)
    print("Size of the stack is:", mystack.size())
    mystack.pop()
    print("popped elements are:",mystack.pop())
    print(mystack.isEmpty())


#Queue 
# A Queue - a container of objects that are inserted and removed according to the FIFO First In First Out principle. 
# they can be of many different types 
# lists are not efficient a way of implementing a queue, since append() and pop() from the end of a list is not fast and incur a memory movement cost. 
# insertion at the end and deletionf rom the beginning of a list is not so fast since it requires a shift in the element positions 

class Queue(object):
    """ Queue implementation in python"""
    def __init__(self,max_size=0):
        self.size=max_size
        self.arr=[]

    def enqueue(self,item):
        """appending an item to the queue"""
        if self.is_full():
            print("the Queue is Full")
        else:
            self.arr.append(item)

    def dequeue(self):
        """removing an item from the queue"""
        if self.is_empty():
            print("the Queue is Empty")
        else:
            self.arr.pop(0)
    
    def is_empty(self):
        """checking whehter the queue is empty"""
        return len(self.arr)==0
    
    def is_full(self):
        """checking whether the queue is full or not"""
        return len(self.arr)==self.size

    def front(self):
        if self.is_empty():
            print("Queue is empty")
        else:
            print("self.arr[0]:", self.arr[0])

    def rear(self):
        if self.is_empty():
            print("Queue is empty")
        else:
            print("self.arr[len(self.arr)-1]:",self.arr[len(self.arr)-1])


##Alternative implementation of Queue using collection package from python 

from collections import deque 
myque=deque()
myque.append('think')
myque.append('design')
myque.append('wireframe')
myque.append('mockdev')
myque.append('development')
myque.append('cicd')
myque.append('publish')
myque.append('release')
print(myque)
myque.popleft() #prints => think 
myque.popleft() #prints => design 


#alternatively using queue 
from queue import Queue 
standinQ=Queue()
standinQ.put("Syed Awase")
standinQ.put("Syed Ameese")
standinQ.put("Syed Azeez")
print(standinQ)
print(standinQ.get()) # prints => Syed Awase 
print(standinQ.get()) # prints => Syed Ameese 
print(standinQ.get())#prints => Syed Azeez 
#print(standinQ.get_nowait()) # empty 
#print(standinQ.get()) # Blocks or waits forever since no elements 

# Priority Queue 
# a priority queue is a container data structure that manages a set of records with totally ordered keys which are numeric weight values to provide quick access tot he record with the smallest or the largest key in the set. 
# it retrieves the highest-priority element.
# they are used for dealing with scheduling problems, where precedence to tasks with higher urgency is given priority. 
#applicable in operating system task scheduler 
# applicable in real-time games 
pinQ=[]
pinQ.append((23,"jackiechan"))
pinQ.append((18,"brucewills"))
pinQ.append((19,"willsmith"))
pinQ.append((8,"tomcruise"))
pinQ.append((4,"Arnoldswazneger"))
pinQ.append((3,"SilversterStallone"))

#resort after every insertion 
pinQ.sort(reverse=True)
while pinQ:
    next_item=pinQ.pop()
    print(next_item)

#HeapQ Module 
# implementation of priority queue 
import heapq 

purchaseList=[]
heapq.heappush(purchaseList,(18,'router'))
heapq.heappush(purchaseList,(22,'monitor'))
heapq.heappush(purchaseList,(42,'mouse'))
heapq.heappush(purchaseList,(11,'television'))
heapq.heappush(purchaseList,(8,'laptop'))
heapq.heappush(purchaseList,(3,'mobile'))

while purchaseList:
    next_item=heapq.heappop(purchaseList)
    print(next_item) 



#alternative implementation of priority queue 
from queue import PriorityQueue 

taskQ=PriorityQueue()
taskQ.put((2,'mlusingPython'))
taskQ.put((12,'learnScala'))
taskQ.put((15,'learnRust'))
taskQ.put((13,'learnDProg'))
taskQ.put((8,'PythonwithR'))
taskQ.put((5,'PythonAI'))
taskQ.put((6,'OraclewithPython'))

while not taskQ.empty():
    next_item=taskQ.get()
    print(next_item)


#Dictionaries in python 

#dictionaries are highly optimized and underlie many parts of the language. 

myphonediary = {'Awase':'124','Ameese':'069','Azeez':'773'}
myphonediary['Awase']

# alternatively using collections 
# ordereddictionary 

import collections 
mile=collections.OrderedDict(one=1,two=2,three=3)
print(mile)
print(mile['two'])
mile['four']=4
print(mile)
print(mile.keys())


#creating dictionaries or groups of multiple dictionaries into a sinvle mapping 
from collections import ChainMap 
mydiction={'awase':99008,'ameese':96911}
otherdiction={'babla':98991,'abu':20012}
together=ChainMap(mydiction,otherdiction)

print(together)


#creating readonly dictionaries 
#types.MappingProxyType 
from types import MappingProxyType
read_only = MappingProxyType({'http_accessPort':453,'https_accessport':965})

print(read_only)
#trying to assign a value to any existing key would throw an error
read_only['http_accessPort']:872


#graphs in python 
# it consists of nodes and also vertices, which may or may not be connected to each other 
# the lines or the path that connects two nodes is called an edge. 
# if the edge has a particular direction of flow, then it is called a directed graph, with the direction edge being called an arc. 
# if no directions are specified, the graph is called undirected graph. 
# applied in social networks, molecular studies in chemistry biology, maps, recommender systems 

graph = { "a" : ["c", "d"],
          "b" : ["d", "e"],
          "c" : ["a", "e"],
          "d" : ["a", "b"],
          "e" : ["b", "c"]
        }


def graph_edges(graph):
    edges=[]
    for vertices in graph:
        for neighbour in graph[vertices]:
            edges.append((vertices,neighbour))
    return edges 

print(graph_edges(graph))


#alternative implementation 
from collections import defaultdict 











#tree in python 

class MyTree:
    def __init__(self,info, left=None,right=None):
        self.info=info 
        self.left = left 
        self.right =right 
    
    def __str__(self):
        return (str(self.info) + ', Left child: ' + str(self.left) + ', Right child: ' + str(self.right))


classicTree = MyTree(1,MyTree(2,2.1,2.2), MyTree(3,3.1))

print(classicTree)



#linked list in python
# embedded references in objects 
# a common data structure the linked list 
# linked lists are made up of nodes, where each node contains a reference to the next node in the list. 
# in addition, each node contains a unit of data called cargo 
# linked list is considered a recursive data structure because it has a recursive definition 
# a linked list is either empty (none) or has a node that contains a cargo object and a reference to a linked list . 


from collections import deque 

mylin=deque([1,2,3,4,5])
print(mylin)
for x in mylin:
    print(x)

print(mylin.pop(),mylin)



class MyNode:
    def __init__(self,value=None,next=None):
        self.value=value 
        self.next =next 
    
    def __str__(self):
        return 'Node ['+str(self.value)+']'


class MyLinkedList:
    def __init__(self):
        self.first = None
        self.Last=None 
    
    def insert(self,x):
        if self.first ==None:
            self.first=MyNode(x,None)
            self.last = self.first 
        elif self.last ==self.first :
            self.last = MyNode(x,None)
            self.first.next = self.last 
        else:
            current = MyNode(x,None)
            self.last.next =current 
            self.last =current 
    
    def __str__(self):
        if self.first != None:
            current = self.first
            out = 'MyLinkedList [\n' +str(current.value) +'\n'
            while current.next != None:
                current = current.next
                out += str(current.value) + '\n'
            return out + ']'
        return 'LinkedList []'

    def clear(self):
        self.__init__()

    

if __name__ =="__main__":
    mylist = MyLinkedList()
    mylist.insert(23123123)
    mylist.insert(636235)
    mylist.insert(36362)
    mylist.insert(4647)
    print(mylist)
    mylist.clear()
    print(mylist)





#double linked list 




# circular linked list 

class MyCircularQueue:
    #constructor for the class 
    def __init__(self,maxSize):
        self.queue=list()
        #user input vale for maxSize 
        self.maxSize=maxSize 
        self.head =0
        self.tail =0 

    ##adding element to the queue
    def add_enqueue(self,data):
        #if queue is full 
        if self.size()==(self.maxSize-1):
            return("Queue is full")
        else:
            #please go ahead and add an element to the queue 
            self.queue.append(data)
            #increment the tail pointer 
            self.tail = (self.tail+1)%self.maxSize 
            return True 
        
    
    ##removing an elemnt from the queue
    def rem_dequeue(self):
        #check if the queue is empty 
        if self.size()==0:
            return("the Queue is empty!")
        else:
            #fetch data 
            data=self.queue[self.head]
            #increment head 
            self.head= (self.head+1)% self.maxSize 
            return data  
        
    # compute the size of the queue 
    def size(self): 
        if self.tail >=self.head:
            qSize=self.tail -self.head 
        else:
            qSize=self.maxSize-(self.head-self.tail)
        #return the size of the queue
        return qSize 
    

if __name__=='__main__':
    size = input("Enter the size of the Circular Queue please:")
    myq=MyCircularQueue(int(size))
    print(myq)
    print(myq.add_enqueue(123124132))
    print(myq.add_enqueue(234))
    print(myq.add_enqueue(3424))
    print(myq.add_enqueue(5234))
    print(myq.add_enqueue(4323))
    print(myq.add_enqueue(53431))
    print(myq.add_enqueue(55322))
    print(myq)