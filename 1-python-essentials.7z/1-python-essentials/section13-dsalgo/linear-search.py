"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""


#linear search 
#problem statement 
#given an array of n elements write a function to search a given element x in the array 

#myarray={112,231,1234,272,4857,3837,3827,37,2827,27487,388}

#find 37 exists in the array or not 

def LinearSearch(myarray,n,x):
    for i in range(0,n):
        if(myarray[i]==x):
            return i;
    return -1

if __name__=='__main__':
    myarray=[112,231,1234,272,4857,3837,3827,37,2827,27487,388]
    x=37
    n=len(myarray)
    result=LinearSearch(myarray,n,x)
    if(result==-1):
        print("Element is not present in the array")
    else:
        print("Element is present at index",result)