"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#selection sort algorithm
import sys

#traversing through all the array elements 
def selectionSortAlgo(myarray):
    print("pre-sorting array is:",myarray)
    for i in range(len(myarray)):
        min_index=i 
        for j in range(i+1,len(myarray)):
            if myarray[min_index]>myarray[j]:
                min_index=j 

        #swapping the minimum element with the first element 
        myarray[i],myarray[min_index]= myarray[min_index],myarray[i]

    
    print("post sorting operations, the array is:")
    for k in range(len(myarray)):
        print("%d"% myarray[k])




if __name__=="__main__":
    demoArray= [ 270, 881, 818, 22, 273, 581, 891, 1123, 2111, 
    411, 5153, 8229, 34144, 43233, 53775, 610 ]
    selectionSortAlgo(demoArray)
