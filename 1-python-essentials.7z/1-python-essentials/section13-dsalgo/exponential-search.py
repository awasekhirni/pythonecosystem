"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#exponential search 
# this works in O(Log n)time 

# Python program to find an element x 
# in a sorted array using Exponential Search 
  
# A recurssive binary search function returns  
# location  of x in given array arr[l..r] is  
# present, otherwise -1 
def binarySearch( arr, l, r, x): 
    if r >= l: 
        mid = l + ( r-l ) / 2
          
        # If the element is present at  
        # the middle itself 
        if arr[mid] == x: 
            return mid 
          
        # If the element is smaller than mid,  
        # then it can only be present in the  
        # left subarray 
        if arr[mid] > x: 
            return binarySearch(arr, l,  
                                mid - 1, x) 
          
        # Else he element can only be 
        # present in the right 
        return binarySearch(arr, mid + 1, r, x) 
          
    # We reach here if the element is not present 
    return -1
  
# Returns the position of first 
# occurence of x in array 
def exponentialSearch(arr, n, x): 
    # IF x is present at first  
    # location itself 
    if arr[0] == x: 
        return 0
          
    # Find range for binary search  
    # j by repeated doubling 
    i = 1
    while i < n and arr[i] <= x: 
        i = i * 2
      
    # Call binary search for the found range 
    return binarySearch( arr, i / 2,  
                         min(i, n), x) 


if __name__=="__main__":
    sample_array=[ 270, 881, 818, 22, 273, 581, 891, 1123, 2111, 
    411, 5153, 8229, 34144, 43233, 53775, 610 ]
    s_s_arr=sorted(sample_array)
    n = len(s_s_arr) 
    x = 891
    result = exponentialSearch(s_s_arr, n, x) 
    if result == -1: 
        print("element is not present in the array")
    else: 
        print("Element is present at index %d" %(result)) 