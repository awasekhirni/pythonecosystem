"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#Bubble Sort 
# A sorting algorithm that works by repeatedly swapping the adjacent elements if they are in wrong order 
#steps compares first two eleements and waps them in increasing order 
# repeat these steps until the last element 

def myBubbleSort(myarray):
    tnl=len(myarray)
    outerloop=0
    innerloop=0
    while outerloop <tnl:
        innerloop=outerloop+1
        while innerloop<tnl:
            if myarray[outerloop]<myarray[innerloop]:
                myarray[outerloop],myarray[innerloop]=myarray[innerloop],myarray[outerloop]
            innerloop=innerloop+1
        print(myarray)
        outerloop=outerloop+1 

        
    

if __name__=="__main__":
    demoArray=[ 270, 881, 818, 22, 273, 581, 891, 1123, 2111, 
    411, 5153, 8229, 34144, 43233, 53775, 611 ]
    myBubbleSort(demoArray)
  