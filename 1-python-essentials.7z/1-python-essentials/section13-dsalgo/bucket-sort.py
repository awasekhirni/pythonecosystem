"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#BUCKET SORT 
# mainly useful when input is uniformly distributed over a range. 
#bucketSort(myarray[],n)
# create n empty buckets or lists 
# for every array in element array 
# -- insert array[i] into bucket[n*array[i]]
## sort individual buckets using insertion sort 
## concatenate all sorted buckets 

# Python3 program to sort an array 
# using bucket sort 
def insertionSortAlgo(b): 
	for i in range(1, len(b)): 
		up = b[i] 
		j = i - 1
		while j >=0 and b[j] > up: 
			b[j + 1] = b[j] 
			j -= 1
		b[j + 1] = up	 
	return b	 
			
def bucketSortAlgo(x): 
	arr = [] 
	slot_num = 10 # 10 means 10 slots, each 
				# slot's size is 0.1 
	for i in range(slot_num): 
		arr.append([]) 
		
	# Put array elements in different buckets 
	for j in x: 
		index_b = int(slot_num * j) 
		arr[index_b].append(j) 
	
	# Sort individual buckets 
	for i in range(slot_num): 
		arr[i] = insertionSortAlgo(arr[i]) 
		
	# concatenate the result 
	k = 0
	for i in range(slot_num): 
		for j in range(len(arr[i])): 
			x[k] = arr[i][j] 
			k += 1
	return x 

if __name__=="__main__":
    myarray=[0.543, 0.861, 0.636, 
	0.124, 0.165, 0.6734,0.7842] 
    print("Sorted Array post processing is :")
    print(bucketSortAlgo(myarray))
