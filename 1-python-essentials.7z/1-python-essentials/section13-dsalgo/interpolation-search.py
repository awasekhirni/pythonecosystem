"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#interpolation search 
# it is an improvement over binary search 
#linear search -O(n) time 
#jump search -O(Root n) time 
#Binary Search -O(Log n) time 
#unlike binary search which goes the middle element to check, interpoation search may go to different locations according to the value of the key being search. 

#interpolation search formula 
#element_position = lo + [ (x-arr[lo])*(hi-lo) / (arr[hi]-arr[Lo]) ]

#arr[] ==> Array where elements need to be searched
#x     ==> Element to be searched
#lo    ==> Starting index in arr[]
#hi    ==> Ending index in arr[]

def myInterpolationSearchAlgo(arr, n, x): 
	# Find indexs of two corners 
	lo = 0
	hi = (n - 1) 
 
	while lo <= hi and x >= arr[lo] and x <= arr[hi]: 
		# Probing the position with keeping 
		# uniform distribution in mind. 
		pos = lo + int(((float(hi - lo) /
			( arr[hi] - arr[lo])) * ( x - arr[lo]))) 

		# Condition of target found 
		if arr[pos] == x: 
			return pos 

		# If x is larger, x is in upper part 
		if arr[pos] < x: 
			lo = pos + 1; 

		# If x is smaller, x is in lower part 
		else: 
			hi = pos - 1; 
	
	return -1

if __name__=="__main__":
    sample_array=[ 270, 881, 818, 22, 273, 581, 891, 1123, 2111, 
    411, 5153, 8229, 34144, 43233, 53775, 610 ]
    s_s_arr=sorted(sample_array)
    n=len(s_s_arr)
    #element to find in the array 
    finderx=8229
    fetchindex=myInterpolationSearchAlgo(s_s_arr,n,finderx)
    if fetchindex !=-1:
        print("the element you are finding is @",fetchindex)
    
    else:
        print("the element is not found in the array")



