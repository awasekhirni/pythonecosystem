"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#mergesort demo 
# similar to quicksort algo
# based on divide and conquer 
# divides and myarrayay into two halves and calls itselfs for the two halves and then merges the two sorted halves 
#MergeSort(myarray[], l,  r)
# If r > l
#    1. Find the middle point to divide the myarrayay into two halves:  
#            middle m = (l+r)/2
#     2. Call mergeSort for first half:   
#            Call mergeSort(myarray, l, m)
#     3. Call mergeSort for second half:
#             Call mergeSort(myarray, m+1, r)
#     4. Merge the two halves sorted in step 2 and 3:
#             Call merge(myarray, l, m, r)

# Python program for implementation of MergeSort 
def mergeSortAlgo(myarray): 
	if len(myarray) >1: 
		mid = len(myarray)//2 #Finding the mid of the myarray
		L = myarray[:mid] # Dividing the myarray elements 
		R = myarray[mid:] # into 2 halves 

		mergeSortAlgo(L) # Sorting the first half 
		mergeSortAlgo(R) # Sorting the second half 

		i = j = k = 0
		
		# Copy data to temp myarrays L[] and R[] 
		while i < len(L) and j < len(R): 
			if L[i] < R[j]: 
				myarray[k] = L[i] 
				i+=1
			else: 
				myarray[k] = R[j] 
				j+=1
			k+=1
		
		# Checking if any element was left 
		while i < len(L): 
			myarray[k] = L[i] 
			i+=1
			k+=1
		
		while j < len(R): 
			myarray[k] = R[j] 
			j+=1
			k+=1

# Code to print the list 
def printList(myarray): 
	for i in range(len(myarray)):		 
		print(myarray[i],end=" ") 
	print() 

# driver code to test the above code 
if __name__ == '__main__': 
	demoArray = [ 270, 881, 818, 22, 273, 581, 891, 1123, 2111, 
    411, 5153, 8229, 34144, 43233, 53775, 610 ]
	
	printList(demoArray) 
	mergeSortAlgo(demoArray) 
	
	printList(demoArray) 


