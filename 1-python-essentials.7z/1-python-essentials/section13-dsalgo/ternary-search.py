"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#TernarySearch Algorithm 

def myTernarySearchAlgo(L, key):
    left = 0
    right = len(L) - 1
    while left <= right:
        ind1 = left
        ind2 = left + (right - left) // 3
        ind3 = left + 2 * (right - left) // 3
        if key == L[left]:
            print("Key found at:" + str(left))
            return
        elif key == L[right]:
            print("Key found at:", str(right))
            return
        elif key < L[left] or key > L[right]:
            print("Unable to find key")
            return
        elif key <= L[ind2]:
            right = ind2
        elif key > L[ind2] and key <= L[ind3]:
            left = ind2 + 1
            right = ind3
        else:
            left = ind3 + 1
    return -1


if __name__=="__main__":
    demoarray=[ 270, 881, 818, 22, 273, 581, 891, 1123, 2111, 
    411, 5153, 8229, 34144, 43233, 53775, 610 ]
    s_demo=sorted(demoarray)
    print(s_demo)
    elem_to_find=891
    myTernarySearchAlgo(s_demo,elem_to_find)
    