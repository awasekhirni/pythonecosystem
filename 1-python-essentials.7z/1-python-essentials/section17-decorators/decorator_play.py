"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

def makeup_decorator(func):
    def msg_wrapper():
        print("pre-function processing")
        func()
        print("post-function processing")
    return msg_wrapper 


@makeup_decorator
def test_deco():
    print("basic demo using decorators in python")

#executing 
test_deco()


####example2 

def escape_unicode(f):
    def wrap(*args,**kwargs):
        x=f(*args,**kwargs)
        return ascii(x)
    
    return wrap 


@escape_unicode 
def city_name():
    return 'Bangal$re weather is pleasant all around the year'


#executing 
city_name()

#passing arguments to decorators 
def tags(tag_name):
    def tags_decorator(func):
        def func_wrapper(name):
            return "<{0}>{1}</{0}>".format(tag_name, func(name))
        return func_wrapper 
    return tags_decorator 

@tags("p")
def get_text(name):
    return "Hello"+name


#execution 
print(get_text("Syed Awase"))


#array out of index decorator
array=['syed awase','syed ameese','syed azeez','syed rayyan']
def outofindex_notify(func):
    def newvalueof(pos):
        if pos>=len(array):
            print("The Array index is out of range")
            return 
        func(pos)
    return newvalueof 

@outofindex_notify 
def myvalue(index):
    print(array[index])

#execution 
myvalue(100)


#uppercase decorator 
def uppercase(func):
    def upperwrap():
        original_result=func()
        modified_result = original_result.upper()
        return modified_result
    return upperwrap 

@uppercase 
def messageme():
    return "syed awase"

#execution 
messageme()


#applying multiple decorators to a single function 
def strong(func):
    def wrapper():
        return '<strong>' + func() + '</strong>'
    return wrapper

def emphasis(func):
    def wrapper():
        return '<em>' + func() + '</em>'
    return wrapper


@strong
@emphasis 
def messagehim():
    return 'Syed Ameese'

#execution 
messagehim()


#decorator function with arguments
def trace(func):
    def wrapper(*args, **kwargs):
        print(f'TRACE: calling {func.__name__}() '
              f'with {args}, {kwargs}')

        original_result = func(*args, **kwargs)

        print(f'TRACE: {func.__name__}() '
              f'returned {original_result!r}')

        return original_result
    return wrapper


@trace
def say(name, line):
    return f'{name}: {line}'

say('Jane', 'Hello, World')


import time

def timing_function(some_function):
    def wrapper():
        t1=time.time()
        some_function()
        t2=time.time()
        print("Time taken to run the function"+ str((t2-t1))+"\n")
    return wrapper 


@timing_function 
def other_function():
    testlist=[]
    for item in (range(0,10000)):
        testlist.append(item)
    print("\n Sum of all the numbers:"+str((sum(testlist))))



#executing 
other_function()