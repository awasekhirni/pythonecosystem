"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#python conditional statements and loops

#objective one to take a number as input and check if the numbers are divisible 
#by it and multiples of it between 2000 and 3000
    
myNomero= int(input("please enter the number"))
listofNumber=[]
for x in range(2000, 3000):
    if(x%myNomero==0): 
        listofNumber.append(str(x))
    print(','.join(listofNumber))


#converting temperature from celsium to fahrenheit
#C = (5/9) * (F - 32)
temp = input("Input the  temperature you like to convert? (e.g., 45F, 102C etc.) : ")
degree = int(temp[:-1])
i_convention = temp[-1]

if i_convention.upper() == "C":
  result = int(round((9 * degree) / 5 + 32))
  o_convention = "Fahrenheit"
elif i_convention.upper() == "F":
  result = int(round((degree - 32) * 5 / 9))
  o_convention = "Celsius"
else:
  print("Input proper convention.")
  quit()
print("The temperature in", o_convention, "is", result, "degrees.")

#print the following pattern 


n=5;
for i in range(n,0,-1):
  for j in range(i):
    print('*',end='')
  print('')
for i in range(n):
  for j in range(i):
    print('*',end='')
  print(' ')

# check whether a word is a palindrome 
# GADAG, NEVER ODD OR EVEN ,Madam, I'm Adam
#redivider, deified, civic, radar, level, rotor, kayak, reviver, racecar, redder, madam, and refer. 
myword=input('please input a word and lets check if it is a palindrome:')
for char in range(len(myword) -1,-1,-1):
  for mychar in range(0,len(myword)-1,1):
    if(myword[mychar]==myword[char]):
      print(myword[char] +" " +myword[mychar])
print('\n')


# write a program to identify even and odd nos
starting_no=int(input('please enter the startingno:'))
ending_no=int(input('please enter the endingno:'))
counter_odd=0
counter_even=0
for x in range(starting_no, ending_no, 1):
    if not x%2:
      counter_even+=1
      print('even no:',x)
    else:
      counter_odd+=1
      print('odd no:',x)
print("number of even numbers:",counter_even)
print("number of odd numbers:",counter_odd)


#looping and combining two lists 
sunday_stock=[11,14,15,12,13,14,15,16,18,21,27]
monday_stock=[21,26,28,23,22,21,21,21,19,18,16]

for item in zip(sunday_stock,monday_stock):
  print(item)

tuesday_stock=[16,19,25,22,23,24,25,26,28,24,27]

for item in zip(sunday_stock, monday_stock, tuesday_stock):
  print(item)

stock_prices=[sunday_stock,monday_stock,tuesday_stock]

from pprint import pprint as pp
pp(stock_prices)