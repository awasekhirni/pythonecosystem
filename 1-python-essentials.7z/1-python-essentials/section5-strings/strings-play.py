"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

# python strings code play

import textwrap
myset_chars = ['s', 'y', 'e', 'd']
mystrings = ''.join(myset_chars)
print(mystrings)


def appendify(str1):
    length = len(str1)

    if length > 3:
        if str1[-1:] == 'y':
            str1 += 'ly'
        elif str1[-1:] == 'n':
            str1 += "ing"
        else:
            str1 += 'est'

    return str1


print(appendify('happy'))
print(appendify('train'))
print(appendify('strong'))


# identify negative sentiment in sentences

def negative_sample(sentence):
    snot = sentence.find('not')
    sdont = sentence.find('do not')

    if (sdont > 0 or snot > 0):
        return " this is a negative statement"
    else:
        return "positive statement"


mystatement = "I love to do exciting things"
mynegstate = "I do not like to drink"

print(negative_sample(mystatement))
print(negative_sample(mynegstate))


# extract part of the sentence or word based on a pattern
myurl = "https: // www.enchantedlearning.com/word-list/negative_words.shtml"

mywordone = myurl.rsplit('_', 1)[0]
mywordtwo = myurl.rsplit('-', 1)[0]
mywordthree = myurl.rsplit('-', 1)[1]
print(mywordone)
print(mywordtwo)
print(mywordthree)


# remove the nth index character from a nonempty string
def remove_character(str, n):
    first_part = str[:n]
    last_part = str[n + 1:]
    return first_part + last_part


print(remove_character('Assaignment', 3))

# exchanging the first and the last characters in a given string


def swap_firstlast(stre):
    return stre[-1:]+stre[1:-1]+stre[:1]


print(swap_firstlast("funk"))


# remove the characters of odd or even index values based on user's input

def remove_byindexposition(str, idx):
    eresult = ""
    oresult = ""
    if idx == "e":
        for i in range(len(str)):
            if i % 2 == 0:
                eresult = eresult + str[i]
            else:
                oresult = oresult+str[i]
    return eresult, oresult


print(remove_byindexposition("abcdefghijklmnop", 'e'))


# checking whether a string starts with a specific set of characters
company_id = "UN1234321991238123"
print(company_id.startswith("UN"))  # returns boolean value

#reverse string
def reverse_mystring(str1):
    return ''.join(reversed(str1))

print(reverse_mystring("abcdef"))



# display formatted text with a specified width as output -using textwrap package
context_text = """Though the debates surrounding military drone strikes are far from over, 2013 saw a new issue rise: unmanned aerial vehicles (UAVs) in US airspace.This year, the FAA slowly moved ahead with plans to regulate domestic drone flight by 2015, approving the first commercial UAVs and accepting bids for a handful of test sites around the country. Companies, meanwhile, began work on drone-related services even before approval: Amazon made waves late in the year by announcing plans for half-hour, door-to-door delivery service by octocopter. Drones also became a common tool for public services, used by firefighters and police for surveillance, reconnaissance, and search-and-rescue operations. Of course, these developments weren’t without controversy: critics pushed for strong privacy protections to accompany the FAA’s other UAV rules, and several states passed laws regulating how police and private citizens could gather and use drone footage. """

print(textwrap.fill(context_text, width=40))
# printing text without any indentation
print(textwrap.dedent(context_text))
# adding prefix wrapping to the text
ident = textwrap.dedent(context_text)
wrap_result = textwrap.fill(ident, width=40)
final_result = textwrap.indent(wrap_result, "%%")
print(final_result)

