"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#CONTEXT MANAGER API 

#utilities for creating and working with context managers 
# contextlib module contains utilities for working with context managers and the with statement 

# a context manager is responsible for a resource within a code bloc, possibly creating it when the block is entered and then clearning it up after the block is exited. 
