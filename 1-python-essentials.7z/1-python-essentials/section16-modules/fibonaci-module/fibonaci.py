"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#!/usr/bin/python
# fibonacci numbers module

# write fibonacci series upto n


def fibOne(n):
    a, b = 0, 1
    while b < n:
        print(b, end='')
        a, b = b, a+b
    print()

# return Fibonacci series upto n


def fibTwo(n):
    result = []
    a, b = 0, 1
    while b < n:
        result.append(b)
        a, b = b, a + b
    return result


def sayHello():
    return "Hello! Syed Awase I love you!!"
