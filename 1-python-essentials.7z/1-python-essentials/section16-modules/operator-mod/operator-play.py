"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#OPERATOR MODULE
import operator 

a=1 
b=10 
#not_ includes the trailing underscore because not is a python keyword 
#truth applies the same logic used when testing an expression in an if statement or converting an expression to a bool 
# is_() implements the same check used by the is keyword 
# is_not() does the same test and returns the opposite answer 

print('not_(a):',operator.not_(a))
print('not_(a):',operator.truth(a))
print('is_(a,b):',operator.is_(a,b))
print('is_not(a,b):',operator.is_not(a,b))


#comparison operators 
#all of the rich comparison operators are supported 

for func in(operator.lt, operator.le,operator.eq,operator.ne,operator.ge,operator.gt):
    print('{}(a, b): {}'.format(func.__name__, func(a, b)))


#arithmetic operators 
#the arithmetic operators for manipulating numerical values are also supported 

print('abs(a):',operator.abs(a))
print('neg(a):',operator.neg(a))
print('neg(a):',operator.neg(b))
print('pos(a):',operator.pos(a))
print('add(a):',operator.add(a,b))
print('floordiv(a):',operator.floordiv(a,b))
print('mod(a):',operator.mod(a,b))
print('pow(a):',operator.pow(a,b))
print('sub(a):',operator.sub(a,b))
print('truediv(a):',operator.truediv(a,b))

#bitwise operations 
print('and_(a):',operator.and_(a,b))
#print('invert(a):',operator.invert(a,b))#
print('lshift(a):',operator.lshift(a,b))

print('or_(a):',operator.or_(a,b))
print('rshift(a):',operator.rshift(a,b))
print('xor(a):',operator.xor(a,b))


#sequence operators 
# the operators for working with sequences can be divided into four groups 
# 1. building up sequences 
# 2. searching for items
# 3. accessing contents 
# 4. removing items from sequences 

import operator 
a=[126,383,321,837,839]
b=['a','b','c','d','e']

print("concat operation(a,b):",operator.concat(a,b))
print("contains operation(a,no):",operator.contains(a,321))
print("count occurence operation(a,no):",operator.countOf(a,321))
print("fetch indexof(a,no):",operator.indexOf(a,321))

print('\nAccess Items:')
print('  getitem(b, 1):',operator.getitem(b, 1))
print('  getitem(b, slice(1, 3)):', operator.getitem(b, slice(1, 3)))
print('  setitem(b, 1, "d") :', end=' ')
operator.setitem(b, 1, "d")
print(b)
print('  setitem(a, slice(1, 3), [4, 5]):', end=' ')
operator.setitem(a, slice(1, 3), [4, 5])
print(a)

print('\nDestructive:')
print('  delitem(b, 1)          :', end=' ')
operator.delitem(b, 1)
print(b)
print('  delitem(a, slice(1, 3)):', end=' ')
operator.delitem(a, slice(1, 3))
print(a)


#############################################
#Inplace operators 
# in addition to the standard operators, many types of objects support "in-place " modifications through special operators such as +=.

import operator 

a=-123
b=34.0 
c=[1123,3422,3433,228]
d=['mango','grape','guava','orange']

#inplace operation iadd 
x=operator.iadd(a,b)
print("iadd operation", x)

y=operator.iconcat(c,d)
print("iconcat operation",y)


