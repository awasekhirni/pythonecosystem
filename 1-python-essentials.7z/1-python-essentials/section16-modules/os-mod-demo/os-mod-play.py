"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#!/usr/bin/python
# os module for python
import os

print(os.name)

# getting the current working directory
mycwd = os.getcwd()
print(mycwd)

# to print the absolute path on your system
os.path.abspath('.')

# to print files and directories in the current directory
os.listdir('.')

try:
    # If the file does not exist,
    # then it would throw an IOError
    filename = 'sak.txt'
    f = open(filename, 'rU')
    text = f.read()
    f.close()

# Control jumps directly to here if
# any of the above lines throws IOError.
except IOError:

    # print(os.error) will <class 'OSError'>
    print('Problem reading: ' + filename)

# In any case, the code then continues with
# the line after the try/except


# os.popen()- method opens a pipe to or from a command
# the return value can be read or written depending on whether mode is r or w

fs = 'sak.txt'
# popen() is similar to open()
file = open(fs, 'w')
file.write('Hello')
file.close()
file = open(fs, 'r')
text = file.read()
print(text)

# popen() provides a pipe/gateway
file = os.popen(fs, 'w')
file.write('Hello Syed Awase')


# os.close - close file descriptor fd
# a file opened using open(), cna be closed by close() only.
# but file opened through os.popen() can be closed with close() or os.close()

fe = "sak.txt"
file_new = open(fe, 'r')
text = file_new.read()
print(text)
os.close(file_new)

# a file sak.txt can be renamed to syedawase.txt using the function os.rename()
golu = "sak.txt"
os.rename(golu, 'sak_new.txt')


# directory os
dir(os)
for k in dir(os):
    print(k)

# access(path,mode)
 # os.F_OK-Found
 # os.R_OK-Readable
 # os.W_OK-Writable
 # os.X_OK-Executable

# change the directory
os.chdir('C:\\Users\\syedawase\\Desktop')
os.access('sak.txt', os.R_OK)
os.access('sak.txt', os.F_OK)
os.access('sak.txt', os.W_OK)
os.access('sak.txt', os.X_OK)

# chflags set path flags to the numeric flags.
# os.UF_NODUMP – Don’t dump the file
# os.UF_IMMUTABLE − You may not change the file
# os.UF_APPEND − You may only append to the file
# os.UF_NOUNLINK – You may not rename or delete the file
# os.UF_OPAQUE − The directory is opaque when we view it through a union stack
# os.SF_ARCHIVED – You may archive the file
# os.SF_IMMUTABLE – You may not change the file
# os.SF_APPEND – You may only append to the file
# os.SF_NOUNLINK – You may not rename or delete the file
# os.SF_SNAPSHOT − It is a snapshot file

#os.chflags('sak.txt', os.SF_NOUNLINK)

# chown(path,uid,gid)
#os.chown("sak_new.txt", 100, -1)

# chroot python os module alters the current process root directory to the given path
# os.chroot("/myphotos")

# close(fd)- closes the associated file with descriptor fd
fed = os.open("sak_new.txt", os.O_RDWR)
os.close(fed)

# closerange(fd_low,fd_high) -
fedy = os.open('sak_renew.txt', os.O_RDWR)
os.write(fedy, "Testing")
os.closerange(fedy, fedy)

# duplicate - returns a duplicate of the file descriptor
# dup(fd)
fred = os.open("syedawase.txt", os.O_RDWR)
d_fred = os.dup(fred)
os.write(d_fred, "Testing")
os.closerange(fred, d_fred)

# dup2(fd,fd2) => duplicates the descriptor fd to fd2
frexy = os.open("syed-azeez.txt", os.O_RDWR)
os.write(frexy, "Testing")
frexy2 = 1000
os.dup2(frexy, frexy2)
os.lseek(frexy2, 0, 0)
str = os.read(frexy2, 100)
print(f"Read string is {str}")
os.close(frexy)


# fchdir() alters the current working directory to the directory that the file descriptor fd represents
os.chdir('/var/www/sak/html')
print("Current Working direactory is: %s" % os.getcwd())
billo = os.open("/tmp", os.O_RDONLY)
os.fchdir(billo)
print("Current working dir:%s" % os.getcwd())
os.close(billo)

# fchown(fd,uid,gid)
# fchown() alters the owner and the group id of the file specified by fd to the numeric uid and gid
# setting an id -1 leaves it unchanged 
betty = os.open("/tmp", os.O_RDONLY)
os.fchown(betty,100, -1)
os.fchown(betty, -1, 50)
print("Changed ownership successfully")
os.close(betty)

#fdatasync(fd)
# forces writing the file with filedescriptor fd to disk 

myfy=os.open("babu.txt", os.O_RDWR)
os.write(myfy, "Lets go for holiday")
os.fdatasync(myfy)

os.lseek(myfy, 0, 0)
xstr=os.read(myfy,100)
print(f"Read String is {xstr}")
os.close(myfy)

#retrieve file information
compfile=os.open('compfile-sak.txt',os.O_RDWR)
fileinfo=os.fstat(compfile)
print(f"File Info: {fileinfo}")
print(f"UID of the file:{fileinfo.st_uid}")
print(f"GID of the file:{fileinfo.st_gid}")
print("id of the device containg the file:", fileinfo.st_dev)
print("inode number:", fileinfo.st_ino)
print("protection",fileinfo.st_mode)
print("number of hard links", fileinfo.st_nlink)
print("total size in bytes", fileinfo.st_size)
print("blocksize for filesystemI/o",fileinfo.st_blksize)
print("total size in bytes:", fileinfo.st_size)
print("number of blocks allocated", fileinfo.st_blocks)
print("time of last access", fileinfo.st_atime)
print("time of last modification", fileinfo.st_mtime)
print("time of the last status change", fileinfo.st_ctime)


#information pertaining to the file system containing the file linked with file descriptor
otherfile = os.open("Nuos_file.txt", os.O_RDWR)
ofo = os.fstatvfs(otherfile)
print("File Info", ofo)
print("Maximum file length is:", ofo.f_namemax)
print("Freeblocks:", ofo.f_namemax)
print("free blocks:", ofo.f_bfree)
print("file system block size:",ofo.f_bsize)
print("fragment size:",ofo.f_frsize)
print("size of fs in f_frsize units", ofo.f_blocks)
print("free blocks for non-root",ofo.fbavail)
print("inodes",ofo.f_files)
print("free inodes", ofo.f_ffree)
print("free inodes for non-root", ofo.f_favail)
print("file system id:",ofo.f_fsid)
print("mount flags:", ofo.f_flag)
print("maximum filename length:", ofo.f_namemax)
os.close(otherfile)


#fsync(fd)
#forcefully writing to a file using file descriptor 

fedx=os.open("store-sak.txt",os.O_RDWR)
os.write(fedx,"syed's storefile")
os.fsync(fedx)
os.lseek(fedx,0,0)
mystring=os.read(fedx,100)
print("Read string is:{mystring}")
os.close(fedx)

#altering the ownership and group id of the path 
webpath="/var/www/html/sak-on.txt"
webdex=os.open(webpath,os.O_RDWR)
os.close(webdex)
os.lchown(webpath,500,-1)
os.lchown(webpath,-1,500)


#link will create a hard link that points to an src named destination
op="/var/www/html/"
md=os.open(op,os.O_RDWR)
os.close(md)
dst = '/tmp/sak_notes.txt'
os.link(op, dst)

#list holding the names of the entries in the directory at the path
urpath="/var/www/html/"
dirs = os.listdir(urpath)
for file in dirs:
    print(file)

#device information
store_path = "/var/www/html/sak_new.txt"
xinfo = os.lstat(store_path)
major_dnum = os.major(xinfo.st_dev)
minor_dnum=os.minor(xinfo.st_dev)
print("major device number is:", major_dnum)
print("minor device number is:", minor_dnum)
#create a raw device number
dev_num = os.makedev(major_dnum, minor_dnum)
print("device number:",dev_num)


#to create a directory recursively  
usrpath="/tmp/home/monthly/daily"
os.makedirs(usrpath,0755)

#to open a pseudo-terminal pair 
m,s=os.openty()
print(m)
print(s)
s=os.ttyname(s)
print(m)
print(s)

#pipe()creates a pipe 
os.pipe()

# to create a symbolic link destination points to the source
mysrc="/usr/bin/python"
mydst="/sak/python"
os.symlink(mysrc,mydst)


#temporary file object 
mytmp=os.tmpfile()
mytmp.write("Temporary new file is here")
mytmp.seek(0)
print(mytmp.read())
mytmp.close()
# to create a temporary path name to create a new temporary file 
tmpfn=os.tmpnam()
print("this is a unique path:",tmpfn)







