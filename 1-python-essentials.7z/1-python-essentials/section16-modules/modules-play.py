import sys
"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""


# listing modules
help("modules")


# sys module
sys.version

dir(sys)

for i in dir(sys):
    print(i)


#builtin modules

import builtins 
dir(builtins)

for j in dir(builtins):
    print(j)



