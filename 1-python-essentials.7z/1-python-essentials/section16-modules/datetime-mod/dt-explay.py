"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#comparing two dates in python
from datetime import datetime, timedelta 
mypast = datetime.now()-timedelta(days=1)
mypresent=datetime.now()
mypast<mypresent 
datetime(3000,1,1) <mypresent 
mypresent -datetime(2000,4,4)
datetime.timedelta(4232,4749,2992)


# using MINYEAR to print minimum representable year 
print ("Minimum representable year is : ",end="") 
print (datetime.MINYEAR) 
  
# using MAXYEAR to print maximum representable year 
print ("Maximum representable year is : ",end="") 
print (datetime.MAXYEAR) 


# using date() to represent date 
print ("The represented date is : ",end="") 
print (datetime.date(1997,4,1)) 
  
# using today() to print present date 
print ("Present date is : ",end="") 
print (datetime.today()) 


# using fromtimestamp() to calculate date 
print ("The calculated date from seconds is : ",end="") 
print (datetime.fromtimestamp(3452435)) 
  
# using min() to print minimum representable date 
print ("Minimum representable date is : ",end="") 
print (datetime.min) 
  
# using max() to print minimum representable date 
print ("Maximum representable date is : ",end="") 
print (datetime.max) 


#####################
import calendar 

mycal = calendar.TextCalendar(calendar.SUNDAY)
mycal.prmonth(2013,2)

mycal_monday = calendar.TextCalendar(calendar.MONDAY)
mycal_monday.prmonth(2013,2)


#######################
import calendar 
import pprint 

thirt_cal=calendar.Calendar(calendar.SUNDAY)

thirt_cal_data = thirt_cal.yeardays2calendar(2013,3)
print("len(thirt_cal_data):",len(thirt_cal_data))

cal=calendar.TextCalendar(calendar.SUNDAY)
print(cal.formatyear(2013,2,1,1,3))


###################################

#compute the second saturday 
import calendar 
import sys

year = 2013
#show every month 
for month in range(1,13):
    ct=calendar.monthcalendar(year,month)
    first_week=ct[0]
    second_week=ct[1]
    third_week=ct[2]

    if first_week[calendar.SATURDAY]:
        meeting_date=second_week[calendar.SATURDAY]
    else:
        meeting_date=third_week[calendar.SATURDAY]


print('{:>3}: {:>2}'.format(calendar.month_abbr[month],meeting_date))

############################
import datetime

print('Earliest  :', datetime.time.min)
print('Latest    :', datetime.time.max)
print('Resolution:', datetime.time.resolution)

#######################################
import datetime

today = datetime.date.today()
print(today)
print('ctime  :', today.ctime())
tt = today.timetuple()
print('tuple  : tm_year  =', tt.tm_year)
print('         tm_mon   =', tt.tm_mon)
print('         tm_mday  =', tt.tm_mday)
print('         tm_hour  =', tt.tm_hour)
print('         tm_min   =', tt.tm_min)
print('         tm_sec   =', tt.tm_sec)
print('         tm_wday  =', tt.tm_wday)
print('         tm_yday  =', tt.tm_yday)
print('         tm_isdst =', tt.tm_isdst)
print('ordinal:', today.toordinal())
print('Year   :', today.year)
print('Mon    :', today.month)
print('Day    :', today.day)

########################################
import datetime
import time

o = 733114
print('o               :', o)
print('fromordinal(o)  :', datetime.date.fromordinal(o))

t = time.time()
print('t               :', t)
print('fromtimestamp(t):', datetime.date.fromtimestamp(t))

################################################
import datetime

today = datetime.date.today()
print('Today    :', today)

one_day = datetime.timedelta(days=1)
print('One day  :', one_day)

yesterday = today - one_day
print('Yesterday:', yesterday)

tomorrow = today + one_day
print('Tomorrow :', tomorrow)

print()
print('tomorrow - yesterday:', tomorrow - yesterday)
print('yesterday - tomorrow:', yesterday - tomorrow)


#################
import datetime

format = "%a %b %d %H:%M:%S %Y"

today = datetime.datetime.today()
print('ISO     :', today)

s = today.strftime(format)
print('strftime:', s)

d = datetime.datetime.strptime(s, format)
print('strptime:', d.strftime(format))


######################################
import datetime

min6 = datetime.timezone(datetime.timedelta(hours=-6))
plus6 = datetime.timezone(datetime.timedelta(hours=6))
d = datetime.datetime.now(min6)

print(min6, ':', d)
print(datetime.timezone.utc, ':',
      d.astimezone(datetime.timezone.utc))
print(plus6, ':', d.astimezone(plus6))

# convert to the current system timezone
d_system = d.astimezone()
print(d_system.tzinfo, '      :', d_system)