#!/usr/bin/env python3
import urllib.robotparser
from urllib.parse import urlparse
import urllib.parse
from urllib.request import urlopen
"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

# pip install urllib3

# urllib module in python3 allows you access websites via python porgram.

# used to make requests
import urllib.request

x = urllib.request.urlopen('http://www.territorialprescience.com')
print(x.read())


# reading a file from the web and printing its contents
with urlopen('https://raw.githubusercontent.com/awasekhirni/ghalib/master/shayari.txt') as story:
    story_words = []
    for line in story:
        line_words = line.decode('utf-8').split()
        for word in line_words:
            story_words.append(word)

for word in story_words:
    print(word)


# used to parse values into the url

url = 'https://www.google.com/search'
values = {'q': 'syed awase '}


# urlib.request
# urllib.error
# urllib.parse
# urllib.rebotparser

gurl = urllib.request.urlopen('https://www.google.com/')
ginfo = gurl.info()
print(ginfo)
header = ginfo
header.as_string()
gurl.getcode()


# downloading a file
url = 'https://github.com/awasekhirni/.NetCORE/raw/master/IdentityServer4.Quickstart.UI-release.zip'
response = urllib.request.urlopen(url)
data = response.read()
with open('IdentityServer4.Quickstart.UI-release.zip', 'wb') as fobj:
    fobj.write(data)
# #alternative approach
# tmp_file,header=urllib.request.urlretrieve(url)
# with open('otherfile.zip','wb')as fobj:
#     with open(tmp_file,'rb') as tmp:
#         fobj.write(tmp.read())
# #another way
# urllib.request.urlretrieve(url,'alt.zip')


# #specifying user agent
# import urllib.request
# user_agent = 'Mozilla/5.0 (X11;Ubunti; Linux x86_64;rv:47.0 Gecko/201000101 Firefox/47.0'
# url='http://www.territorialprescience.com'
# headers = {'User=Agent': user_agent}
# request = urllib.request.Request(url, headers=headers)
# with urllib.request.urlopen(request) as response:
#     with open('useragent.html', 'wb') as out:
#         out.write(response.read())


# urllib.parse
result = urlparse("https://duckduckgo.com/?q=syed+awase&canonical&ia=qa")

# submitting a web form
data = urllib.parse.urlencode({'q': 'faiz ahmed faiz'})
url = 'http://duckduckgo.com/html/'
full_url = url + '?' + data
response = urllib.request.urlopen(full_url)
with open('result.html', 'wb') as f:
    f.write(response.read())


# urllib.robotparser
robot = urllib.robotparser.RobotFileParser()
robot.set_url('http://arstechnica.com/robots.txt')
robot.read()
robot.can_fetch('*', 'http://arstechnica.com/')
robot.can_fetch('*', 'http://arstechnica.com/cgi-bin/')
