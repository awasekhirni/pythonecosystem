"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

##################
#ITERTOOLS MODULE 

#Itertools module provides many convenient functions for working with iterators. 

#functions that create or operate on iterators 
#count() returns an infinite counter 
# similar to infinite range()

import itertools 

for i in itertools.count(start=10,step=-1):
    if not i:
        break 
    print(i)
    


#cycle() loops an iterator infinitely 

s="hello, you fool i love you, come on enjoy the joy ride"
for j, ch in enumerate(s):
    print(j,ch)

#using cycle() 

for k, ch in zip(range(40),itertools.cycle(s)):
    print(k,ch)


#repeat() creates an infinite iterator from a single element 

mysentence="Sycliq builds systems for crop life cycle intelligence"

for i, mysentence in zip(range(20),itertools.repeat(mysentence)):
    print(i,mysentence)



#chain() links multiple tail to head 
#flat list of multiple lists by linking 
#used often for flattening multiple lists 
for e in itertools.chain('chain kuli','ki main kuli','ki chain'):
    print(e)


#functions to select and group iterator elements

#compress() filters an iterator based on a list of selectors. 
#selectors can be any values that evaluate to boolean True or False 

import itertools
products='stapler','monitor','office table','grinder','carromboard','badminton racket','shoes'
selector=True,True,True,False, True,False, True 
for cartItem in itertools.compress(products,selector):
    print(cartItem)



#takewhile() takes elements while a criterion is satisfied. 

for k in itertools.takewhile(lambda x:x<10, itertools.count()):
    print(k)


#dropwhile() does the opposite, it skips elements while a criterion is satisfied. 
for i in itertools.dropwhile(lambda x:x<5, itertools.count()):
    if i>10:
        break 
    print(i)

#groupby() allows us to split an iterator into multiple iterators based on a grouping key, groups have to be consecutive
is_even=lambda x:not x%2

for e,g in itertools.groupby(sorted(range(10),key=is_even),key=is_even):
    print(e,list(g))


#combinatorial functions 
#product() returns the cartesian product of two iterators, which is roughly equal to a nested for loop 
for x,y in itertools.product([1,2,3,4,5],[6,7,8,9,10]):
    print(x,y)



#permutations() returns all possible different orders (permutations of the elements) in an iterator 
for i in itertools.permutations([1,2,3]):
    print(list(i))

#combinations() returns all possible ways in which an r number of elements can selected 
for i in itertools.combinations([1,2,3,4], r=2):
    print(list(i))




# Python code to demonstrate 
# converting 2d list into 1d list 
# using chain.from_iterables 

# import chain 
from itertools import chain 

ini_list = [[1, 2, 3], 
			[3, 6, 7], 
			[7, 5, 4]] 
			
# printing initial list 
print ("initial list ", str(ini_list)) 

# converting 2d list into 1d 
# using chain.from_iterables 
flatten_list = list(chain.from_iterable(ini_list)) 

# printing flatten_list 
print ("final_result", str(flatten_list)) 

#######################################


# Python code to demonstrate 
# converting 2d list into 1d list 
# using list comprehension 

# import chain 
from itertools import chain 

ini_list = [[1, 2, 3], 
			[3, 6, 7], 
			[7, 5, 4]] 
			
# printing initial list 
print ("initial list ", str(ini_list)) 

# converting 2d list into 1d 
# using list comprehension 
flatten_list = [j for sub in ini_list for j in sub] 

# printing flatten_list 
print ("final_result", str(flatten_list)) 


######################################
import itertools 

myranger1=range(10)
myranger2=range(7)

print("zip stops early")
print(list(zip(myranger1,myranger2)))

#print("zip_longest processes all of the values of mismatched lists")
print(list(itertools.zip_longest(myranger1,myranger2)))



#############################
#itertools_islice.py
import itertools

print('Stop at 5:')
for i in itertools.islice(range(100), 5):
    print(i, end=' ')
print('\n')

print('Start at 5, Stop at 10:')
for i in itertools.islice(range(100), 5, 10):
    print(i, end=' ')
print('\n')

print('By tens to 100:')
for i in itertools.islice(range(100), 0, 100, 10):
    print(i, end=' ')
print('\n')


