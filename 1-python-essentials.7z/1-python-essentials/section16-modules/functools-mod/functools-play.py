"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#FUNCTOOLS MODULE 
# A higher order function is a function that operates on other functions 
#it operates on other functions 
# when a function takes functions as arguments 
# or returns functions a return values 
# it is called a higher-order function 
# this is used often in functional programming 
# it is part of the python standard function library 
import functools 

#the partial() function binds arguments to a function, so that the function can later be called without passing this argument.j
# this is related to the functional-programming concept currying, in which a single function that takes multiple arguments is turned into a chain of functions that each take on argument


#the purpose of function currying is to easily get specialized functions from more general functions. 
# we can achieve this by pre-setting some parameters at a different time and keeping them fixed afterwards. 


# this is kind of incremental binding of function argument. 

#currying implementation in python 
def curry (prior, *additional):
    def curried(*args):
        return prior(*(args + additional))
    return curried

def add(*args):
    return sum(args)

x = curry(add, 23213,421312,52312321)
y = curry(x, 2132)
print(y(213123))


#################
from copy import copy
import functools


def curry(function):

  def inner(*args, **kwargs):
    partial = functools.partial(function, *args, **kwargs)
    signature = inspect.signature(partial.func)
    try:
      signature.bind(*partial.args, **partial.keywords)
    except TypeError as e:
      return curry(copy(partial))
    else:
      return partial()

  return inner


#############################

def arimean(*args):
    return sum(args) / len(args)
def curry(func):
    f_args = []
    f_kwargs = {}
    def f(*args, **kwargs):
        nonlocal f_args, f_kwargs
        if args or kwargs:
            f_args += args
            f_kwargs.update(kwargs)
            return f
        else:
            return func(*f_args, *f_kwargs)
    return f
            
s = curry(arimean)
s(2)(5)(9)(4, 5)
s(5, 9)
print(s())
s2 = curry(arimean)
s2(2)(500)(9)(4, 5)
s2(5, 9)
s2()

################################
#currying in python - many to single argument 
def change(a):
    def w(b):
        def x(c):
            def y(d):
                def z(e):
                    print(a,b,c,d,e)
                return z
            return y 
        return x 
    return w


change(10)(20)(30)(40)(50)

############################
def compose(g, f):
    def h(*args, **kwargs):
        return g(f(*args, **kwargs))
    return h

def BMI(weight, height):
    return weight / height**2

def evaluate_BMI(bmi):
    if bmi < 15:
        return "Very severely underweight"
    elif bmi < 16:
        return "Severely underweight"
    elif bmi < 18.5:
        return "Underweight"
    elif bmi < 25:
        return "Normal (healthy weight)"
    elif bmi < 30:
        return "Overweight"
    elif bmi < 35:
        return "Obese Class I (Moderately obese)"
    elif bmi < 40:
        return "Obese Class II (Severely obese)"
    else:
        return "Obese Class III (Very severely obese)"
f = compose(evaluate_BMI, BMI)
weight = 1
while weight > 0:
    weight = float(input("weight (kg) "))
    height = float(input("height (m) "))
    print(f(weight, height))


##################################################
# Demonstrate Currying of composition of function 
  
def change(b, c, d): 
    def a(x): 
        return b(c(d(x))) 
    return a 
      
def daystohour(time):  
    """ Function that converts days to hours. """
    return time * 24
      
def hourstominutes(time):  
    """ Function that converts hours to minutes. """
    return time * 60
      
def minutestoseconds(time): 
    """ Function that converts minutes to seconds. """
    return time * 60
      
if __name__ == '__main__': 
    transform = change(minutestoseconds, hourstominutes, daystohour) 
    e = transform(10) 
    print(e) 
####################################################
# Demonstrate Currying of composition of function 
def change(b, c, d): 
    def a(x): 
        return b(c(d(x))) 
    return a 
      
def kilometer2meter(dist):  
    """ Function that converts km to m. """
    return dist * 1000
      
def meter2centimeter(dist):  
    """ Function that converts m to cm. """
    return dist * 100
      
def centimeter2feet(dist): 
    """ Function that converts cm to ft. """
    return dist / 30.48
      
if __name__ == '__main__': 
    transform = change(centimeter2feet, meter2centimeter, kilometer2meter ) 
    e = transform(565) 
    print(e) 

##########################################################

#partial functions in python 
#partial functions allow us to fix a certain number of arguments of a function and generate a new function 

from functools import partial 
def myfunction(a,b,c,d):
  print('inside myfunction')
  return 1111*a + 222*b+33*c +4*d


mycomputation = partial(myfunction,10,20,30)

print(mycomputation(100))


##################################################
#reduce() in python 
# the reduce(fun,seq) function is used to apply a particular function passed in its argument to all of the list elements mentioned in the sequence passed along 
# the first two elements of sequence are picked and the result is obtained. 
# next step is to apply the same function to the previously attained result and the number just succeeding the second element and the result is again stored 
# this process continues till no more elements are left in the container 
# the final returned result is retuned 

import functools 
import operator 
mylist = [123,323,423,472,9827,171]

# using reduce to compute sum of list 
print ("The sum of the list elements is : ",end="") 
print (functools.reduce(lambda a,b : a+b,mylist)) 
  
# using reduce to compute maximum element from list 
print ("The maximum element of the list is : ",end="") 
print (functools.reduce(lambda a,b : a if a > b else b,mylist)) 


##using reduce to compute product 
#using the operator functions 
print(functools.reduce(operator.add,mylist))
print(functools.reduce(operator.mul,mylist))


### reduce() vs accumulate()

#both reduce() and accumulate() can be used to calculate the summation of a sequence elements. 
# difference in implementations 
# reduce() is defined in functools module 
# accumulate() is defined in itertools module 
# reduce() stores the intermediate result and only returns the final summation value 
# accumulate() returns a list containing the intermediate results, the last number of the list is summation value of the list 
# reduce(fun,seq) takes function as 1st and sequence as 2nd argument. 
# accumulate(seq,fun) takes sequence as 1st argument and function as second argument
#  

import itertools 
import functools 

score_card=[12,313,123,13,12,34,83,837,82,128,378,1289,1328,123,9833]
#using accumulate print summation 
print(list(itertools.accumulate(score_card,lambda x,y:x+y)))

#using reduce print summation 
print(functools.reduce(lambda x,y:x+y,score_card))

# to convert a tuple into a string 
import functools 
import operator  
  
def convertTuple(tup): 
    str = functools.reduce(operator.add, (tup)) 
    return str
  

intuple=('s','y','e','d','a','w','a','s','e','k','h','i','r','n','i')
mynameis=convertTuple(intuple)
print(mynameis)


###########################################

# Python code to demonstrate 
# converting 2d list into 1d list 
# using functools.reduce 

# import functools 
from functools import reduce

ini_list = [[1, 2, 3], 
			[3, 6, 7], 
			[7, 5, 4]] 
			
# printing initial list 
print ("initial list ", str(ini_list)) 

# converting 2d list into 1d 
# using functools.reduce 
flatten_list = reduce(lambda z, y :z + y, ini_list) 

# printing flatten_list 
print ("final_result", str(flatten_list)) 


#####################################
#LRU CACHE 
# LRU cache decorator remembers the results of a function call and when the function is called again with the same set of arguments, returns this result right away. 
# this is a form of caching and is related tot he functional-programming concept memorization 

import itertools 
import time 
import functools 


@functools.lru_cache()
def compute_primebelow(x):
    return next( itertools.dropwhile(lambda x:any(x//i==float(x)/i for i in range(x-1,2,-1)),range(x-1,0,-1)))


t0=time.time()
print(compute_primebelow(10000))
t1=time.time()
print('took %.2f ms'%(1000*(t1-t0)))
print(compute_primebelow(10000))
t2=time.time()
print('Second iteration took %.2f ms'%(1000*(t2-t1)))


########################################
#@singledispatch decorator allows you to create different implementations of a function, given different argument types. 
# the type of the first argument is used to decide which implementation of the function should be used 

import functools 

@functools.singledispatch
def add(a,b):
    return a+b 

@add.register(str)
def _(a,b):
    return int(a)+int(b)

print(add('123123','12331234'))

##############################
from types import LambdaType
from multipledispatch import dispatch

class TestClass(object):

    @dispatch(object)
    def test_method(self, arg, verbose=False):
        if verbose:
            print("Let me just say,", end=" ")

        print(arg)

    @dispatch(int, float)
    def test_method(self, arg, arg2):
        print("Strength in numbers, eh?", end=" ")
        print(arg + arg2)

    @dispatch((list, tuple), LambdaType, type)
    def test_method(self, arg, arg2, arg3):
        print("Enumerate this:")

        for i, elem in enumerate(arg):
            print(i, arg3(arg2(elem)))


if __name__ == '__main__':

    test = TestClass()
    test.test_method(55555, 9.5)
    test.test_method([33, 22, 11], lambda x: x*2, float)