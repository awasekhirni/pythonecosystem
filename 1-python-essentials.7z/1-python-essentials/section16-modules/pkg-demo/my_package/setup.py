import setuptools
with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name='tpri_package',
    version='0.1',
    scripts=['tpri_package'],
    author="Syed Awase",
    author_email="awasekhirni@gmail.com",
    description="A Simple TPRI Package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/awasekhirni/tpri",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
         "License :: OSI Approved :: MIT License",
         "Operating System :: OS Independent",
    ],
)
