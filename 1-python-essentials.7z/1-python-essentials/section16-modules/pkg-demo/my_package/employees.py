class Employees:
    def __init__(self):
        """constructor for this class"""
        #create some employees for tpri
        self.colleagues=['syed ameese','syed awase','syed azeez','syed rayyan']

    def printColleagues(self):
        print('printing colleagues')
        for colleague in self.colleagues:
            print('\t%s' % colleague)
            