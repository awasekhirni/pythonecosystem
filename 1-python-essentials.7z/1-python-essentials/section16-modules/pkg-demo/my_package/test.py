#import classes from the brand new package
from employees import Employees

#create an object of Employees class and call a method of it 
myemployee = Employees()
myemployee.printColleagues()



        