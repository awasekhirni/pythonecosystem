"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#!/usr/bin/python
from computearea import circle_area, power

if __name__ == "__main__":
    print(circle_area(12))
    print(power(12, 20))
