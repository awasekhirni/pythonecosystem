"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
#!/usr/bin/python

pi = 3.141592


def circle_area(r):
    """ Calculate circle area"""
    return pi * r * r


def power(x, n):
    result = x
    for i in range(1, n):
        result = result * x
    return result
