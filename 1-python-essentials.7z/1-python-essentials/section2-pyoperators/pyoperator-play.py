"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
print(chr(16),chr(191),chr(6712))

import operator 
#using iadd() to add and assign 
x = operator.iadd(1212,3273)
#print the value of x 
print("the value after adding two numbers")
print(x)

#concatenating strings 
onesen= "hello! you fool i love you"
twosen=" come on enjoy the joy ride "
#using iconcat() to concat the sentences 

finalsentence=operator.iconcat(onesen,twosen) 
#printing the concatenated sentence 
print(finalsentence)


#subtracting numbers 
diffno = operator.isub(3274,128)
print(diffno)
#using imul() to multiply and assign 
mull=operator.imul(12,12)
print(mull)

#itruediv() - used to assign and divide the current value 

#imod() - used to assign and return reminder 
divval=operator.itruediv(123132,22)
print(divval)

#modulus operations 
icmod=operator.imod(14123123,2323)
print(icmod)