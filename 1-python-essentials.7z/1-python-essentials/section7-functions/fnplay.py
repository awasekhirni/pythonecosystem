"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#write a function to compute string length

def compute_stringlen(str1):
    count=0
    for char in str1:
        count+=1
    return count 


print(compute_stringlen('hello, you fool i love you'))


#compute the character frequency in string 

def compute_charfreq(mystring):
    dict={}
    for i in mystring:
        keys=dict.keys()
        if i in keys:
            dict[i]+=1
        else:
            dict[i]=1
    return dict 


print(compute_charfreq('betty bought a bit of butter to make the bitter butter better'))


#multiple return statements in functions 
#tuple 
def myMultiReturnTuple():
    productName="SycliQPrime"
    productPrice=1599
    return (productName,productPrice) 


#list 
def myMultiReturnList():
    productName="SycliQPrime"
    productPrice=1599
    return [productName,productPrice]


#dictionary 
def myDictionaryReturnList():
    de=dict()
    de['str']="Hello, this is dictionary"
    de['score']=123
    return de 



#swap the first character in a word
def charact_swap(mywordone,mywordtwo):
    new_one=mywordtwo[:1]+mywordone[1:]
    new_two=mywordone[:1]+mywordtwo[1:]
    return new_one+'  '+new_two 


print(charact_swap('Forgan', 'Mellony'))



#find the longest word in the sentence and print it 

# def find_longestWord(mypara):
#         word_len=[]
#         for n in mypara:
#             mypara.append((len(n),n))
#         word_len.sort()
#         return word_len[-1][1]

# print(find_longestWord(["Parrot", "Parole", "Juicer","Jargon","Miscellaneous", "Monstrous"]))  



#compute the occurence of words in a sentence - word frequency nlp 
def compute_wordfreq(mypara):
    counts=dict()
    words=mypara.split()

    for word in words:
        if word in counts:
            counts[word]+=1
        else:
            counts[word]=1

    return counts



newsdata="The cache of documents released by NSA whistleblower Edward Snowden shed light on the extent of U.S. espionage operations in various parts of the world and threatened to damage U.S. relations with some key international players, who claimed in public to be furious with the U.S.’s snooping in their own countries. There was White House ally German Chancellor Angela Merkel, demanding answers on allegations that the NSA had tapped her cell phone, and Brazilian President Dilma Rousseff who canceled a trip to the U.S. and then, later, complained before a global audience at the UN about the “affront” to her country’s sovereignty. The repercussions echoed far outside the intelligence community: U.S. web companies could lose billions of dollars as international users turn to products they think are less prone to spying eyes. And it does the already tetchy relationship between Washington and Moscow little good when the latter is giving asylum to America’s now best-known fugitive."

print (compute_wordfreq(newsdata))


#create caesar encryption for news data 

def encrypt_caesar(actualText,step):
    finalText=[]
    cryptText=[]

    uppercase=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
    lowercase=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

    for eachAlfabet in actualText:
        if eachAlfabet in uppercase:
            index= uppercase.index(eachAlfabet)
            crypting=(index+step)%26
            cryptText.append(crypting)
            newLetter=uppercase[crypting]
            finalText.append(newLetter)
        elif eachAlfabet in lowercase:
            index=lowercase.index(eachAlfabet)
            crypting=(index+step)%26
            cryptText.append(crypting)
            newLetter=lowercase[crypting]
            finalText.append(newLetter)
    return finalText


code = encrypt_caesar("SyedAwaseKhirni",7)
print()
print(code)
print()



#alphabetic sorting 
grocery_list=input("Please enter your grocery items you wish to purchase from supermarket:")
items=[item for item in grocery_list.split(",")]
print(",".join(sorted(list(set(items)))))


#write a function to check whether a number is in a range
#  
def test_range(myno):
    if myno in range (11,29):
        print("%s is in the range of " % str(myno))
    else:
        print("the number is outside the given range")


test_range(30)


#identify the number of capital and small letters in a sentence
def count_thecase(senti):
    d = {"uppercase": 0, "lowercase": 0}
    for c in senti:
        if c.isupper():
            d["uppercase"] += 1
        elif c.islower():
            d["lowercase"]+=1
        else:
            pass
    print("the original sentence is:", senti)
    print("No of upper case characters:", d['uppercase'])
    print("No of lower case characters:",d['lowercase'])
    
count_thecase("Betty bought a bit of Butter, to make the bitter Butter Better")



#check whether a number is prime or not
def check_prime(n):
    if (n == 1):
        return False
    elif (n == 2):
        return True
    else:
        for x in range (2,n):
            if (n % x == 0):
                return False
        return True

print(check_prime(37))
print(check_prime(96))


#palindrome check

def palindrome_check(myword):
    leftpos = 0
    rightpos = len(myword) - 1
    
    while rightpos>=leftpos:
        if not myword[leftpos] == myword[rightpos]:
            return False
        leftpos += 1
        rightpos -= 1
    return True

print(palindrome_check('gadag'))
print(palindrome_check('kayak'))


#create pascal triangle
def create_pascal(n):
    trow = [1]
    y = [0]
    for x in range(max(n, 0)):
        print(trow)
        trow=[l+r for l,r in zip(trow+y,y+trow)]
    return n>=1

create_pascal(6)

#checking for panagram
# words or sentences containing every letter of the alphabet at least once 
#import string, sys
import string, sys 
def check_panagram(mysent,alphabet=string.ascii_lowercase):
    alphaset=set(alphabet)
    return alphaset<=set(mysent.lower())

print(check_panagram("betty bought a bit of butter to make the bitter butter better"))


#accessing a function inside a function 
def outerfn(a):
    def innerfn_add(b):
        nonlocal a
        a+=1
        return a+b
    return innerfn_add


offo=outerfn(10)
print(offo(10))


#variable length arguments
def printMarks(name, *marks):
    "this prints a variable passed arguments"
    print("Output is=")
    print(name)
    for var in marks:
        print(var)
    return


#calling the function 
printMarks('SyedAwase', 89, 98, 84, 89, 90)


#annonymous functions 
def make_increment(n):
    return lambda x: x ** n
    
#calling function
val = make_increment(2)
print(val(10))
print(val(20))


#lambda functions in python3
#simple one-line functions that try to save space and time.
#useful in higher-order functions, which actually take another function as argument
def double(x):
    return x*2

double = lambda x:x*2

#consuming/using it
double(5) == 10


#local functions 
#local scoping rules are based on LEGB rule 
# local,enclosing, global, built-in
# useful for specialized, one-off functionality implementation
#help in code organization and reability 

def sort_by_first_letter(strings):
    def first_letter(s):
        return s[-1]
    return sorted(strings, key=first_letter)

sort_by_first_letter(['hello','you', 'fool', 'i','love','you'])


#LEGB rule demo 
g='global'
def outer(p="param"):
    l='local'
    def inner():
        print(g,p,l)
    inner()


#execution 
outer()



#measure the real-size of any python object 
import sys 

def compute_object_size(obj,seen=None):
    """compute the object size in a recursive manner"""
    size=sys.getsizeof(obj)
    if seen is None:
        seen=set()
    obj_id=id(obj)
    if obj_id in seen:
        return 0 
    seen.add(obj_id)
    if isinstance(obj,dict):
        size+=sum([compute_object_size(v,seen) for v in obj.values()])
        size+=sum([compute_object_size(k,seen) for k in obj.keys()])
    elif hasattr(obj,'__dict__'):
        size+=compute_object_size(obj.__dict__,seen)
    elif hasattr(obj,'__iter__') and not isinstance(obj,(str,bytes,bytearray)):
        size+=sum([compute_object_size(i,seen) for i in obj])
    return size 


#function to replace a character with a new character in a string 
def replaceCharinSentence(mysentence,exisChar,replChar):
    newChars = map(lambda x:x if (x!=exisChar and x!=replChar) else exisChar if(x==replChar) else replChar,mysentence)
    print(''.join(newChars))
  
# Driver program 
if __name__ == "__main__": 
    sentenceNew = 'leve'
    c1 = 'e'
    c2 = 'a'
    replaceCharinSentence(sentenceNew,c1,c2)



#intersection of two arrays
def interSectionFunction(arrOne,arrTwo):
    myresult=list(filter(lambda x:x in arrOne,arrTwo))
    print("ArrayIntersection:",myresult )


if __name__ =="__main__":
    One=[1212,12726,72726,32727,37363,4387]
    Two=[1276763,57763,474762,1212,72726]
    interSectionFunction(One,Two)