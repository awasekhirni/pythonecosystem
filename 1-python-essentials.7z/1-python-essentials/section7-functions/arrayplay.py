"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

from array import *

array_idx = array('i', [1212, 3123, 4323, 55231, 123412, 4523])
for i in array_idx:
    print(i)

print("Accessing the first two elements individually")
print(array_idx[0])
print(array_idx[1])

# appending a new item to the end of the array
array_idx.append(21371237)
print("My new array values are:"+str(array_idx))

array_idx.reverse()
print("reversed order of the array:", str(array_idx))

# print the length in bytes of one array item in the internal representation
print("length in bytesof one array item:"+str(array_idx.itemsize))

# get the current memory address and the length in elements of the buffer
print("Current memory address and the length in elements of the buffer: " +
      str(array_idx.buffer_info()))
print("The size of the memory buffer in bytes: " +
      str(array_idx.buffer_info()[1] * array_idx.itemsize))


# print the number of occurrences of a specified element in an array
mynewarr = array('i', [12, 11, 8, 19, 21, 21, 98, 8, 69,
                       11, 43, 12, 8, 8, 9, 19, 16, 17, 18, 43, 34])
print("Number of occurrences of the number 8 in the said array: " +
      str(mynewarr.count(8)))


# appending another array
array_idx.extend(mynewarr)
print(str(array_idx))


# convert an array to an array of machine values and return the bytes representation
myval = array('b', [115, 121, 101, 68, 65, 119, 65, 115, 101])
conv_byarr = myval.tobytes()
print(conv_byarr)

# append items from a specified list
list_val = [1231, 1321, 249, -1329]
tr_arr = array('i', [])  # empty array
tr_arr.fromlist(list_val)
print("items in the array:"+str(tr_arr))

# insert a new item before the 4th element in an existing array
ins_val = array('i', [1232, 1242, 2892, 2991, 1923])
ins_val.insert(3, 3131)
print("new array after insertion is:"+str(ins_val))

# remove a specified item using the index from an array.
cric_runs = array('i', [23, 29, 56, 29, 67, 89, 91, 106, 121, 10, 11])
print('the published array with errors is:'+str(cric_runs))
cric_runs.pop(3)
print('the new corrected scores are:'+str(cric_runs))


# remove the first occurence of a specified element from an array
scrib_arr = array('i', [13, 15, 16, 17, 19, 21, 45, 67, 12, 23, 15])
scrib_arr.remove(15)
print("after removal of value 15 from the array:"+str(scrib_arr))


# convert an array to an ordinary list with the same items
scary = array('i', [13, 15, 16, 17, 19, 21, 45, 67, 12, 23, 15])
scary_list = scary.tolist()
print('new list from array:'+str(scary_list))
