"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
# python conditional statements and loops


# guessing game using while condition
import random
target_num, guess_num = random.randint(50, 55), 0
while target_num != guess_num:
    guess_num = int(input('please guess a number between 50 and 55'))
print('You have guessed it right')


# compute the fibanocci number until the given no
terminate_no = int(
    input('please enter the number until which you want me to computer fibonacci:'))
i, j = 0, 1
while j < terminate_no:
    print(j)
    i, j = j, i+j


# compute dogs age equivalent to human years
# first two years it is 2*10.5
# rest of the years is 4* human years
human_age = int(input("Please input dogs age in human years:"))

if human_age < 0:
    print("Age must be a positive number")
    exit()
elif human_age <= 2:
    dogs_age = human_age*10.5
    print("dogs_age when it is less than 2 is", dogs_age)
else:
    dogs_age = 2*10.5+(human_age-2)*4

print("the dogs age in the dogs years is:", dogs_age)

# identify if the triangle is isosceles, equilateral,scalene
print('please input the lengths of the triangle sides:')
x = int(input("x:"))
y = int(input("y:"))
z = int(input("z:"))

if x == y == z:
    print("it is an equilateral triangle")
elif x == y or y == z or z == z:
    print("it is an isosceles triangle")
else:
    print("Scalene Triangle")

# compute the chinese zodiac for any given year
year = int(input("Input your birth year: "))
if (year - 2000) % 12 == 0:
    sign = 'Dragon'
elif (year - 2000) % 12 == 1:
    sign = 'Snake'
elif (year - 2000) % 12 == 2:
    sign = 'Horse'
elif (year - 2000) % 12 == 3:
    sign = 'sheep'
elif (year - 2000) % 12 == 4:
    sign = 'Monkey'
elif (year - 2000) % 12 == 5:
    sign = 'Rooster'
elif (year - 2000) % 12 == 6:
    sign = 'Dog'
elif (year - 2000) % 12 == 7:
    sign = 'Pig'
elif (year - 2000) % 12 == 8:
    sign = 'Rat'
elif (year - 2000) % 12 == 9:
    sign = 'Ox'
elif (year - 2000) % 12 == 10:
    sign = 'Tiger'
else:
    sign = 'Hare'

print("Your Zodiac sign :", sign)


# statistical problem compute the median of 3 number s
first_no = float(input("Please input the first number"))
second_no = float(input("please input the second number"))
third_no = float(input("please input the third number"))

if first_no > second_no:
    if first_no < third_no:
        median = first_no
    elif second_no > third_no:
        median = second_no
    else:
        median = third_no
else:
    if first_no > third_no:
        median = first_no
    elif second_no < third_no:
        median = second_no
    else:
        median = third_no

print("the median is", median)


# truthy value in python
# falsy value in python

score = 121
if score:
    print("the cricket score is defined and truthy")


# calculate the sum of a list of numbers
# recursion
def compute_listsum(mylist):
    if len(mylist) == 1:
        return mylist[0]
    else:
        return mylist[0]+compute_listsum(mylist[1:])


print(compute_listsum([12312, 12313, 1312312, 123141]))

# convert an integer to a string in any base


def stringin_anybase(mystring, base):
    toConvertString = "0123456789ABCDEF"
    if mystring < base:
        return toConvertString[mystring]
    else:
        return stringin_anybase(mystring // base, base) + toConvertString[mystring % base]


print(stringin_anybase(5437, 16))


# factorial
def factorial(n):
    if n <= 1:
        return 1
    else:
        return n * (factorial(n - 1))


print(factorial(7))


# compute power to the value of a to the power b

def power(a, b):
    if b == 0:
        return 1
    elif a == 0:
        return 0
    elif b == 1:
        return a
    else:
        return a * power(a, b - 1)


print(power(2, 5))

# compute the greatest common divisor of two integers


def compute_gcd(a, b):
    low = min(a, b)
    high = max(a, b)

    if low == 0:
        return high
    elif low == 1:
        return 1
    else:
        return compute_gcd(low, high % low)


print(compute_gcd(24, 28))
