"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#CALCULATOR APPLICATION 

#functools module, itertools module, iterator unpackaing, decorators, generators, StopIteration(the iterator protocol)

import functools 
import itertools 

#tuples 
OPERATOR='+','-','/','*'
EXIT_COMMANDS ='exit','quit'


def can_calculate(state):
    if len(state)<3:
        return False 
    *_,i1,op,i2=state 
    return isinstance(i1,float) and op in OPERATOR and isinstance(i2,float)

    
def calculate(state):
    *_,i1,op,i2=state 
    if op=='+':
        result=i1+i2
    elif op=='-':
        result=i1-i2
    elif op=='*':
        result=i1*i2
    elif op=='/':
        result=i1/i2
    else: 
        raise ValueError("Invalid Operator")
    
    print('%f %s %f=%f'%(i1,op,i2,result))
    return result


def process_input(state,update):
    state.append(update)
    if can_calculate(state):
        presult=calculate(state)
        state.append(presult) 
    return state 



def validate_input(fn):
    def inner():
        i=fn()
        try:
            i=float(i)
        except ValueError:
            pass 
        if isinstance(i,float) or i in OPERATOR or i in EXIT_COMMANDS:
            return i 
        return None
    
    return inner

@validate_input
def get_input():
    return input()



def input_loop():
    while True:
        i=get_input()
        if i in EXIT_COMMANDS:
            break 
        if i is None:
            print("please enter a number or an operator")
            continue 
        yield i 




def calculatorApp():

    functools.reduce(process_input,input_loop(),[0])



if __name__=="__main__":
    calculatorApp()