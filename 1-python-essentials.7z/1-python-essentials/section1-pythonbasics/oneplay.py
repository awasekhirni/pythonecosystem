"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
import multiprocessing
from math import pi
import sys
msg = "hello, you are being run on python"
print(msg)
mesg = "Barak Obama, changed the game"
mesg.capitalize()  # capitalize
mesg.replace("k", "c")  # replace
mesg.isalpha()  # boolean check for alphabet
mesg.isdigit()  # useful when converting to int

# everything in Python is an object and has an identity attached to it
my_name = "Syed Awase"
print("unique identifier attached to my_name:", id(my_name))

# define simple string with special characters

mysong = "You know Hello, you fool i love you! (that\"s me)"
print(mysong)

# printing a poem format

print("Betty bought a bit of butter, \n\tto make the bitter butter better \n\t\tthe bitter the butter, it tastes better, \n\t\tso betty did it better. \nthe bitter the butter, \n\tthe better the cheese!")


# another string
my_home = "I stay at Winterthurerstrasse, ZH"
print(my_home, "******", end="")

# multi-line string
sites = '''Even though you extract geoplaces from the web, we need to perform place name disambiguations'''
print(sites)

# this is another multi-line string
sycliq = """it is an acronym for Systems for Commodity/Crop/Commuting/Care Life Cycle Intelligence"""
print(sycliq)


# variable numbers
var1 = 123141
var2 = 1294812

print(id(var1))
print(id(var2))
print("variable1:", var1)
print("variable2:", var2)

# now lets delete the reference to a number object by using "del" statement

del var2
#print("is it printing reference now:", id(var2))

print("Hello, after deleting reference")

# printing the version of python
print("Python version is:", sys.version)
print("Version info:", sys.version_info)


# computing the area of a cirle
r = float(input("Please enter the radius of the circle:"))
area = pi * r ** 2
print("the area of the circle with radius" + str(r) + "is:" + str(area))


# printing grocerylist to purchase
grocerylist = ["milk", "eggs", "butter", "choclate", "yoghurt"]
print("%s %s" % (grocerylist[-1], grocerylist[0]))

# formatted date printing in YYYY/MM/DD
product_release_date = (31, 12, 2013)
print("the product release data is:%i/%i/%i" % product_release_date)

# input an integer and compute the sum of squares, sum of cubes and sum of power of the same numberself.
given_number = int(input("Please input an integer:"))
no_sq = int("%s" % (given_number ** 2))
no_cube = int("%s" % (given_number ** 3))
no_power = int("%s" % (given_number ** given_number))
sumofAllfears = no_sq + no_cube + no_power
print(sumofAllfears)


# compute the volume of sphere
rad_sphere = int(input("Please input an radius sphere:"))
comp_vol = 4.0 / 3.0 * pi * rad_sphere ** 3
print("the volume of the sphere is:", comp_vol)


# Python code to demonstrate the working of
# complex(), real() and imag()

# importing "cmath" for complex number operations
# Initializing real numbers
x = 12
y = 4

# converting x and y into complex number
z = complex(x, y)

# printing real and imaginary part of complex number
print("The real part of complex number is : ", end="")
print(z.real)

print("The imaginary part of complex number is : ", end="")
print(z.imag)

# compute the area of a triangle
bredth = int(input("please enter the base:"))
heght = int(input("please enter the height:"))
comp_area = (bredth * heght) / 2
print("computed area of the triangle is:", comp_area)


# finding the number of CPU's running on your laptop
print("the number of processors on your laptop are:", multiprocessing.cpu_count())


# emptying a variable without destroying it
my_data = 1231243123,
tricky = {"logs": 1231}
naira_marks = [89, 83, 81, 89, 78]  # list
gas = (12, 11, 18)  # tuple
print(type(my_data)())
print(type(tricky)())
print(type(naira_marks)())
print(type(gas)())


# determining the largest and smallest integers, longs, floats
print("float value information:", sys.float_info)
print('\nInteger value information:', sys.int_info)
print("\nMaximum size of an integer:", sys.maxsize)
print("\nGet the platform info:", sys.platform)
print(sys.executable)
print(sys.api_version)


# string format function
myname = "Syed Awase"
qualify = "PhD"
"Hello, All, nice to visit you. I am {0} and my qualification is {1}.".format(
    myname, qualify)
# Note-python is 0 based


#### trunc, floor, ceil in python 
import math 
print(math.floor(3.14567))
print(math.trunc(3.14567))
print(math.ceil(3.14567))

