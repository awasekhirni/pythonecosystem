"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#classes in python
#class:object specification for creating objects 
#All objects created usign the same class specification will have the same characteristics
#object: it is an instance of a class 
#mthod:a function defined in a class

class Kettle(object):
    def __init__(self,make,price):
        self.make=make 
        self.price=price 
        self.on = False
        
kenwood = Kettle("kenwood", 2045.56)
print(kenwood.make)
print(kenwood.price)



class Person:
    # constructor/initializer for the class
    def __init__(self, name):
        self.name = name

    def say_hello(self):
        print("Hello! Syed", self.name)


# instantiation
sak = Person("Awase")
sak.say_hello()

smr = Person("Rayyan")
smr.say_hello()

# object oriented programming in python


class Product:
    pass  # do nothing

new_product = Product()
print(new_product)

# class Employee:
#     # class attribute
#     type = "permanent"

#     # instance attribute
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age


class Employee:
    "Common base class for all employee objects"
    empCount = 0

    # constructor/initializer
    def __init__(self, empId, empName, empSalary, empDesg):
        self.empId = empId
        self.empName = empName
        self.empSalary = empSalary
        self.empDesg = empDesg

    def displayCount(self):
        print("Total no of employees:%d" % Employee.empCount)

    def displayEmployee(self):
        print("empId:", self.empId, "empName:", self.empName,
              "empSalary:", self.empSalary, "empDesg:", self.empDesg)


syed = Employee(123134, "Syed Awase", 16236126, "CEO")
azeez = Employee(123123, "Syed Azeez", 716123, "COO")

print(syed)
print(azeez)
# type of the object
print(type(syed))

syed.displayEmployee()


# bank account
class BankAccount:
    "Base class for Bank Account"

    # constructor/instantiation
    def __init__(self):
        self.balance = 0

    def withdraw(self, amount):
        self.balance -= amount
        print("post-withdraw-balance:", self.balance)
        return self.balance

    def deposit(self, amount):
        self.balance += amount
        print("post-deposit-balance:", self.balance)
        return self.balance


# instantiation
syed_awase = BankAccount()
syed_ameese = BankAccount()

syed_awase.deposit(50000)
syed_ameese.deposit(80000)

syed_awase.withdraw(7863)
syed_ameese.withdraw(6552)


# Reverse Iterator for looping over a sequence backwards

class Reverse:
    """Iterator for looping over a sequence backwards."""

    def __init__(self, data):
        self.data = data
        self.index = len(data)

    def __iter__(self):
        return self

    def __next__(self):
        if self.index == 0:
            raise StopIteration
        self.index = self.index - 1
        return self.data[self.index]


myrev = Reverse("Harry Potter and Chamber of Secrets")
iter(myrev)
for mychar in myrev:
    print(mychar)

# class attributes and object attributes are store in seperate dictionaries
print(myrev.__dict__)


# public access modifiers
# all member variables and methods are public by default

class Bottle:
    def __init__(self):
        self.color = None
        self.content = None

    def fill(self, beverage):
        self.content = beverage

    def empty(self):
        self.content = None


# instantiate
beerBottle = Bottle()
beerBottle.color = "brown"
beerBottle.content = "Non-Alcholic Beer"

print(beerBottle.content)
beerBottle.empty()
beerBottle.fill('juice')
print(beerBottle.content)


# AccessModifier:Protected
# all member variables and methods cna be made protected by convention only in python
# _variablename is a convention followed to define protected variables

class Cloth:
    def __init__(self):
        self.color = None
        # protected variabel
        # by convention we use _variablename
        self._materialcontent = None

    def Embroider(self, design):
        self._content = design

    def Dye(self, colorDye):
        self.colorDye = colorDye


# instance
frock = Cloth()
frock._material = "cotton"
print(frock._materialcontent)


#class Book
class Book:
    def __init__(self,book_title, book_author, book_publisher, book_year, book_price):
        self.book_title=book_title 
        self.book_author=book_author
        self.book_publisher = book_publisher
        self.book_year = book_year
        self.book_price = book_price
        
    def library_entry(self):
        return (self.book_title + ' ' + self.book_author + ' ' + self.book_year + ' ' + self.book_publisher + ' ' + str(self.book_price))
        

fountain_head = Book("Fountain Head", "Ayn Rand", "2002", "McGrawHill", 200)

print(fountain_head.library_entry())

# private scope
# name mangling technique in python


class Cup:
    def __init__(self, color):
        # protected variable
        # convention followed is _variable name
        self._color = color
        # private variable
        # convention followed is __variable name
        self.__content = None

    def fill(self, beverage):
        self.__content = beverage

    def empty(self):
        self.__content = None


# instantiate
mochaCup = Cup('red')
mochaCup._Cup__content = "coffee"
print(mochaCup._Cup__content)


# general scenario
# traditional approach
is_RockStar = True


def ProgrammerCheck():
    return (is_RockStar == True)


class Programmer(object):
    def __init__(self, data):
        self.data = data

    def do_learn(self):
        if ProgrammerCheck():
            print(
                "Programmer is a rockstar he can self learn and deliver: Syed Awase!:::", self.data)

    def set_learn(self):
        if ProgrammerCheck():
            self.external = "Not sure how he is!!"
            print("Your request for Programmer::", self.data)


geekone = Programmer("Narri")
geektwo = Programmer("Barri")
geekone.do_learn()
geekone.set_learn()


# scenario using @static method
isPlayer = True


class Player(object):
    def __init__(self, data):
        self.data = data

    @staticmethod
    def does_perform():
        return (isPlayer == True)

    def overseas_Play(self):
        if self.does_perform():
            print("fit for Overseas Play:", self.data)

    def set_Play(self):
        if self.does_perform():
            self.gethim = "get this player to play"
            print("Football play:", self.data)


messi = Player('Lionel Messi')
messi.overseas_Play()
messi.set_Play()

# vehicle class


class Vehicle:
    def __init__(self, number_of_wheels, type_of_fuel, seating_capacity, maximum_velocity, bhp):
        self.number_of_wheels = number_of_wheels
        self.type_of_fuel = type_of_fuel
        self.seating_capacity = seating_capacity
        self.maximum_velocity = maximum_velocity
        self.bhp = bhp

    #@property
    def get_number_of_wheels(self):
        return self.number_of_wheels

    #@number_of_wheels.setter
    def set_number_of_wheels(self, number):
        self.number_of_wheels = number


# instantiation
vento = Vehicle(4, 'diesel', 5, 250, 120)



#task manager demo
tasks = []

class Task:
    #class attribute
    task_app="Awase'List"

    def __init__(self, task_id, task_description, task_startdate, task_enddate, task_priority):
        self.task_id=task_id
        self.task_description = task_description 
        self.task_startdate = task_startdate
        self.task_enddate = task_enddate
        self.task_priority = task_priority
        
    def __str__(self):
        return "Task"

    
    def get_task_app(self):
        return self.task_app
        

#printing class attribute
print(Task.task_app)



#inheritance and polymorphism
students=[]
class Student:
    school_name = 'Excel Foundation School'
    
    def __init__(self, name, student_id):
        self.name = name
        self.student_id = student_id
        students.append(self)

    def get_school_name(self):
        return self.school_name 

    
#extending class or inheriting class 
class HighSchoolStudent(Student):

    school_name = "Excel High School"
    
    def get_school_name(self):
        return "I got a high school student here!"

sak = HighSchoolStudent("Awase",990008)

print(sak.get_school_name)

#Bird Classification 
class Bird:
    "Common base class for all bird species"
    bird_count=0

    #constructor/initializer 
    def __init__(self, bird_id, bird_type, bird_name, bird_size):
        self.bird_id = bird_id
        self.bird_type=bird_type 
        self.bird_name = bird_name
        self.bird_size = bird_size
        
    def displayCount(self):
        print("Total no of birs:%d" % Bird.bird_count)

    def displayBirdInfo(self):
        print("bird_id:", self.bird_id, "bird_type:",self.bird_type, "bird_name:",self.bird_name,"bird_size:", self.bird_size)


#subclassing 
class Eagle(Bird):
    def __init__(self, bird_id, bird_name, bird_type, bird_size, bird_isextinct):
        self.bird_isextinct = bird_isextinct
        super(Eagle, self).__init__(bird_id, bird_name, bird_type, bird_size)
        
    def eagleDetails(self):
        return (str(self.bird_id) + '' + self.bird_name + '' + self.bird_type + '' + self.bird_size + '' + self.bird_isextinct)
        
    def dietary(self):
        print(' I am non-vegetarian')

    
falcon = Eagle(1231314, "White Eagle", "Carnivore", "large", "No")
print(falcon.eagleDetails())


#financial account example 
class FinancialAccount:
    "Base class for Bank Account"

    #constructor/instantiation
    def __init__(self):
        self.balance = 0
        
    def withdraw(self, amount):
        self.balance -= amount
        print("post-withdraw-balance:",self.balance)
        return self.balance 

    def deposit(self, amount):
        self.balance+=amount 
        print("post-deposit-balance:", self.balance)
        return self.balance
        
#instantiation
rayyan_ac = FinancialAccount()

rayyan_ac.deposit(37161274)
rayyan_ac.withdraw(267213)

#inheritance
class MinimumBalanceAccount(FinancialAccount):
    def __init__(self, minimum_balance):
        self.minimum_balance = minimum_balance
        super(MinimumBalanceAccount, self).__init__()
        
    def withdraw(self, amount):
        if self.balance - amount < self.minimum_balance:
            print("Sorry! minimum balance has to be maintained")
        else:
            FinancialAccount.withdraw(self, amount)
            
#inheritance other example 
class Animal(object):
    def __init__(self, name, species):
        self.name = name
        self.species = species
        
    def getName(self):
        return self.name
        
    def getSpecies(self):
        return self.species
        
    def __str__(self):
        return "%s is %s" %(self.name, self.species)

    
#creating instance 
bruno=Animal("Brono","Dog")
print("bruno is a %s" % bruno.getSpecies())
violet=Animal("Violet","Parrot")
print("violet is a %s" %violet.getSpecies())

#creating a subclass 

class Dog(Animal):
    def __init__(self,name, best_friend):
        Animal.__init__(self, name, "Dog")
        self.best_friend=best_friend 
    
    def protect(self):
        return self.best_friend 


#instance of the subclass 
hunter=Dog('Hunter',True)
print(hunter.protect())


#Another Example 
class Polygon:
    def __init__(self, no_of_sides):
        self.n=no_of_sides 
        self.sides = [0 for i in range(no_of_sides)]
        
    def inputSides(self):
        self.sides = [float(input("Enter side"+str(i+1)+":"))for i in range(self.n)]

    def dispSides(self):
        for i in range(self.n):
            print("Side", i+1, "is",self.sides[i])



class Triangle(Polygon):
    def __init__(self):
        Polygon.__init__(self, 3)
        
    def findArea(self):
        a, b, c = self.sides
        #calculate the semi-perimeter 
        s = (a + b + c) / 2
        area = (s * (s - a) * (s - b) * (s - c)) ** 0.5
        print("The area of the triangle is %0.2f" % area)
        
t = Triangle()
t.inputSides()
t.dispSides()
t.findArea()


#conversion metrics 

class Length:
    
    __metric = {"mm" : 0.001, "cm" : 0.01, "m" : 1, "km" : 1000,
                "in" : 0.0254, "ft" : 0.3048, "yd" : 0.9144,
                "mi" : 1609.344 }

    def __init__(self, value, unit="m"):
        self.value = value
        self.unit = unit

    def Converse2Metres(self):
        return self.value * Length.__metric[self.unit]

    def __add__(self, other):
        l = self.Converse2Metres() + other.Converse2Metres()
        return Length(l / Length.__metric[self.unit], self.unit)

    def __str__(self):
        return str(self.Converse2Metres())

    def __repr__(self):
        return "Length(" + str(self.value) + ", '" + self.unit + "')"

if __name__ == "__main__":
    x = Length(4)
    print(x)
    y = eval(repr(x))

z = Length(4.5, "yd") + Length(1)
print(repr(z))
print(z)
#############################################

class Ccy:

    currencies = {'CHF': 1.0821202355817312,
                   'CAD': 1.488609845538393,
                   'GBP': 0.8916546282920325,
                   'JPY': 114.38826536281809,
                   'EUR': 1.0,
                   'USD': 1.11123458162018}

    def __init__(self, value, unit="EUR"):
        self.value = value
        self.unit = unit

    def __str__(self):
        return "{0:5.2f}".format(self.value) + " " + self.unit

    def changeTo(self, new_unit):
        """
        An Ccy object is transformed from the unit "self.unit" to "new_unit"
        """
        self.value = (self.value / Ccy.currencies[self.unit] * Ccy.currencies[new_unit])
        self.unit = new_unit

    def __add__(self, other):
        """
        Defines the '+' operator.
        If other is a CCy object the currency values
        are added and the result will be the unit of
        self. If other is an int or a float, other will
        be treated as a Euro value.
        """
        if type(other) == int or type(other) == float:
            x = (other * Ccy.currencies[self.unit])
        else:
            x = (other.value / Ccy.currencies[other.unit] * Ccy.currencies[self.unit])
        return Ccy(x + self.value, self.unit)


    def __iadd__(self, other):
        """
        Similar to __add__
        """
        if type(other) == int or type(other) == float:
            x = (other * Ccy.currencies[self.unit])
        else:
            x = (other.value / Ccy.currencies[other.unit] * Ccy.currencies[self.unit])
        self.value += x
        return self

    def __radd__(self, other):
        res = self +other
        if self.unit != "EUR":
            res.changeTo("EUR")
        return res

    # __sub__, __isub__ and __rsub__ can be defined analogue

x = Ccy(10, "USD")
y = Ccy(11)
z = Ccy(12.34, "JPY")
z = 7.8 + x + y + 255 + z
print(z)

lst = [Ccy(10, "USD"), Ccy(11), Ccy(12.34, "JPY"), Ccy(12.34, "CAD")]

z = sum(lst)

print(z)

####################################

class Cucy:

    currencies = {'CHF': 1.0821202355817312,
                   'CAD': 1.488609845538393,
                   'GBP': 0.8916546282920325,
                   'JPY': 114.38826536281809,
                   'EUR': 1.0,
                   'USD': 1.11123458162018}

    def __init__(self, value, unit="EUR"):
        self.value = value
        self.unit = unit

    def __str__(self):
        return "{0:5.2f}".format(self.value) + " " + self.unit

    def __repr__(self):
        return 'Ccy(' + str(self.value) + ', "' + self.unit + '")'

    def changeTo(self, new_unit):
        """
        An Ccy object is transformed from the unit "self.unit" to "new_unit"
        """
        self.value = (self.value / Ccy.currencies[self.unit] * Ccy.currencies[new_unit])
        self.unit = new_unit

    def __add__(self, other):
        """
        Defines the '+' operator.
        If other is a CCy object the currency values
        are added and the result will be the unit of
        self. If other is an int or a float, other will
        be treated as a Euro value.
        """
        if type(other) == int or type(other) == float:
            x = (other * Ccy.currencies[self.unit])
        else:
            x = (other.value / Ccy.currencies[other.unit] * Ccy.currencies[self.unit])
        return Ccy(x + self.value, self.unit)


    def __iadd__(self, other):
        """
        Similar to __add__
        """
        if type(other) == int or type(other) == float:
            x = (other * Ccy.currencies[self.unit])
        else:
            x = (other.value / Ccy.currencies[other.unit] * Ccy.currencies[self.unit])
        self.value += x
        return self

    def __radd__(self, other):
        res = self +other
        if self.unit != "EUR":
            res.changeTo("EUR")
        return res

    # __sub__, __isub__ and __rsub__ can be defined analogue


    def __mul__(self, other):
        """
        Multiplication is only defined as a scalar multiplication,
        i.e. a money value can be multiplied by an int or a float.
        It is not possible to multiply to money values
        """
        if type(other) == int or type(other) == float:
            return Ccy(self.value * other, self.unit)
        else:
            raise TypeError("unsupported operand type(s) for *: 'Ccy' and " + type(other).__name__)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __imul__(self, other):
        if type(other) == int or type(other) == float:
            self.value *= other
            return self
        else:
            raise TypeError("unsupported operand type(s) for *: 'Ccy' and " + type(other).__name__)


x = Cucy(10.00, "EUR")
y = Cucy(10.00, "GBP")
x + y
Cucy(21.215104685942173, "EUR")
print(x + y)

print(2 * x + y * 0.9)



#Class iterators 

class OReverse:
    """Iterator for looping over a sequence backwards"""

    def __init__(self, data):
        self.data = data
        self.index = len(data)
        

    def __iter__(self):
        return self

    
    def __next__(self):
        if self.index==0:
            raise StopIteration
        self.index=self.index-1 
        return self.data[self.index]

    
myrev = OReverse("Harry Potter and Chamber of Secrets")
iter(myrev)
for mychar in myrev:
    print(mychar)

#iterating a list 
for i in ["Syed Awase", "Syed Ameese", "Syed Azeez"]:
    print(i)

#iterating through a string to extract characters
for ch in "Syed Awase":
    print(ch)

# iterating through a dictionary
for k in {'user1': 99008, "user2": 96911, "user3": 98171}:
            print(k)


# static methods in classes
# Static method enables us to call via the class name or via the instance name, without the necessity of passing a reference to an instance of it.

# traditional approach
is_RockStar = True


def MyProgrammerCheck():
      return (is_RockStar == True)


class MyProgrammer(object):
      def __init__(self, data):
            self.data = data

      def do_learn(self):
            if ProgrammerCheck():
                  print(
                      "Programmer is a rock star he can self learn and deliver: Syed Awase!", self.data)

      def set_learn(self):
            if ProgrammerCheck():
                  self.external = "Not sure how he is!!"
                  print("Your request for Programmer::", self.data)


geekone = MyProgrammer("Narri")
geektwo = MyProgrammer("Barri")
geekone.do_learn()
geekone.set_learn()

# # above example using @staticmethod
isPlayer = True


class FootballPlayer(object):
      def __init__(self, data):
            self.data = data

      @staticmethod
      def does_perform():
            return (isPlayer == True)

      def overseas_Play(self):
            if self.does_perform():
                  print("Fit for Overseas Play:", self.data)

      def set_Play(self):
            if self.does_perform():
                  self.gethim = "get this player to play"
                  print("Football Play:", self.data)


messi = FootballPlayer("Lionel Messi")
messi.overseas_Play()
messi.set_Play()


# example two
class Demo:
      __counter = 0

      def __init__(self):
            type(self).__counter += 1

      @staticmethod
      def demoInstances():
            return Demo.__counter


if __name__ == "__main__":
      print(Demo.demoInstances())
      myval = Demo()
      print(myval.demoInstances())
      mysec = Demo()
      print(mysec.demoInstances())
      print(Demo.demoInstances())


#class methods
#class methods are bound to a class
# the first parameter of a class mehtod is a reference to a class 

class ClassWork:
    __counter = 0
    
    def __init__(self):
        type(self).__counter += 1
        
    @classmethod 
    def ClassWorkInstance(cls):
        return cls, ClassWork.__counter
        
    
if __name__ == "__main__":
    print(ClassWork.ClassWorkInstance())
    g = ClassWork()
    print(g.ClassWorkInstance())
    h=ClassWork()
    print(h.ClassWorkInstance())
    print(ClassWork.ClassWorkInstance())


#abstract class in python
class ClassAbstractDemo(object):
    """Abstract class"""
    def method_abstract(self):
        raise NotImplementedError
    def __init__(self):
        if type(self)==ClassAbstractDemo:
            raise Exception("Abstract Class Cannot be Instantiated")



#slots demo

class SlotTest(object):

    def __init__(self):
        print("lets create an object")

mynewobject = SlotTest()
mynewobject.name = "Syed Awase"
mynewobject.gender = "male"
#printing the object properties in dictionary format 
print(mynewobject.__dict__)           

#slot => avoiding dynamically created attributes 

class AnotherSlot(object):
    __slots__=['val']

    def __init__(self,v):
        self.val=v 

myxobj=AnotherSlot("SyedAwase")
print(myxobj.val)

#now lets add a new attribute to the object created
#it throws an error => unable to create dynamic attribute 
#myxobj.location = "hyderabad,india"

#TypeClass Demo 

class UsualClass(object):
    def __init__(self,name,email):
        self.name=name 
        self.email = email
        
uc=UsualClass("SyedAwase","awasekhirni@gmail.com")
print(uc)
print(type(uc))
print(dir())

#alternatively creating class with type
TypingClass= type("TypeClass", (object,),{"name":"Syed Azeez","email":"azeez@gmail.com"})

print(TypingClass)
print(type(TypingClass))
print(dir())

#alternatively creating class with type and functions 
def get_govtempid(self):
    return self.govtempid 

GovtEmployee=type('TypeClass',(object,),{'govtempid':432121,'govtempname':'Syed Awase Khirni',"get_govtempid":get_govtempid})

syed=GovtEmployee()
print(syed.get_govtempid())


#inheritance 
class Automobile:
    def start(self):
        print("Starting engine")

    def stop(self):
        print("Stopping engine")


class Bike(Automobile):
    def say(self):
        super().start()
        print("I am two wheeler bike")
        super().stop()


enfield = Bike()
enfield.say()


#class Aircraft
class Aircraft:
    """Aircraft Class Specification"""
    def __init__(self,registration):
        self.registration=registration 

    def registration(self):
        return self._registration  

    def number_of_seats(self):
        rows, row_seats=self.seating_plan()
        return len(rows)*len(row_seats)

class AirbusA319(Aircraft):
    def model(self):
        return 'Airbus A 319'

    def seating_plan(self):
        return range(1,23), "ABCDEF"

class Boeing777(Aircraft):

    def model(self):
        return "Boeing 777"

    def seating_plan(self):
        return range(1,56),"ABCDEFGHIJK"


#private methods and attributes 
class Car:
    def __init__(self):
        self.__wheels=list()
        self.__engine=None 
        self.__body=None 

    def setBody(self,body):
        self.__body=body 
    
    def attachWheel(self,wheel):
        self.__wheels.append(wheel)

    def setEngine(self,engine):
        self.__engine=engine 

    def specification(self):
        print('body:%s'%self.__engine.horsepower)
        print('engine horsepower:%d'%self.__engine.horsepower)
        print('tire size:%d'% self.__wheels[0].size)
        



        


#dictionary based classes 
class OldImage(object):
    def __init__(self,id,caption,url):
        self.id=id
        self.caption=caption 
        self.url =url 
        self._setup()
    
    def _setup(self):
        pass 

oldy=OldImage(13123,"michael-moore.jpeg","www.michael-moore.com")


class AndyImage(object):
    __slots=['id','caption','url']

    def __init__(self,id,caption,url):
        self.id=id 
        self.caption=caption 
        self.url = url 
        self._setup()

    def _setup(self):
        pass 


andy=AndyImage(13123,"michael-moore.jpeg","www.michael-moore.com")


import sys 

def compute_object_size(obj,seen=None):
    """compute the object size in a recursive manner"""
    size=sys.getsizeof(obj)
    if seen is None:
        seen=set()
    obj_id=id(obj)
    if obj_id in seen:
        return 0 
    seen.add(obj_id)
    if isinstance(obj,dict):
        size+=sum([compute_object_size(v,seen) for v in obj.values()])
        size+=sum([compute_object_size(k,seen) for k in obj.keys()])
    elif hasattr(obj,'__dict__'):
        size+=compute_object_size(obj.__dict__,seen)
    elif hasattr(obj,'__iter__') and not isinstance(obj,(str,bytes,bytearray)):
        size+=sum([compute_object_size(i,seen) for i in obj])
    return size 

print(compute_object_size(oldy))
print(compute_object_size(andy))




##another example 
class Part(object):
    __slots__=['part_number','part_name','unit_cost']

    def __init__(self,part_number, part_name, unit_cost):
        self.part_number=part_number 
        self.part_name=part_name 
        self.unit_cost = unit_cost 
    
    def total_cost(self,quantity):
        return self.unit_cost*quantity 
    


assembly = [(33, Part('BL273', 'bolts', 19.25)),
            (26, Part('GQ1283', 'gear', 53.75)),
            (18, Part('PT1262', 'piston', 12.50))]

print(sum(part.total_cost(quantity) for quantity, part in assembly))


#destroying an object 

class DestroyExample:
    def __init__(self):
        print("Object has been created")
    
    #destructor 
    def __del__(self):
        print("Object has been destroyed")


if __name__=="__main__":
    desdemo=DestroyExample()
    del desdemo #to delete the object explicitly 