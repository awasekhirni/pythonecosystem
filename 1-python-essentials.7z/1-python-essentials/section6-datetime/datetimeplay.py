"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
# using date and time in python


from datetime import date
import calendar
import datetime
now = datetime.datetime.now()
print("current data and time:", now.strftime("%Y-%m-%d %H:%M:%S"))


# calendar operations
yyyy = int(input("Please input the year:"))
mm = int(input("please input the month:"))
print(calendar.month(yyyy, mm))

# calculate the number of days between the current date and your birth date
myBirthdate = date(1975, 11, 3)
mycurrentdate = date(2013, 11, 3)
diff_dates = mycurrentdate - myBirthdate
print(diff_dates.days)
