"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

# python lists
# defining empty list
import ast
import random
import itertools
mylist = []

# lists and indexes
grocery_list = ["milk", "curd", "eggs", "carrot", "bread"]
print(grocery_list[0])  # printing the first element of the list
print(grocery_list[-1])  # printing the last element of the list

# to check whether an element exists in the list
"milk" in grocery_list == True

# to retrive the number of the elements in the list
len(grocery_list)

# to add or append an element to the end of the list
grocery_list.append("cake")
len(grocery_list)

# to completely remove or delete an element from the list
del grocery_list[3]
# the list shifts elements to the left after this operation
print(grocery_list)

# access the index of a list
for g_index, g_val in enumerate(grocery_list):
    print(g_index, g_val)

# list slicing
print(grocery_list[1:])  # skips the first element in the list
print(grocery_list[2:])  # skips two elements
print(grocery_list[1:-1])  # ignore the first and the last element in the list


# printing list elements in python
# loops allows us to iterate through the loops
for item in grocery_list:
    print("You have purchase this item in the list:{0}".format(item))


# write a function to compute the sum of items in the list
def compute_sum(items):
    mysum = 0
    for item in items:
        mysum += item
    return mysum


print(compute_sum([27, 28, 29, 31, 26, 49]))


# write a function to compute the multiplication of items int he list
def more_toPly(items):
    initial = 1
    for item in items:
        initial *= item
    return initial


print(more_toPly([23, 27, 29, 58, 65]))


# return the largest integer in the lists
def dec_order(list):
    decitem = list[0]
    for item in list:
        if item > decitem:
            decitem = item

    return decitem


print(dec_order([1, 9, 14, 2, 13, 64, 4, 31, 96, 3]))

#######################
#returning a new list on element insertion using + operator
publist=[1525,3736,37363,746463]

#printing the original list 
print("the original publist is:"+str(publist))

#lets add a new element to the list 
myel=23746

new_publist = publist+[myel]
#printing the new_publish 
print("the new list is:::"+str(new_publist))

#using * operator to add an element to the existing list 
oel=33748
oel_publish=[*publist, oel]

print("oel_list:::",str(oel_publish))

###################
# print unique items only in the list and remove duplicates
occur_twice = []
unique_list = set()
mylist = [11, 11, 123, 146, 26, 26, 93, 87, 78, 87, 65, 56, 65, 32, 23, 123]

for x in mylist:
    if x not in unique_list:
        occur_twice.append(x)
        unique_list.add(x)

print("unique_list:", unique_list)
print("mulitple_occurrence:", occur_twice)

myunique = set(mylist)
my_just = list(myunique)
print(my_just)

# check whether a list is empty or not
stcklist = []
if not stcklist:
    print("stcklist is empty")


# making a clone of the list
actual_list = [21, 312, 456, 758, 8712]
clone_list = list(actual_list)
print("actual_list:", actual_list)
print("clone list:", clone_list)


# identify long words from sentences

def identify_longwords(n, story):
    word_list = []
    story_words = story.split(" ")
    for word in story_words:
        if (len(word)) > n:
            word_list.append(word)
    return word_list


nsaleaks = """The leaks began in June. Edward Snowden, an NSA contractor, 
had collected a vast store of secret internal documents and began sharing 
them with journalistGlennGreenwald, TheWashingtonPost, and others.
The revelations were shocking: the scope and depth of the NSA’s collection of private data stopped looking like a conspiracy theory and became a cold, hard reality we all had to face. The leaks showed that the NSA has collected troves of phone records, spied on US citizens, and tapped the phones of foreign leaders.Over the last half of 2013, the relentless cadence of releases overwhelmed the government’s attempts to justify the NSA programs. Snowden himself, who ultimately landed in Russia, declared that he “already won, ” despite the likelihood that he will live his life in exile. Unfortunately, his claim to victory rings hollow — only now are committees and leaders beginning to take steps to bring about reform."""

print(identify_longwords(3, nsaleaks))


# compare two list and identify common elements in the list
def display_same(onelist, secondlist):
    result = False
    for x in onelist:
        for y in secondlist:
            if x == y:
                print(x, y)
                result = True
                return result


nse_stcknames = ["infy", "mahindra", "ntpc",
                 "sycliq", "tpri", "vdl", "spdl", "jcr"]
bse_stcknames = ["sycliq", "tpri", "ibm",
                 "cipla", "reddylabs", "mrgn", "rpg", "spt"]

print(display_same(nse_stcknames, bse_stcknames))


# to remove 3,5,7 item in a list of rejected candidates
selection_list = ["abu", "munna", "golu", "lambu", "chotu",
                  "shane", "ede", "sanki", "hawle", "pagle", "sandy", "aicy"]
newlist = [x for (i, x) in enumerate(selection_list) if i not in (3, 5, 7)]
print(selection_list)
print(newlist)


# write a program to print the numebrs of a specified list after removing odd numbers from it
myvalues = [231, 123, 124, 6573, 8126, 819, 7262,
            8171621, 8238271, 882, 7373, 1838, 2740587, 8382]
even_list = [x for x in myvalues if x % 2 == 0]
print(even_list)
print(myvalues[0-5])


# printing the difference between two lists
nse_stcknames = ["infy", "mahindra", "ntpc",
                 "sycliq", "tpri", "vdl", "spdl", "jcr"]
bse_stcknames = ["sycliq", "tpri", "ibm",
                 "cipla", "reddylabs", "mrgn", "rpg", "spt"]


print(list(set(nse_stcknames)-set(bse_stcknames)))


# print the index of an element in the list
# as python uses 0 based index, it should print 3
print(nse_stcknames.index("sycliq"))


# write a program to flatten a shallow list
orign = [[12, 123, 43, 43], [67, 827, 829, 9782], [91, 172], [812831, 18]]
mglist = list(itertools.chain(*orign))
print(mglist)

# appending a list to another list
firstone = [12123, 12361265, 12712612, 12827]
secondone = [28991, 9237, 28871, 9828]
final_list = firstone + secondone
print(final_list)

# select a random element form a list
color_list = ['violet', 'indigo', 'blue', 'green', 'yellow', 'orange', 'red']
print(random.choice(color_list))


# convert a list into dictionary
grocery_item = ["milk", "bread", "eggs", "butter"]
grocery_price = [120, 25, 60, 50]

print([{'grocery_item': gi, 'grocery_price': gp}
       for gi, gp in zip(grocery_item, grocery_price)])


# concatenate list items
clist = ['please', 'tell', 'me']
print('-'.join(clist))


# convert string to a list
carmodels = "['kicks','duster','reva','hx5']"
print(ast.literal_eval(carmodels))


# replacing last element in a list with another list
rlist = [2672, 2726, 3837, 38372, 38372]
rlist2 = [23917, 734, 463, 564, 747]
rlist[-1:] = rlist2
print(rlist)

# iterating over the two lists simultaneously
for(x,y) in zip(rlist,rlist2):
    print(x,y)

# check if the n-th element exists in a given list
seclist = [2161, 126, 2379, 957, 2826, 287362, 9827]
seclist_len = len(seclist) - 1
print(seclist[seclist_len])

# printing employee code with division prefix
print(['FIN-{0}'.format(i) for i in seclist])


# find all the values in a list are greater than a specified number 
scores = [86, 65, 23, 0, 15, 54, 67, 162, 182, 46, 1, 1, 1,]
print(all(x >= 65 for x in scores))


#check if all dictionaries in a list are empty or not
dict_list = [{}, {}, {}]
dicto_list = [{1, 2}, {}, {}]

print(all(not d for d in dict_list))
print(all(not d for d in dicto_list))

#########################
#summing list of lists 
nestList=[[1236132,1237712,12731713],
            [23788712387,12889123,12389913],
            [12387123,72372,2382387]]

#printing the initial list 
print("InitialList-",str(nestList))

#using naive method
resultantLis=list()
for j  in range(0,len(nestList[0])):
    tmpval=0
    for i in range(0,len(nestList)):
        tmpval=tmpval+nestList[i][j]
    resultantLis.append(tmpval)

#print final result 
print('finalresult:--',str(resultantLis))
#########################
#using numpuy to sum list of lists 
import numpy as np 
nestList=np.array([[1236132,1237712,12731713],
            [23788712387,12889123,12389913],
            [12387123,72372,2382387]])

#printing list 
print("Initial list---",str(nestList))
#using numpy sum 
resultVal=np.sum(nestList,0)
#printing final result 
print("final result using numpy is:", str(resultVal))

#########################
#using list comprehension and zip 

nestList=[[1236132,1237712,12731713],
            [23788712387,12889123,12389913],
            [12387123,72372,2382387]]

print("InitialList:::",str(nestList))
#using list comprehension 
sumlistResult=[sum(i) for i in zip(*nestList)]

#printing the final result
print("final list:::",str(sumlistResult))

#########################

#python code to iterate through tuples list of lists into a single list 
#using itertools.ziplongest 

from itertools import zip_longest 

intupleList=[
    [('6272'), ('782'), ('131')], 
         [('32721'), ('2726'), ('36353')], 
         [('56331'), ('47432'), ('82733')] 
]

#print initial list 
print("InitialList=",intupleList)

#iterate list tuples list of list into single list 
rest_list=[item for nuvoList in zip_longest(*intupleList) for item in nuvoList if item]

#print final results 
print("ResultantList:::=",rest_list)



#########################
#using itertools.ziplongest + lambda+chain 
from itertools import zip_longest, chain 

#initializing lists

intupleList=[
    [('6272'), ('782'), ('131')], 
         [('32721'), ('2726'), ('36353')], 
         [('56331'), ('47432'), ('82733')] 
]
#print initial list 
print("InitialList=",intupleList)

#computing result 
c_result=list(filter(lambda x:x,chain(*zip_longest(*intupleList))))

#print final resultset 
print("FinalResultset=", c_result)

#########################

#slicing list from jth element to the nth/last element

shareSlice=[126,2726,272,28727,272,274,687,4746]

#print original list 
print("the original shareSlice is:"+str(shareSlice))

#starting index to begin slicing 
str_slicer=3

#resulting sliced list 
leftover=shareSlice[str_slicer:None]
otherlis=shareSlice[str_slicer:]

#printing the results 
print("the final sliced list is:"+str(leftover))
print("the other sliced list is:"+str(otherlis))
#printing the last elemnt of the list 

for i in range(0,len(shareSlice)):
    if i ==(len(shareSlice)-1):
        print("the last element of the list is:"+str(shareSlice[i]))

#list pop 
print("the last element using pop() is:" +str(shareSlice.pop()))






#########################
#perform operation on kth element in the list 
temperature=[12.67,18.58,16.92,15.85,15.46,17.27,18.65]

mod_temp=[i+2 if j%2==0 else i for j,i in enumerate(temperature)]
print("the modified temperature list is:"+str(mod_temp))

#########################
#concversion of list elements to lower case 

funlist =["ScuBaDiving","KaYaking","BaDminton","BowLing"]

#print the original list 
print("the originallist:"+str(funlist))
#operations on eachlist elemnet using map() to transform from upper case to lower case 
new_fun=list(map(str.lower,funlist))
#########################
#inserting a character after every Nthe element.
# initializing list 
act_list = ['f', 'u', 'n', 'r', 'u', 'n', 'g', 'u', 
                            'n', 'b', 'u', 'n'] 
  
# printing original list 
print ("The original list is : " + str(act_list)) 
  
# initializing k  
k = 's'
  
# initializing N 
N = 3
  
# using join() + enumerate() 
# inserting K after every Nth number  
new_act = list(''.join(i + k * (N % 3 == 2)  
           for N, i in enumerate(act_list))) 
  
# printing result  
print ("The lists after insertion : " +  str(new_act)) 

#alternatively using itertools we can implement it 
from itertools import chain 
iter_result=list(chain(*[act_list[i : i+N] + [k]  
            if len(act_list[i : i+N]) == N  
            else act_list[i : i+N]  
            for i in range(0, len(act_list), N)])) 

#print the results after itertools 
print("itertools result:"+str(iter_result))

#########################
#perfoming duplication using itertools.chain from iterable 

import itertools 

#initializing list 
numlist=[26,376,2726,281,3827]
#printing the original list 
print("the original list is: "+str(numlist))

duplist = list(itertools.chain.from_iterable([i, i] for i in numlist)) 
  
# printing duplication elements list 
print ("The list after element duplication " +  str(duplist)) 

#########################
#last occurence of an element in a list 
# initializing list 
occ_list = ['f', 'u', 'n', 'b', 'u', 'n', 'r', 'u', 
                            'n', 'g', 'u', 'n'] 
  
# using join() + rfind() 
# to get last element occurrence 
last_occ = ''.join(occ_list ).rindex('u') 
  
# printing result 
print ("The index of last element occurrence: " + str(last_occ)) 

#retrieving the last element occurrence 
my_elem=len(occ_list)-1-occ_list[::-1].index('u')

###printing the element 
print("last occurence:"+str(my_elem))

#using max and enumerate to get the last element occurence 
me_elem_last=max(idx for idx, val in enumerate(occ_list)  
                                    if val == 'u')

#print 
print("last-element-using max and enumerate:"+str(me_elem_last))
#########################

# Program to find most frequent  
# element in a list 
  
def most_frequent(List): 
    counter = 0
    num = List[0] 
      
    for i in List: 
        curr_frequency = List.count(i) 
        if(curr_frequency> counter): 
            counter = curr_frequency 
            num = i 
  
    return num 

List = [45545,3435437,7688,223123, 13213213, 223123, 2223123, 1123213, 34545,45545,3435437,7688,32423,88766,2342,223123]

print(most_frequent(List)) 
#########################

from itertools import permutations 

mylist = list(permutations(range(1,7)))
print(mylist)