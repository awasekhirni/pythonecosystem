"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""


#copying a file 

file_one = open("orig.txt","r")
file2_copyto=open('duplicate.txt',"w")
myline = file_one.readline()
while myline:
    file2_copyto.write(myline)
    myline=file_one.readline()

file_one.close()
file2_copyto.close()



#delete a file 
import os 
myfile_to_delete = "/tmp/foo.txt"

if os.path.isfile(myfile_to_delete):
    os.remove(myfile_to_delete)
else:
    print("Error:%s file not found " % myfile_to_delete)


#alternatively deleting files in a directory 

import os 
import sys 
import shutil 

# fetch the directory name 
my_dir_todelfiles = input("Enter the directory name:")
try:
    shutil.rmtree(my_dir_todelfiles)
except OSError as e: 
    print ("Error: %s - %s." % (e.filename, e.strerror))


# delete files leaving the folder structure intact 
import os 
filestoRemoveinFolder='/path/to/folder'
fileList = os.listdir(filestoRemoveinFolder)

for file in fileList:
    filePath=filestoRemoveinFolder+"/"+file

    if os.path.isfile(filePath):
        os.remove(filePath)
    
    elif os.path.isdir(filePath):
        newFileList = os.listdir(filePath)
        for myfile in newFileList:
            insideFilePath= filePath+"/"+myfile

            if os.path.isfile(insideFilePath):
                os.remove(insideFilePath)





#recreating the file again once deleted 

import os 
mypath="/path/to/folder"
filename="sak"
if os.path.exists(mypath):
    os.system("cd %s" %mypath)
    os.system("rm -rf %s" %filename)
    print("file you specified is deleted")
    os.system("mkdir %s" %filename)
    print("new file with the same name has been recreated")
else:
    print("error")

#fetching the file creation and modification date/times 
import os.path,time 
print("last modified:%s" % time.ctime(os.path.getmtime("iosexplay.py")))
print("Created:%s"% time.ctime(os.path.getctime("iosexplay.py")))