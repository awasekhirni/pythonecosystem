from copy import deepcopy
"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""
# a tuple is a sequence of immutable python objects
# tupes are sequences just like lists.
# tuples cannot be changed unlike lists
# tuples use parentheses, where as lists use square brackets

mytrials = (121, 123, 145, 156, 171)
# create a tuple with different data types
myrosydet = ('syed awase', False, 3.14, 12131)
# empty tuples
myemptuple = ()
# accessing tuples
print("mytrials:", mytrials[0])
print("mytrials all:", mytrials[1:4])

# updating tuples
one_t = (12, 31.4)
two_t = ('press', 'prime')
three_t = one_t+two_t
print(three_t)

# get the length of the tuple
print(len(three_t))

# unpack a tuple into multiple variables
x, y = one_t
print(x+y)

# converting a tuple to a list
mylist = list(three_t)
# converting a list to tuple
triplex = tuple(mylist)

print(mylist)
print(triplex)

# converting a tuple to a string
wordplay = ('s', 'y', 'e', 'd', 'a', 'w', 'a', 's', 'e')
str = ''.join(wordplay)
print(str)
print(wordplay[5])
print(wordplay[-3])

# make a copy of tuple using deepcopy function
myclone = deepcopy(wordplay)
print(myclone)

# return the number of times an element occurs in the tuple
count = wordplay.count('e')
print(count)

# check whether an element exists within a tuple
print('a' in wordplay)

# using merge of tuples with the + operator you can remove an item and it will create a new tuple
first_name = wordplay[4:]
print(first_name)

# slice the tuple
shorty = wordplay[2:4]
print(shorty)

# get the index of the parameter passed in the tuple
myidx = wordplay.index('a')
print(myidx)

# reverse list
myrev = reversed(wordplay)
print(tuple(myrev))


# convert tuple to dict
# create a tuple
rumple = ((2, "w"), (3, "r"))
print(dict((y, x) for x, y in rumple))

#sort a tuple by its floating point element
price = [('item1', '12.20'), ('item2', '15.10'), ('item3', '24.5')]
print(sorted(price, key=lambda x: float(x[1]), reverse=True))

# print the length of the tuple
print(len(wordplay))


#example 
mytunn=("SyedAwase", 227)
mytunn=mytunn + ("Syed Ameese",212)
print(mytunn)

#loop through the elements with for loop 
for element in mytunn:
    print(element)

# check if an element exists in the tuple 
'SyedAwase' in mytunn #returns boolean
'SyedAwaseKhirni' in mytunn # returns boolean -false 

#repeat a tuple n no of times using * 
3*mytunn #repeats the tuples 3 times 

# check number of elements with len()
len(3*mytunn)
