"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#Comprehensions in Lists, Dict
#Generator Expressions and Nested Comprehensions

#listcomprehensions 


###############################
## add 2 to every kth element using list comprehension

# initializing list  
lvl_list = [731, 734, 538, 272, 6727, 218, 3719, 2612] 
  
# printing the original list 
print ("The original list is : " + str(lvl_list)) 
  
# using list comprehension + list slicing 
# Edit every Kth element in list  
# add 2 to every 3rd element 
lvl_list[0::3] = [i + 2 for i in lvl_list[0 :: 3]] 
  
# printing result 
print ("The list after editing every kth element : "
                                   + str(lvl_list)) 


################################
#element duplication using list comprehension 
official_list_id=[2123,21378,72651,63535,262541,476499,893725]

#print the original list 
print("the original list is:"+str(official_list_id))

#list comprehension to perform element duplications 
lc_list=[i for i in official_list_id for x in (0,1)]

#printing the result
print("the list after element duplications is :"+str(lc_list))


##############################
#list comprehension operations on each list element 
#upper casing each element in the list 
minorityList=['awase','ameese','rayyan','azeez','rafiq','razia','nayyirah','luqman','sadath','nazia','rehan','imad','hassan','rubi','zeba']

#printing the origingal list 
print("the original minority list is:"+str(minorityList))

#converting each list element to upper case 
u_minority=[i.upper() for i in minorityList]
#printing the final result after uppercase transformation 
print("uppercase names:"+str(u_minority))

#list comprehension operations 
from math import sqrt 
for i in range(10):
    print(sqrt(i))

#implementing a list comprehension 
[print(sqrt(i) for i in range(10))]


#filtering list comprehensions 
for i in range(20):
    if i%2:
        continue 
    print(i)


#list comprehension 
[print(i) for i in range(20) if not i%2]


#breaking list comprehensions 
#not possible to break a list comprehension 
# only possible with generator expression. 




#############################
#Dictionary Comprehensions 

products='stapler','monitor','office table','grinder','carromboard','badminton racket','shoes'
category='stationery','electronics','furniture','home appliances','indoor games','indoor games','mens wear'
amazing_cart=dict(zip(products,category))
print(amazing_cart)

#old approach without comprehensions 
d={}
for products,category in zip(products,category):
    d[products.capitalize()]=category.capitalize()
print(d)

#dictionary comprehensions 
d={products.capitalize():category.capitalize() for products,category in zip(products,category)}
print(d)

#old approach filtering dict comprehensions 
md={}
for products,category in zip(products,category):
    if category=='indoor games':
        continue 
    md[products.capitalize()]=category.capitalize()
print(md)

#filtering dict comprehensions 
md={
    products.capitalize():category.capitalize() 
    for products,category in zip(products,category)
    if category !='indoor games'
    }
print(md)



#################################################

#Generator expressions 

#old approach 
from math import sqrt 
#g=(sqrt(j)) for j in range(20))
#for j in g:
#    print(j)


#generator expression 
mygen=(sqrt(i) for i in range(3))
print(next(g))
print(next(g))
print(next(g))
print(next(g))#stopIteration called 


#filtering generator expressions 
evno=(k for k in range(10) if i%2)
for k in evno:
    print(k)

#breaking generator expression 
def fibonacci():
    yield 1
    yield 1
    vmlist=[1,1]
    while True:
        vmlist=[vmlist[-1],sum(vmlist[-2:])]
        yeild vmlist[-1]
    

class EndGenerator(Exception):pass 

def stop():
    raise StopIteration()

def wrap(g):
    mylist=[]
    while True:
        try:
            mylist.append(next(g))
        except EndGenerator:
            break 
    return mylist 



myg=wrap(i for i in fibonacci() if i<10 or stop())
for i in myg:
    print(i)



#nested comprehension 


grid=[]
for x in range(2):
    for y in range(2):
        grid.append((x,y))
print(grid)

# generator function
def mygr(pos):
    print(pos)
    yield 1
    print(pos)
    yield 2

mygrid =[(x,y) for x in mygr('outerloop') for y in mygr('innerloop')]
print(mygrid)
 
#python has several convinience functions for working with iterators 
# zip(), map(),enumerate() and filter()

products=['stapler','monitor','office table','grinder','carromboard','badminton racket','shoes']
category=['stationery','electronics','furniture','home appliances','indoor games','indoor games','mens wear']
rating=[4,3,5,4,3,3,4]

for products,category, ranking in zip(products,category,rating):
    print("this %s product is of %s and has a rating of %s"%(products,category,rating))



#map() applying a function to each element from an iterator 

from math import sqrt 
doubleyourmoney=[122,1233,362,827,172]
for h in map(sqrt,doubleyourmoney):
    print(h) # you end up loosing money for greed

#generator expression 
for k in (sqrt(m) for m in doubleyourmoney ):
    print(k)


################################################
#enumerate() to get the indices with elements 

#demo without enumerate 
products=['stapler','monitor','office table','grinder','carromboard','badminton racket','shoes']
c=0
for products in products:
    print(c,products)
    c+=1 


#demo using enumerate from itertools 
for x, products in enumerate(products):
    print(x,products)


#generator expression 
for y, products in (y, products[y]) for y in range(len(products))):
    print(y,products)


###################################
#filter is used to exclude elements or data filtering 

rating=[4,3,5,4,3,3,4]

#without filter 
for r in rating:
    if i%2:
        continue 
    print(r)


#using filter 
for f in filter(lambda f:not f%2,rating):
    print(f)


#generator expression 
for g in (g for g in rating if not g%2):
    print(g)

##################################
#numerical functions 
#built-in functions that work with iterators 

none_true =[0,0,0]
some_truth=[0,1,0]
all_true=[1,1,1]

def truthyCheck(t):
    for e in t:
        if e:
            return True 
        return False 



truthyCheck(none_true)
truthyCheck(some_truth)
truthyCheck(all_true)

#using any 
#any() checks if any elements evaluate to true
any(none_true)
any(some_truth)
any(all_true)



############
#generator expression implementation 
True in (bool(e) for e in all_true)
True in (bool(e) for e in some_truth)


######################
#all() checks if all elements evaluate to be TRUE 


def check_all(k):
    for e in k:
        if not e:
            return False 
    return True 

check_all(none_true)
check_all(some_truth)

#using all()
all(some_truth)


#generator expression 
False not in (bool(e) for e in some_truth)

#################
#sorted() takes an iterator with numeric elements and sorts it 
#min() miniumum 
#max() maximum 


