import operator
"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

# dictionaries are key value pairs
profiler = {'name': 'Syed Awase', 'age': 32,
            'specialisation': 'geographic information systems', 'qualification': 'Ph.D'}
print("profile:" + str(profiler))
print(profiler['name'])
# adding a new entry to the dictionary
profiler['university'] = 'University of Zurich'

# updating the dictionary
profiler['age'] = 33

print(str(profiler))

# gets the total length of the dictionary
print(len(profiler))

# gett the type of the passed variable
print(type(profiler))

# print the values of the dictionary
print(profiler.values())

# print the keys of the dictionary
print(profiler.keys())

# sorting dictionary in ascending and descending order
mysorted_val = sorted(profiler.items(), key=operator.itemgetter(0))
print("dictionary sorted by ascending order:", mysorted_val)
other_sort = sorted(profiler.items(), key=operator.itemgetter(0), reverse=True)
print("dictionary sorted by descending order:", other_sort)


# adding a key to a dictionary
profiler.update({'company': 'TPRI'})
print("with updated values:"+str(profiler))


# removing elements from dictionary
del profiler['university']
print(str(profiler))
# removing all elements from the dictionary
profiler.clear()
print(str(profiler))

# combine multiple dictionaries into one by concatenating them
basket_one = {'item1': 'milk', 'item2': 'eggs', 'item3': 'bread'}
basket_two = {'item4': 'shaving cream', 'item5': 'shampoo', 'item6': 'cologne'}
basket_three = {'item7': 'beer', 'item8': 'wine', 'item9': 'soda'}
ttl_basket = {}
for d in (basket_one, basket_two, basket_three):
    ttl_basket.update(d)
print('All items in one basket:', ttl_basket)
print(len(ttl_basket))

# check if a given key already exists in a dictionary


def check_key(x):
    if x in ttl_basket:
        print("key is present in the dictionary")
    else:
        print("key is not present in the dictionary")


check_key('item10')
check_key('item9')

# iterate over dictionaries using for-loop
for dict_key, dict_value in ttl_basket.items():
    print(dict_key, '->', dict_value)


# write a python script to generate and print a dictionary that contains a number between 1 and n
myselection = int(input('please enter a number:'))
selectedval = dict()

for x in range(1, myselection+1):
    selectedval[x] = x*x


print(selectedval)


# merge two python dictionaries
emp1 = {'name1': 'Syed Awase', 'salary1': 3000000}
emp2 = {'name2': 'Syed Sadath', 'salary2': 2500000}
employees = emp1.copy()
print("merged list of employees:"+str(employees))
employees.update(emp2)
print("merged list of employees:"+str(employees))
# merge two python dictionaries -scenario 2
test1 = {'candidate': 'syed awase', 'score': 89}
test2 = {'candidate': 'syed azeez', 'score': 90}
exam = test1.copy()

exam.update(test2)
print('merged lists is:'+str(exam))

# iterate over dictionaries using for-loop
parties = {
    'congress': 910012,
    'bjp': 910018,
    'jp': 910013,
    'tdp': 910014,
    'trs': 910015,
    'jds': 910016
}

for key, value in parties.items():
    print(key, 'identified by', parties[key])

# sum all the items in a dictionary
grocery_items = {'item1': 123, 'item2': 23,
                 'item3': 321, 'item4': 82, 'item5': 847, 'item6': 817, 'item8': 67, 'item9': 91}


print("total amount in the cart:" + str(sum(grocery_items.values())))

#multiply all items in a dictionary 
mul_result=1
for key in grocery_items:
    mul_result = mul_result*grocery_items[key]

print(mul_result)

#removing a key from the dictionary 
if 'item6' in grocery_items:
    del grocery_items['item6']

print(str(grocery_items))

#map two lists into a dictionary 
color_code=["violet","indigo","blue","green","yellow","orange","red"]
color_val = ['#9400D3',  '#4B0082', '#0000FF','#00FF00','#FFFF00','#FF7F00','#FF0000']
color_diction=dict(zip(color_code, color_val))
print(str(color_diction))

#sorting a dictionary by key 
for key in sorted(color_diction):
    print("%s:%s" %(key, color_diction[key]))


#identify the maximum scores and minimum scores from a test cricket match 
testcricket_score={'klrahul':32,'mvijay':65,'capujara':62,'vkohli':9,'amrahane':18,'rgsharma':35,'rashwin':40,'wpsaha':0,'rajadeja':42,'mohdshami':0,'utyadav':9}

max_scorer=max(testcricket_score.keys(), key=(lambda k:testcricket_score[k]))
min_scorer = min(testcricket_score.keys(),key=(lambda k: testcricket_score[k]))

print("Maximum Batsman Score:", testcricket_score[max_scorer])
print("Minimum Batsman Score:", testcricket_score[min_scorer])


#return a dictionary from an object's properties 

class returnDictionaryField(object):
    def __init__(self):
        self.name='Syed Awase Khirni'
        self.age=33
        self.company='TPRI'
        self.qualification='PhD'
        self.made=True 
    def do_nothing(self):
        pass 

researcher = returnDictionaryField()
print(researcher.__dict__)

#remove duplicates from a dictionary data set 
hindi_movies={
    'id1':{'name':'3idiots', 'rating':5,'lang':'hindi'},
    'id2':{'name':'pk', 'rating':5,'lang':'hindi'},
    'id3':{'name':'lagaan', 'rating':5,'lang':'hindi'},
    'id4': {'name': '3idiots', 'rating': 5, 'lang': 'hindi'},
}

uniquelist={}

for key,value in hindi_movies.items():
    if value not in uniquelist.values():
        uniquelist[key]=value

print(uniquelist)

#to check a dictionary is empty or not 
if not bool(uniquelist):
    print("Dictionary list is empty")

#combine two dictionaries adding values for common keys 
from collections import Counter 
mgroad_store={'grinder':14,'tv':48,'fans':23,'cooker':143}
koramangla_store= {'grinder':26,'tv':45,'fans':87,'cooker':12}
kalyanngr_store={'grinder':68,'tv':12,'fans':46,'cooker':26}
ttl_stock=Counter(mgroad_store)+Counter(koramangla_store)+Counter(kalyanngr_store)

print("total stock in bangalore stores are:"+str(ttl_stock))


# print all unique values in a dictionary 
shuffle_list = [{'a': 'in12912'}, {'b': 'rj122'}, {'c': 'ck1912'},{'a':'in12912'},{'e':'if991'},{'f':'ig4912'}]
uvalue=set(val for dic in shuffle_list for val in dic.values())

print('Unique values:', uvalue)


#identify the top 3 values in a dictionary 
from heapq import nlargest 
testcricket_score={'klrahul':32,'mvijay':65,'capujara':62,'vkohli':9,'amrahane':18,'rgsharma':35,'rashwin':40,'wpsaha':0,'rajadeja':42,'mohdshami':0,'utyadav':9}
topthree = nlargest(3,testcricket_score, key=testcricket_score.get)
print(topthree)


#program to create a dictionary from a string 
from collections import defaultdict, Counter 
mystatement="chainkullikimainkullikichain"
jodha={}
for alphabet in mystatement:
    jodha[alphabet]=jodha.get(alphabet,0)+1

print(jodha)

#print the dictionary in table format 
yearly_stats={'months':[1,2,3,4,5,6,7,8,9,10,11,12],'mgroad':[4233,3433,6442,5432,66444,2322,43453,6232,123123,234234,233223]}
for row in zip(*([key]+(value)for key, value in sorted(yearly_stats.items()))):
    print(*row)


#convert a list into a nested dictionary of keys
schindlerslist=[21,126,2626,1278]
killdictator=current={}
for val in schindlerslist:
    current[val]={}
    current=current[val]
print(killdictator)



#sort a list alphabetically in a dictionary 
num = {'a1': [2, 3, 1], 'a2': [5, 1, 2], 'a3': [3, 2, 4]}
sorted_dict = {x: sorted(y) for x, y in num.items()}
print(sorted_dict)

#remove spaces from the dictionary keys 
course_list = {'IS  001': ['Math', 'Science'], 'CP    002': ['Math', 'English']}
print("Original dictionary: ", course_list)
course_dict = {x.translate({32: None}): y for x, y in course_list.items()}
print("New dictionary: ",course_dict)

# get the top 3 items sold on amazon
from heapq import nlargest 
from operator import itemgetter 
amazon_basket={'baseball':234,'badminton':322,'bulb':1232124,'sweater':34322,'harddisk':132221,'reebok':54323}
for name,val in nlargest(3, amazon_basket.items(), key=itemgetter(1)):
    print(name,val)


#retrieve key,value and  item occured in the dictionary 
store_purchases={'chips':10,'eggs':32,'bread':12,'jam':72,'bread':13,'eggs':38,'juice':47,'carrot':12,'sandwich':38}
print("key  | value   |  count")
for count, (key,value) in enumerate(store_purchases.items(),1):
    print(key,'     ',value,'      ',count)


#to check if multiple keys exist in a dictionary 

professor={
    'name':'syed awase',
    'session':'geographic information systems',
    'classof':2007,
    'institution':'iiitb',
    'topstudent':'mohammed imaduddin'
}

print(professor.keys()>={'classof','topstudent'})
print(professor.keys()>={'session',2007})
while professor:
    info,class_=professor.popitem()
    print(info,class_)

#count the number of items in a dictionary value 
gennum = {'a1': [2, 3, 1], 'a2': [5, 1, 2], 'a3': [3, 2, 4]}
ktr=sum(map(len,gennum.values()))
print(ktr)


#match key values in two dictionaries 
x = {'key1': 1, 'key2': 3, 'key3': 2}
y = {'key1': 1, 'key2': 2}
for (key, value) in set(x.items()) & set(y.items()):
    print('%s: %s is present in both x and y' % (key, value))



#sort dictionaries by key or value 
#create a dictionary and display its keys alphabetically
#display both the keys and values sorted in alphabetical order by the key. 
# alternatively display both the keys and values sorted in alphabetical order by value. 

def myDictionaryStore():
    key_value={}

    #intializing valu e
    key_value[12]=32652
    key_value[5]=875534
    key_value[4]=63431
    key_value[3]=98767
    key_value[2]=6342
    key_value[1]=45321
    key_value[11]=523423
    key_value[9]=86533
    key_value[10]=97654
    key_value[7]=23423
    key_value[8]=53423
    key_value[6]=55432

    print("Task1:-\n")
    print("Keys are:")
    #iterate over the keys 

    for i in sorted (key_value.keys()):
        print(i, end=" ")


    print("Task2:=\n")
    print("keys and values are:")
    for j in sorted (key_value):
        print((j, key_value[i]),end=" ") 


    print("Task3=\n")
    print("keys and values are:")
    print(sorted(key_value.items(),key=lambda kv:(kv[1],kv[0])))


def main():
    myDictionaryStore()


#main function calling 
if __name__=="__main__":
    main()



######
#difference in keys in two dictionaries 

familia1= {'one':'syedawase', 'two':'syedameese', 'three':'syedazeez'} 
familia2= {'one':'syedawase', 'two:':'syedrayyan'} 
  
diff = set(familia2) - set(familia1) 
  
# Printing difference in 
# keys in two dictionary 
print(diff) 



# Python code to find difference in keys in two dictionary 
  
# Initialising dictionary  
grocerylist= {'one':'milk', 'two':'ghee'} 
purchaselist= {'one':'milk', 'two':'ghee', 'three':'geeks', 
        'four': {'fourone': 12, 'fourtwo': 22, 'fourthree': 32 }} 
  
for key in purchaselist.keys(): 
    if not key in grocerylist: 
  
        # Printing difference in 
        # keys in two dictionary 
        print(key) 



# Python code to find difference in keys in two dictionary 
  
# Initialising dictionary  
grocerylist= {'one':'milk', 'two':'ghee'} 
purchaselist= {'one':'milk', 'two':'ghee', 'three':'geeks', 
        'four': {'fourone': 12, 'fourtwo': 22, 'fourthree': 32 }}
          
for key in grocerylist.keys(): 
    if not key in purchaselist: 
  
        # Printing difference in 
        # keys in two dictionary 
        print(key) 


# Python code to find difference in keys in two dictionary 
  
# Initialising dictionary  
grocerylist= {'one':'milk', 'two':'ghee'} 
purchaselist= {'one':'milk', 'two':'ghee', 'three':'geeks', 
        'four': {'fourone': 12, 'fourtwo': 22, 'fourthree': 32 }} 
          
print(set(grocerylist.keys()).intersection(purchaselist.keys())) 


# Python3 code to demonstrate  
# to convert dictionary of list to  
# list of dictionaries 
# using list comprehension 
  
# initializing dictionary 
ielts_scores = { "syed_rs" : [8.5, 8], "aicysk_rs" : [7, 7.5], "azeez_rs" : [8, 7] } 
  
# printing original dictionary 
print ("The original dictionary is : " + str(ielts_scores)) 
  
# using list comprehension 
# to convert dictionary of list to  
# list of dictionaries 
res = [{key : value[i] for key, value in ielts_scores.items()} 
         for i in range(2)] 
  
# printing result 
print ("The converted list of dictionaries " +  str(res)) 



# Python code to split into even and odd lists 
# Funtion to split 
def Split(mix): 
    ev_li = [] 
    od_li = [] 
    for i in mix: 
        if (i % 2 == 0): 
            ev_li.append(i) 
        else: 
            od_li.append(i) 
    print("Even lists:", ev_li) 
    print("Odd lists:", od_li) 
  
# Driver Code 
mix = [2, 5, 13, 17, 51, 62, 73, 84, 95] 
Split(mix) 


##############################################################################################
# given a list of dictionaries, return a single dictionary with sum values with the same key 

import collections,functools,operator

#initializing the list of dictionary 
yearonsales=[{'mercedes':354,'subaru':1635,'toyota':2726},
{'mercedes':456,'subaru':1432,'toyota':5673},
{'mercedes':564,'subaru':5442,'toyota':7865},
{'mercedes':453,'subaru':6542,'toyota':8754},
{'mercedes':458,'subaru':6654,'toyota':9878},
]
#printing the yearonsales values 
print("the initial dictionary", str(yearonsales))

#sum the values with same keys 
fiveyearsalesResult = dict(functools.reduce(operator.add,map(collections.Counter,yearonsales)))

print('the results:',str(fiveyearsalesResult))


#alternatively 
#alternatively 
mycounter=collections.Counter()
for d in yearonsales:
    mycounter.update(d)

result=dict(mycounter)

print("summed dictionary", str(mycounter))


#alternatively
from operator import itemgetter 

otherapprresult={}
for g in yearonsales:
    for k in g.keys():
        otherapprresult[k]=otherapprresult.get(k,0)+g[k]

print("other approach result:",str(otherapprresult))



######################################
#sorting dictionaries by values 
from operator import itemgetter 

#product likes 
product_likes=[
    {'pName':"Sony Z1 Ultra",'likes':252516,'ranking':'B'},
     {'pName':"Samsung S4",'likes':152516,'ranking':'C'},
      {'pName':"iPhone S6",'likes':752516,'ranking':'A'},
       {'pName':"Lenovo Zuk2",'likes':352516,'ranking':'B'},
        {'pName':"Opp Note",'likes':52516,'ranking':'E'},
         {'pName':"One+ 5",'likes':652516,'ranking':'B'}

]

#using sorted and itemgetter to print list sorted by likes 
print("the printed sorting by likes:")
print(sorted(product_likes,key=itemgetter('likes')))

print("\r")
#alternatively group sorting 
print(sorted(product_likes,key=itemgetter('likes','ranking')))

#reverse sorting 
print(sorted(product_likes,key=itemgetter('likes'),reverse = True))



#####################################################
#sort list of dictionaries by values in Python – Using lambda function


#product likes 
product_likes=[
    {'pName':"Sony Z1 Ultra",'likes':252516,'ranking':'B'},
     {'pName':"Samsung S4",'likes':152516,'ranking':'C'},
      {'pName':"iPhone S6",'likes':752516,'ranking':'A'},
       {'pName':"Lenovo Zuk2",'likes':352516,'ranking':'B'},
        {'pName':"Opp Note",'likes':52516,'ranking':'E'},
         {'pName':"One+ 5",'likes':652516,'ranking':'B'}

]


# using sorted and lambda to print dictionaries list in ascending order by likes
print("sorted and lambda to print dictionaries list ")
print(sorted(product_likes, key = lambda j: j['likes']))
  
print ("\r") 
  
# using sorted and lambda to print list sorted  
print("Ascending order to print by likes and ranking")
print(sorted(product_likes, key = lambda k: (k['likes'], k['ranking'])))
  
print ("\r") 
  
# using sorted and lambda to print list sorted 
#  in descending order 
print("sorting in descending order: ")
print(sorted(product_likes, key = lambda j: j['likes'],reverse=True))


#merging two dictionraries 
def DictionaryMerge(dictOne,dictTwo):
    d_result={**dictOne,**dictTwo}
    return d_result 


if __name__=="__main__":
    walmart_houston={'sony_xperia':12312,'one_plus':1271287}
    walmart_boston={'iphone':37366,'samsung_s8':2372}
    walmart_usa=DictionaryMerge(walmart_boston,walmart_houston)
    print(walmart_usa)