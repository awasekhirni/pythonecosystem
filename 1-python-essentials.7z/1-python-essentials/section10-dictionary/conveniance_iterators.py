"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#standard tuples uses numerical indexes to access its members 

myprofile=('SyedAwase',37,'male','PhD','University of Zurich')
print("Profile:",myprofile)

mystatsProf=('ProfX',48,'male','PhD','ETHZ')

print("Tuple access by Index:",mystatsProf[0])

#printing the fields by index 
for e in [myprofile,mystatsProf]:
    print('%s is a %d year old %s and has earned %s, %s' % e) 

######################
#namedtuple demo 

import collections 

Actor=collections.namedtuple('Actor','name age gender country')

print("Type of Person:",type(Actor))

joey=Actor(name="Joey", age=28,gender="male")
print("Friends Actor:", joey)

phoebe=Actor(name="Phoebe",age=27,gender="female")

print("All the fields of namedtuple by index")
for elem in [joey,phoebe]:
    print('%s is a %d year old %s' % elem)


###
#example named tupe 
from collections import namedtuple

Product = namedtuple('Product',['name','warranty','manufacturedDate'])

sony= Product(name="Sony Z1",warranty="3", manufacturedDate="2016/11/29")
print('%s is manufactured on %s and has a warranty of %s' %(sony.name, sony.manufacturedDate,sony.warranty))


#orderedDictionary 
from collections import OrderedDict 

kategories=OrderedDict([
    ('electronics','television'),
    ('electronics','geyser'),
    ('electricals','fuse'),
    ('computing','keyboard')
])

for categories, class_ in kategories.items():
    print('%s belongs to %s' %(categories,class_))


#default dictionary in python collections 
from collections import defaultdict 

teamskills={
    "syedawase":"GIS",
    "syedameese":"DotNet",
    "syedazeez":"java"
}

#print(teamskills.get('rayyan', 'scala'))

d=defaultdict(lambda:'Rust')
d.update(teamskills)
print(d['shagufta'])
