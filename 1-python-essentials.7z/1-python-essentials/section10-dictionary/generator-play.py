"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#Generator Implementation
#It contains one or more yield statement. 
#When called, it returns an object(iterator) but does not start execution immediately. 
#Methods like __iter__() and __next__() are implemented automatically. So, we can iterate through the items using next()

#Once the function yields, the function is paused and the control is transferred to the caller. 
#Local variables and their states are remembered between successive calls.
#When the function terminates, StopIteration  is raised automatically on further calls.


def my_generatorfunction():
    yield 'SyedAwase'
    yield 'SyedAmeese'
    yield 'SyedAzeez'
    yield 'SyedRayyan'

for e in my_generatorfunction():
    print(e)

print("SyedAwase" in my_generatorfunction())
#return True 

mygs= my_generatorfunction()
print(next(mygs))
print(next(mygs))
print(next(mygs))
print(next(mygs))
#print(next(mygs))

#sending information to a generator 
import random 

POLPROMISES=[
    'I will give you 15 lakhs in your account 2014',
    'I will provide jobs for every india in 2014',
    'I will remove corruption',
    'I will change currency',
    'I will implement GST',
    'I will eliminate all my rivals',
    'I will make india safer',
    'I will bring the value of one us dollar to 20 rupees by 2019',
    'If i do not do it, burn me in 2019'
]

def mypol_promises():

    vaada_raha=yield 'Mitron',
    while vaada_raha!='propaganda':
        vaada_raha= yield random.choice(POLPROMISES)
election_manifesto = mypol_promises()
#since the generator gives output, before it receives input, the first send() must send None.
print(election_manifesto.send(None))
while True:
    try:
        reply=election_manifesto.send(input())
    except StopIteration:
        break 
    print(">>>"+reply)
print('Conversation over!')



#Eager Evaluation vs Lazy Evaluation


#EagerEvalution demo 
def eagereval_fibonacci(n):
    """ Eager Evaluation Fibonacci Series """
    num=[1,1]
    for i in range (n-2):
        num.append(sum(num[-2:]))
    return num

print(eagereval_fibonacci(20))



#Lazy evaluation implementation 
def lazyeval_fibonacci():
    yield 1
    yield 1
    k=[1,1]
    while True:
        k=[k[-1],sum(k[-2:])]
        yield k[-1]


#looping to generate no
for j,n in enumerate(lazyeval_fibonacci()):
    #checking the limit as this is infinite loop
    if j == 20:
        break
    print(n)



#coroutine implementation in python using zip 
#generator
def myfibonacci():
    yield 1 
    yield 1
    myno=[1,1]
    while True:
        myno=[myno[-1],sum(myno[-2:])]
        yield myno[-1]


def tribonacci():
    yield 0
    yield 1
    yield 1
    triple=[0,1,1]
    while True:
        triple = [triple[-2],triple[-1],sum(triple[-3:])]
        yield triple[-1]


for j,(s,t) in enumerate(zip(myfibonacci(),tribonacci())):
    if j==6:
        break
    print("coroutine demo using fibonacci and tribonacci")
    print(s,t)


#coroutine chaining example 
def sentence_splitter(mysentence,next_coroutine):
    """sentence splitter and feeds to the pattern_search coroutine"""
    mytokens = mysentence.split(" ")
    for token in mytokens:
        next_coroutine.send(token)
    next_coroutine.close()

def pattern_search(pattern="ly",next_coroutine=None):
    """search for the pattern"""
    print("searching for the pattern {}",format(pattern))
    try:
        while True:
            token=(yield)
            if pattern in token:
                next_coroutine.send(token)
    except GeneratorExit:
        print("We have found your pattern here!!!")

def print_token():
    """printing the received tokens"""
    try:
        while True:
            token=(yield)
            print(token)
    except GeneratorExit:
        print("Job Done")

ps=print_token()
ps.__next__()
ps=pattern_search(next_coroutine=ps)
ps.__next__()

statement = "While shelly was acting silly, rayyan was gently trying to slip away "
sentence_splitter(statement,ps)



##########################################
###IELTS EXAMINATION DEMO using Coroutine generators 
import random 

QUESTIONS=[
    "Describe about yourself?",
    "What do you?",
    "Do you like to have coffee?",
    "How often do you have coffee?",
    "Do you like your current job and Why?",
    "How do we eradicate fascism and racism in society?",
    "How do we eradicate nepotism in office culture?",
    "Are humans insecure, that they always cling to their ghettos based on race and culture?",
    "In the west,we have white and black ghettos, how are these ghettos similar to the ghettos in your country, give examples.",
    "Good chatting with you!",
    "Thankyou and Good Bye!"

]

ANSWERS=[
    "I am Syed Awase",
    "applied researcher",
    "No thank you",
    "Never",
    "gives me freedom, to work with diverse companies",
    "Equal opportunity and education",
    "Yes",
    "Yes, Caste Ghettos",
    "Same here",
    "Thankyou and Good Bye!"
]

def examiner():
    while True:
        yield random.choice(QUESTIONS)


def responder():
    while True:
        msg = yield 
        print("Response Received: %s" % msg)
        if msg== "Thankyou and Good Bye!":
            break 
        print('Response Received: %s' % random.choice(ANSWERS))

e=examiner()
r=responder()
r.send(None)
while True:
    res=e.send(None)
    try:
        r.send(res)
    except StopIteration:
        break











