"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

mytestScores = 78,86,83,79,81,87,88,89
i=iter(mytestScores)
print(next(i))
print(next(i))
print(next(i))
print(next(i))
print(next(i)) 
print(next(i))
print(next(i))
print(next(i))
print(next(i)) # we receive StopIteration error 

#alternatively the above code can be written as 
j=iter(mytestScores)
while True:
    try:
        e=next(j)
    except StopIteration:
        break
    print(j)


#custom iterator demo 

import random 

class MyRandomIterator:
    """My Custom Random Iterator"""

    def __init__(self,*elements):
        self._elements=list(elements)

    
    def __iter__(self):
        random.shuffle(self._elements)
        self._cursor=0
        return self 

    def __next__(self):
        if self._cursor >=len(self._elements):
            raise StopIteration()
        e=self._elements[self._cursor]
        self._cursor+=1
        return e 


if __name__=="__main__":
    i=MyRandomIterator(232,332,82828) 
    for e in i:
        print(e)


