"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

#unpacking iterator 
# when the right hand side of an assignment consists of multiple values, you may get a list or a tuple. 
mylist = 'milk','curd','cheese','eggs','butter','jam','cereal'
l1,l2,l3,l4,l5,l6,l7 = mylist 
print(l1,l2,l3,l4,l5,l6,l7)

#unpacking nested iterators 
#iterators that consist of iterators can be unpacked in one go! 
myitems=("pen","pencil"), "razor","shaving cream","watch","laptop bag"
(a1,a2),a3,a4,a5,a6 = myitems 
print(a1,a2,a3,a4,a5,a6)


#unpacking an iterator with an unknown length using 
#using rest operator variable 
trialSuccess = 23,29,94,48,67,89,93,78,48,29,34,91,71,92
t1, *rest, t2 = trialSuccess
print(t1,rest,t2)



#unpacking a dictionary 
ani_class={
    "cockroach":"insect",
    "whale":"mammal",
    "snake":"reptile",
    "ant":"insect"

}

a1,a2,a3,a4 = ani_class 
print(a1,a2,a3,a4)

(k1,v1),(k2,v2),(k3,v3),(k4,v4)=ani_class.items()
print(k1,v1)
print(k2,v2)
print(k3,v3)
print(k4,v4)

 


