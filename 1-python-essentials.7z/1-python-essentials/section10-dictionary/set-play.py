"""
Copyright 2013-14 Syed Awase Khirni Territorial Prescience Research India Pvt Ltd.
www.territorialprescience.com 
www.truestate.com 
+91.9035433124
"""

# creating an empty set
mysetting = set()
# setval
setval = set([1231, 13223, 12313, 123412])
print(setval)

# iteration
for n in setval:
    print(n)

# adding an element to the set
setval.add(723626)



# adding multiple elements to the set
setval.update([128712, 28272])
print(setval)

#removing an element from the set 
setval.remove(723626)
print(setval)

# removing an element from the set
setval.pop()
print(setval)

# intersection of two sets
first_sel = set(['ram', 'krishna', 'syed', 'abraham'])
second_sel = set(['syed', 'abraham', 'joe', 'john'])

intersector = first_sel & second_sel
print(intersector)

# union of two sets
uninor = first_sel | second_sel
print(uninor)

# compute the length of a set
print(len(uninor))

# difference between two sets
differ = first_sel - second_sel
print(differ)
# symmetric difference
symdifer = first_sel ^ second_sel
print(symdifer)

# is super set or sub set
issubset = first_sel <= second_sel
print(issubset)
issuperset = first_sel >= second_sel
print(issuperset)

# find the maximum and minimum value of set
print(max(setval))
print(min(setval))

# clearing a set
setval.clear()


# frozen sets
# frozen sets are sets that cannot contina mutable objects
countries = ["Italy", "Germany", "Spain", "USA"]
mfs = frozenset(countries)
# error will be thrown for add method
# mfs.add("Switzerland")


#standard mathematical operations of set theory supported by python are 
mammals ={'Human','Whale','Dog','Cat'}
pets = {'Dog',"Cat","Goldfish","Parrot","Rabbit"}

#s1.union(s2) or s1 |s2 
myunion=mammals.union(pets)
#alternatively mammals | pets
print(myunion) 

#s1.intersection(s2) or s1&s2
myinter = mammals&pets 
print(myinter)
#alternatively myinter = mammals.intersection(pets)

#s1.difference(s2) or s1-s2 
mydiff = mammals-pets 
print(mydiff)


#s1.issubset(s2) or s1<s2
print(mammals < pets)

# s1.issuperset(s2) or s1>s2 
print(mammals > pets)


