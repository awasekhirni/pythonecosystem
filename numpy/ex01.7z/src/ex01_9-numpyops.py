##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 
import numpy as np 
import matplotlib.pyplot as plt 


#3d matrix multiplication 
np.random.seed(42)
One=np.random.randint(0,10, size=[3,3,2])
Two=np.random.randint(0,10, size=[3,2,4])
three=np.random.randint(10,20, size=[3,2])

print("three dimnesion matrix multiplication:", One, Two, One.shape, Two.shape)
Outthere=np.matmul(One,Two)
print("matrix multiplication:", Outthere)
#masked array.mean() = returns the average of the masked array elements along given axis 
# ensure that the input array size and mask size are the same.
myinputarray=np.ma.masked_array(three, mask=[[1,0],[1,0],[0,0]])
print("Masked_array is:", myinputarray)


#basic stats 
dsOne=[32, 36, 46, 47, 56, 69, 75, 79, 79, 88, 89, 91, 92, 93, 96, 97,  
        101, 105, 112, 116] 
#first quartile(Q1)
q1=np.median(dsOne[:10])
#third quartile(Q2)
q3=np.median(dsOne[10:])
#interquartile range (IQR)
IQR=q3-q1 
print("interquartile range:", IQR)
#using numpy.percentile
pq1=np.percentile(dsOne,25, interpolation='midpoint')
pq3=np.percentile(dsOne,75,interpolation='midpoint')
#interquartile range using percentile 
piqr=pq3-pq1 
print("interquartile range using percentile:", piqr)
#using median to compute interquartile 
mq1=np.median(dsOne[:10])
mq3=np.median(dsOne[10:])
#interquartile range using median 
miqr =mq3-mq1 
#compute the quartile deviation 
print("quartile deviation using median is:", miqr/2)

#string operations in numpy 
stingray=np.array(['Syed','Awase','Ameese','Sadath','Azeez','Rayyan','Rameez','Raqib','Rahim','Mohammad','Muneer','Mobin','Mohsin','Mauruf','Majid','Haris','Haneef','Haleema','Hafeef','Hameem','Haneef','Owaisi','Osama','Rizwan','Rafi'])
outray=np.char.rstrip(stingray)
print("character stripping:", outray)


#soring an array 
myarray= np.array([
    [33, 37, 1],
    [107, 13, 22],
    [51, 64, 7]
])

print("sorting the whole array:", np.sort(myarray,axis=None))
#sorting along each row 
print("sorting along each row:", np.sort(myarray,axis=1))
#sorting along each column 
print("sorting along each column:", np.sort(myarray,axis=0))

#reversing an array 
#numpy.flipud() 
print("reversed array:",np.flipud(myarray))

#eye matrix => used to create an identity matrix which can be very useful 
# to perform a variety of operations in linear algebra 
myidentitymat=np.eye(4)
print("myidentity matrix:", myidentitymat)

#gradient - a vector that contains the partial derivatives of all variables
#numpy.gradient(f, *varargs, axis=None, edge_order=1)
garry=np.array([23,27,57,28,78,98,102,89,112], dtype=float)
print("firstorder differences gradient is:",np.gradient(garry))
garryone= np.gradient(garry)
print("second order differences gradient is:", np.gradient(garry,garryone))



# sine wave using the array of elements 
sonar=np.array([0,np.pi/2,np.pi/3,np.pi/4,np.pi/5,np.pi])
print("sine wave values:",np.sin(sonar))
#generating a sinewave 
xs=np.linspace(-np.pi,np.pi,10)
ys=np.sin(xs)
plt.plot(xs,ys)
plt.xlabel("Angle in radians")
plt.ylabel("sin(x)")
plt.axis('tight')
plt.show()

#correlation 
np.random.seed(100)
xc=np.random.randint(0,100,500)
yc=xc+np.random.randint(0,50,500)
corry=np.corrcoef(xc,yc)
print("correlation:", corry)

#logspace demo 
log_array = np.logspace(start=2,stop=3,num=5,base=2)
print("logspace demo:",log_array)

#moving average 
def moving_average(a, n=3):
    #cummulative sum 
    result=np.cumsum(a,dtype=float)
    result[n:]=result[n:]-result[:-n]
    return result[n-1:]/n 

markr=np.empty(20,dtype=float)
print("moving average is:",moving_average(markr, n=3))

