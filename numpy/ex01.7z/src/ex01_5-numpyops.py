##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 

import numpy as np 

#isscalar() - alogical function that returns true if the type of input number is scalar 
ahad=[127,328,384,18,129,182]
print("checks if it is scalar:",np.isscalar(ahad))
print("another check is scalar:", np.isscalar(1872))
#amin function returns minimum of an array or minimum along axis 
#numpy.amin(arr,axis=None,out=None,keepdims=<class numpy._globals._NoValue>)
dartscores=np.random.randn(8)
print(dartscores)
print("fetch the minium value of the array:", np.amin(dartscores))
doubledart=np.arange(362,400,2.75).reshape(2,7)
print("fetch the minimum value of the arayy",np.amin(doubledart, axis=1))

#checking negative infinity 
#np.isneginf() 
print("check negative infinity:",np.isneginf(1))
print("check neg infinity:", np.isneginf(0))
print("nan-check- neginfinity:",np.isneginf(np.nan))
print("check inf:", np.isneginf(np.inf))
print("check ninf:", np.isneginf(np.NINF))

#rounding the elements of an array to the nearest integer
#np.rint() 
print("rounding the values of an array to the nearest integer:", np.rint(doubledart))

#insert() inserts values along the mentioned axies before the given indices 
#numpy.insert(array, object, values, axis=None)
adsfreq=np.arange(18).reshape(3,6)
print("fetch the shape of the array:", adsfreq.shape)
newads=np.insert(adsfreq,1,9,axis=1)
print(newads.shape)

#bincount() = an array of +ve integers the numpy.bincount() method counts the occurency of each element
#numpy.bincount(arr, weights=None,min_len=0)
zonaldata=[12,28,38,29,20,33,49,21,40, 21, 12,28,38,45]
mybin=np.bincount(zonaldata)
print("size of bin:", len(mybin))

#numpy delete() = returns a new array with the deletion of sub-arrays along the mentioned axis
#numpy.delete(array, object,axis=None) 
streetticks=np.arange(5)
print("shape of the array:", streetticks.shape)
delslot=3 
newslot=np.delete(streetticks,delslot)
print("post delete array data:", newslot)

#iscomplex()= function tests element-wise whether it is acomplex number or not and returns the results as boolean array 
#numpy.iscomplex(array)
print("check if it is complex:", np.iscomplex([23+7j, 13+8j]))
cookiearray=np.arange(20).reshape(4,5)
print("check if the array is complex:", np.iscomplex(cookiearray))

#np.not_equal() checks whether two elements are equal or not 
#numpy.not_equal(x1,x2[,out])
z_arr=np.array([3+4j,23, 1.25])
y_arr=np.array([13, 23, 8.67])
print("compare if both the arrays are equal:", np.not_equal(z_arr, y_arr))

#np.isposinf() => tests whether it is positive infinity or not and returns the result as a boolean array
#np.isposinf(array,y=None)
print("check if positive infinity:", np.isposinf(1))
print("check if pos inifinity:",np.isposinf(0))
print("check if nan is pos inifinity:", np.isposinf(np.nan))
print("check if pos inf", np.isposinf(np.inf))
print("check if pos inf:",np.isposinf(np.NINF))

#numpy.equal logical function checks for arr1== arr2 element-wise
cdrval=np.equal([1.25,2.25],[1.25,6.35])
print("equality check:", cdrval)
print("another equality check:", np.equal(z_arr, y_arr))

#less_equal check 
le_val=np.less_equal([1.25,2.25],[1.25,6.35])
print("less than or equal check:", le_val)

print("comparison:", np.less(z_arr, y_arr))

#np.append() => appends values along the mentioned axis at the end of the array 
#np.append(array, values, axis=None)
gr_val=np.arange(6)
pr_val=np.arange(8,12)
print("shape of the first variable is:", gr_val.shape)
print("shape of the second variable is:", pr_val.shape)
nova_val=np.append(gr_val,pr_val )
print("shape of the union is:", nova_val.shape, nova_val)
#two dimensional array 
tr_val=np.arange(8).reshape(2,4)
hr_val=np.arange(8,16).reshape(2,4)
zeva=np.append(tr_val, hr_val)
reva= np.append(tr_val,hr_val, axis=0)
jeva=np.append(tr_val, hr_val, axis=1)
print("2d array appending ops:", zeva)
print("appending by axis-0:", reva)
print("appending by axis-1:",jeva)


#np.around() => it helps users to evenly round array elements to the given number of decimals 
#np.around(arr, decimals=0, out=None)
stockprices=[0.575,0.75,0.85,1.025,1.25,1.40,1.50,1.60,1.75,1.90,2.0,2.1,2.25,2.40,2.50]
print("roundoff to the nearest integer:", np.around(stockprices))
print("roundoff to the nearest decimal", np.around(stockprices, decimals=1))


#flip() reverses the order of array elements along the specified axis, preserving the shape of the array 
#numpy.flip(array,axis)
ppl= np.random.randint(16,size=(4,4))
print("my randomly generated array:",ppl)
flippy=np.flip(ppl,0)
print("post-flipping array:", flippy)

