##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 
import random 
import numpy_financial as npf
import numpy as np 
#pip install numpy-financial

#numpy.degrees() and rad2deg() in python 
# functiont hat helps users to convert angles from radians to degrees
beerfull=np.empty([2,2],dtype=int)
print("two dimensional array:", beerfull)
print("convert angles from deg  to radians:", np.degrees(beerfull))
print("convert angles from radians to degrees:", np.rad2deg(beerfull))

#numpy.full_like() = returns a new array with the same shape and type as a given array
#numpy.full_like(a, fill_value, dtype=None, order='K', subok=True)
jarr=np.arange(8,dtype=int).reshape(2,4)
# create a new array of the same shape with a new value 
print("new array like:", np.full_like(jarr, 12))

#numpy.cos()=> helps user to calculate trigonometric cosine for all x 
print("cosine operations on 2dimensional array:", np.cos(jarr))


#numpy.diag() => extracts and constructs a diagonal array 
marr= np.empty([3,3],dtype=int)
print("original array:", marr)
print("fetching the diagonal values of an array:", np.diag(marr))

#modified code in 2020
#computing net present values 
cpv=[128,3874,9129,-100]
onerate=0.78
tworate=0.63
threerate=0.34 
print("net present values for rate1 is:", npf.npv(onerate, cpv))
print("net present values for rate2 is:", npf.npv(tworate,cpv))
print("net present values for rate3 is:", npf.npv(threerate,cpv))


#computing future values 
#numpy.fv(rate, nper, pmt, pv, when ='end')
# compute future value of 5000 investment now with an additional monthly saving of 2000
# assuming the current rbi rate of interest 11% 
frate=11/12
np=10*12
pmt=-5000 
pv=-2000 
futuresaving= npf.fv(frate, np, pmt, pv)
print("future savings is:", futuresaving)

#np.identity()- returns a identity matrix ie a square matrix with ones on the main diagonal
import numpy as np 
hiz= np.identity(3)
print("identity matrix", hiz)
#numpy eyetool return a 2d array with 1's as a diagonal and 0's elsewhere
hist=np.eye(2,dtype=float)
hist2=np.eye(4,3,k=1)
print("2d array with 1s as diagonal:", hist)
print("2d array with 1s as diagonal:", hist2)

#roll() array elements along the specified axies
# the elements of the input array are being shifted.
#if an element is being rolled first to last position, it is rolled back to first-position
mistyray=np.arange(12).reshape(3,4)
print("original array", mistyray)
print("rolling with 1 shift operation:", np.roll(mistyray,1))
print("rolling with 5 shift operations:", np.roll(mistyray,5))
print("rolling with 5 shift with 0 axis:", np.roll(mistyray,2,axis=0))

#np.log()= to calculate the natural logarithm of x where x belongs to all the input array elements
print("logirithmic value:",np.log(mistyray))
#np.log1p()- natural logarithmic value of x+1 
# log1p is reverse of exp(x)-1
print("natural logarithmic value:", np.log1p(mistyray))
#numpy.log10()- base 10 logarithmic of x 
print("base 10 logarithmic of value:", np.log10(mistyray))

# numpy.power() - Array elemnt from first array is raised to the power of the element from second element
# both arrays must have the same shape and each element in arr1 must be raised to corresponding +v value from array2
#negative integers are not allowed.
#inputarrays are 
i1=[3,4,5,6,7,8,9]
i2=[3,4,5,6,7,8,9]
outpwr=np.power(i1,i2)
print("power operations:", outpwr)

#place() returns the modified array, which was given at the time of input with added values according to the mask. 
miray=np.arange(12).reshape(3,4)
print("original array:",miray)
prayop=np.place(miray, miray > 5, [10, 15, 25,35,45,55])
print("display the modified array with the new values:",prayop)

#transpose of a matrix 
mydata =[[23,34],[46,45],[26,29]]
for row in mydata:
    print(row)
result=[[mydata[j][i] for j in range(len(mydata))] for i in range(len(mydata[0]))] 
print("the transpose operation is done here:")
for row in result:
    print(row)

#alternatively we can do usign transpose function 
tadipar=np.transpose(mydata)
print("mydata transpose to tadipar:", tadipar)

