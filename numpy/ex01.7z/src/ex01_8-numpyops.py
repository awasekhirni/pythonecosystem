##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 
import numpy as np 

#squeeze function- used when we want to remove single-dimensional entries from the shape of an array
mijazia=np.array([[[36, 72, 82], [17, 67, 91]]]) 
print("the current shape of the array is:", mijazia.shape)
print("the shape after squeze is:",np.squeeze(mijazia))


#input dataset
datalist=[23,475,-1,384,283,5.5,17.5,19.5,28,47,29]
#convert the list into numpy array 
arrlist=np.array(datalist)
#compute and print various statistics 
print("Mean:", arrlist.mean())
print("Median:", np.median(arrlist))
print("compute the range(max-min):", np.ptp(arrlist))
print("compute the std.dev:", arrlist.std())
print("80th percentile:", np.percentile(arrlist,80))
print('0.2-quantile:', np.quantile(arrlist,0.2))

#matrix manipulation in Python 
xarr=np.empty([2,2],dtype=int)
yarr=np.empty([2,2],dtype=int) 
print("original xarr and yarr", xarr, yarr)
#print =>addition operation
print("addition of two matrices:", np.add(xarr,yarr))
#print=> subtraction operation 
print("subtraction of two matrices:", np.subtract(xarr, yarr))
# print=> division operation 
print("division of two matrices:", np.divide(xarr,yarr))
#multiplication operation 
print("multiplication of two matrices:", np.multiply(xarr, yarr))
# dot operation to multiply 
print("product of matrices:", np.dot(xarr, yarr))
#transpose operation 
print("transpose:", xarr.T)

#indexing using index arrays 
mojoe=np.arange(12,1, -2)
print("mojoe:", mojoe)
ixjoe=mojoe[np.array([3,1,2])]
print("elements at the indices are :", ixjoe)
#another array 
mariojumps=np.empty(20,dtype="int")
print("mariojumps:",mariojumps)
#basic slicing and indexing
#mariojumps[start:stop:step]
print("index values mariojumps[-12:15:1]", mariojumps[-12:15:1])

print("basic indexing mariojumps[...,1]:", mariojumps[...,1])

#boolean indexing 
print("boolean function mariojump[mariojump<2050]", mariojumps[mariojumps<2050])
#conditional indexing 
condi=mariojumps.sum(-1)
print(condi)
print("conditional indexing mariojumps[condi%20<=0]:",mariojumps[condi%20<=0])



#extract unique values from list 

def fetchunique(list1):
    #initialize a null list 
    myuniquelist=[]
    #traversing the list for all the elements 
    for x in list1:
        #check if exists in unique_list or not 
        if x not in myuniquelist:
            myuniquelist.append(x)
    #printing the unique list 
    for y in myuniquelist:
        print(y)


#input list with duplicates 
lister=[11,21,31,41,41,51,11,12,21,13,34,11,21,31,41,51]
print("extract only the unique values:", fetchunique(lister))
#alternatively using np.unique()
print("using unique function:", np.unique(lister))
#using set to extract unique values 
print("using set:", set(lister))
#using collections counter 
from collections import Counter
print("using collections counter:", *Counter(lister))

#random sampling integer 
dsone=np.random.randint(low=0, high=20, size=10)
dstwo=np.random.randint(low=46, high=3778, size=(3,4))
dsthree=np.random.randint(388,2389,(2,3,4))
print("original_1d:",dsone)
print("original_2d:",dstwo)
print("original_3d:",dsthree)

#converting a dictionary to numpy array 
mywords ={1:'hello',2:'you',3:'fool',4:'i',5:'love',6:'come',7:'enjoy',8:'the',9:'joyride'}

#convert the dictionary
repurp=mywords.items()
#converting the dictionary object to list 
wordlist=list(repurp)
#convert the list to an array
nymwordlist=np.array(wordlist)
print("converted dictionary to numpyarray:", nymwordlist)

#vstack()=> used to stack the sequence of input arrays vertically to make a single array
simone = np.array([23,38,47,76])
dimone=np.array([34,57,68,29])
#stacking operations 
ustack=np.array((simone,dimone))
print("output vertically stacked array:", ustack)

#sign() = used to indicate the sign of a number element-wise in an array.
print("visualize sign of each element:",np.sign(dstwo))


#linear algebra 
larry=np.empty([4,4],dtype=int)
#rank of a matrix 
print("rank of a matrix is:", np.linalg.matrix_rank(larry))
#trace of a matrix 
print("trace of a matrix is:", np.trace(larry))
#determinant of a matrix 
print("determination of a matrix is:", np.linalg.det(larry))
#inverse of matrix
print("Inverse of a matrix:", np.linalg.inv(larry))
#matrix raised to the power of 4
print("matrix raised to the power of 4", np.linalg.matrix_power(larry, 4))
#compute the eigen value 
#real symmetric matrix 
lacros=np.array([[7,-2j],[3j,8]])
m,n=np.linalg.eigh(lacros)
print("Eigen value of m is:", m)
print("Eigen vlaue of n is:", n)
# eig()- used to compute the eigen values and the right eigenvectors of a square array 
#compute an eigen value using eig() function 
s,q=np.linalg.eig(larry)
print("Eigen value of s:", s)
print("Eigen value of q:", q)

#solving a linear matrix equation 
#numpy.linalg.solve() method 
meqn=np.array([[3,4],[7,9]])
ken=np.array([9,16])
print("solving of linear equaltion", np.linalg.solve(meqn,ken))
import matplotlib.pyplot as plt
# least squar solution to a linear matrix equation. 
# x co-ordinates
x = np.arange(0, 9)
A = np.array([x, np.ones(9)])
 
# linearly generated sequence
y = [19, 20, 20.5, 21.5, 22, 23, 23, 25.5, 24]
# obtaining the parameters of regression line
w = np.linalg.lstsq(A.T, y)[0] 
 
# plotting the line
line = w[0]*x + w[1] # regression line
plt.plot(x, line, 'r-')
plt.plot(x, y, 'o')
plt.show()