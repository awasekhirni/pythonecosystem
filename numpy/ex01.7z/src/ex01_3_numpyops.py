##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com  
import numpy as np 

#apply_over_axes() => applies a function repeatedly over multiple axes in an array 
#numpy.apply_over_axes(func,array,axes)

#using a three dimensional array 
threeDarr=np.arange(16).reshape(2,2,4)
print("original array is:", threeDarr)

#applying pre-defined sum function over the axies of 3D array
print("\nfunc applying sum : \n ", np.apply_over_axes(np.sum, threeDarr, [1, 1, 0]))
print("\nfunc applying min function : \n ", np.apply_over_axes(np.min, threeDarr, [1, 1, 0]))
print("\nfunc max : \n ", np.apply_over_axes(np.max, threeDarr, [1, 1, 0]))

#two dimensional array 
twodim=np.arange(23,70,3).reshape(4,4)
print("a two dimensional array:", twodim)
#applying pre-defined sum function over the axies of 2D array
print("\nfunc applying sum : \n ", np.apply_over_axes(np.sum, twodim, [1, 1, 0]))
print("\nfunc applying min function : \n ", np.apply_over_axes(np.min, twodim, [1, 1, 0]))
print("\nfunc max : \n ", np.apply_over_axes(np.max, twodim, [1, 1, 0]))


#tile() => constructs a new array by repeating array a specific number of times 
#numpy.tile(arr,repetitions)
tellertile=np.arange(1,10,2.5)
loopy=3
print("repeated tiles:",np.tile(tellertile,loopy))

#true_divide()=> array element from the first array is divided by the elements from second array.
#element wise division 
#both array1 and array2 must have same shape. 
# //floor division
# /true division 
# np.true_divide(arr1,arr2,/, out=None, *, where=True, casting='same_kind', order='K',dtype=None, ufunc'true_divide')

#inputarrays 
ikrarone=[6,11,23,45,56,27]
ikrartwo=[11,27,56,43,67,23]
outkar=np.true_divide(ikrarone,ikrartwo)
#using a single divisor 
sinkar = np.true_divide(ikrarone,7)
print("outputarray:",outkar)
print("using divisor:",sinkar)
floarout=np.floor_divide(ikrarone,ikrartwo)
print("floor division:",floarout)

#argmin => returns indices of the minimum element of the array 
#numpy.argmin(array,axis=None,out=None)
argxv=np.random.randint(8) 
print("argmin, indices of min elemnet:", np.argmin(argxv,axis=0))
tora=np.random.randint(16,size=(4,4))
print("argmin, indices of min element:", np.argmin(tora,axis=0))

#numpy.reshape() = function shapes an array without changing data of array 
#numpy.reshape(array,shape, order='C')

myrandom=np.arange(6).reshape(2,3)
myrez=np.arange(6).reshape(3,2)
print("reshape demo1:",myrandom)
print("reshape demo2:",myrez)

#numpy().random.rand() = creates an array of specified shape and fills it with random values 
#numpy.random.rand(a1,a2,a3,...an)
mirro=np.random.rand(6)
print("randomly generated values:",mirro)
pirro=np.random.rand(4,5)
print("randomly generated array values:", pirro)
#three dimensional array 
tirro=np.random.rand(4,5,6)
print("randomly generated 3 dimensional array:", tirro)

#argmax- returns indices of the max element of the array in a particular axis 
#numpy.argmax(array, axis=None,out=None) 
print("max element:", np.argmax(pirro,axis=0))

#ravel() = returns contiguous flattened array (1D array with all the input elements with the sametype as it)
#numpy.ravel(array, order='C')
contiguousval=np.arange(16).reshape(4,4)
print("original data:",contiguousval)
print("regeneration as a flattened array:",contiguousval.ravel())
#flattening array without using ravel 
print("flatenning array using reshape operation:", contiguousval.reshape(-1))

#preserving the order and reshaping 
coval=np.arange(12).reshape(2,3,2).swapaxes(1,2)
print(coval)
print("flattening coval:", coval.ravel(order='K'))

#random.randn() => create an array of specified shapes and fills it with random values as per the standard normal distribution 
#numpy.random.randn(d0,d1,d2,d3,....,dn)
colorvalues=np.random.randn(16)
print("one dimensional array filled with random values:\n",colorvalues)
twodimvalues=np.random.randn(3,4)
print("two dimensional array filled with random values:\n", twodimvalues)
threedimvalues= np.random.randn(2,3,4)
print("three dimensional array filled with random values:\n", threedimvalues)

