##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 
import numpy as np 
import matplotlib.pyplot as plt 
#numpy.nanargmin()=> returns the indices of the min element of the array in a particular axis ignoring NaNs
#numpy.nanargmin(array, axis=None)
#one dimensional array 
awal=[np.nan,112,373,289,100]
print("returingin indicies of the min elements by ignoring nan:", awal)
duwal=np.array([[np.nan,46,467],[28,928,102]])
print("returning indices of the min elmeent by ignoring nan:",duwal)



#numpy.isinf() => tests element-wise whether it is +ve or -ve infinity or not 
# returns boolean array 
#numpy.isinf(array, [,out])

print("finite check:", np.isinf(1276))
print("finite check2:",np.isinf(0))
#not a number check 
print("non a number check:", np.isinf(np.nan))
print("infinity check:", np.isinf(np.inf))
print("ninfinity check:", np.isinf(np.NINF))

#checking array elements 2d
sally= np.arange(8).reshape(2,4)
print("infinity check for a two dimensional array:", np.isinf(sally))

#numpy.ndarray.flat()= used to flattend n-dimensional arrays into 1 dimensional 
#numpy.ndarray.flat()
eik=np.arange(16).reshape(4,4)
print("one dimensional iterator over a range of indices:",eik.flat[3:9])
#flatenning the whole array as a one dimensional array 
print("one dimensional representation:", eik.flat[0:16])
#assign a range of indices with a single value 
eik.flat[2:8]=227
eik.flat[8:12]=253
print("post assignment operation:", eik)

#flatitier iterator is returned by x.flat for any array x
# it allow iteration over N-dimensional arrays, either in a for-loop or by calling its next method 
dosara= np.arange(16).reshape(2,2,4)
print(dosara)
print("flatening the n-dimensional array:", dosara.flat[0:16])
print("fetching the type of the array:",type(dosara.flat))
#iterating over to print each element using for loop 
for i in dosara.flat:
    print(i ,"\n", end= '')



#isrealobj(array) logical function helps to check if the array has no complex data type or array has a complex number 
# even if the imaginary part is equal to zero, it is not considered to be a real object 
print("isreal check:", np.isrealobj(eik))
#generating a complex data type array 
cafun = np.arange(16).reshape(4,4).dtype=complex 
print("2 dimensional complex array:", cafun)
print("2 dimensional complex array:", np.isrealobj(cafun))

# amax() = returns the maximum of an array or maximum along an axis if mentioned
# np.max(arr,axis=None, out=None, keepdims=<class numpy._globals.NoValue>)

wahid=np.arange(8)
print("return the max value element:", np.amax(wahid))

#expm1() => mathematical function helps users to calculate exponential of all the elements subtracting 1 from all the input array elements 
#np.expm1(array, out=None, where=True, casting="same_kind", order="K", dtype=None)

pizzasizes=[6,12,14,18,22]
expo_pizza=np.exp(pizzasizes)
print("Exponential value of the array elements:", expo_pizza)
alt_expo=np.expm1(pizzasizes)
print("Expoonetal values of array elements -1:", alt_expo)

#graphical representation of expm1 function 
basketscores=[1,1.5,2,2.5,3,3.5,4,4.5,5]
outbasket=np.expm1(basketscores)
yax=[1,1.5,2,2.5,3,3.5,4,4.5,5]

plt.plot(basketscores, yax, color = 'blue', marker = "*") 
  
# red for numpy.expm1() 
plt.plot(outbasket, yax, color = 'red', marker = "o") 
plt.title("numpy.expm1()") 
plt.xlabel("X") 
plt.ylabel("Y") 
plt.show() 




