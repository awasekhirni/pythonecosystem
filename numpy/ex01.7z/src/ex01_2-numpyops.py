##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 
import numpy as np 

#vector product of two variables 
ein_vector= 4+9j
zwei_vector=7+3j 

compute_vec=np.vdot(ein_vector,zwei_vector)
print("vector product of two variables:", compute_vec)

#vector product of arrays 
#single dimension array 
vec_x=np.array([[12,24],[36,72]])
vec_y=np.array([[11,22],[33,66]])

prod_v=np.vdot(vec_x,vec_y)
print("vector product of a single dimensional array:",prod_v)


#numpy.take() => returns elements from array along the mentioned axis and indices. 
#np.take(array, indices, axis=None, out=None, mode='raise')
tam_arr=[[35,45,65,75,85,95],[11,22,33,44,55,66,77]]
req_indices=[0 ]
print("taking the indices of the array:", np.take(tam_arr,req_indices))
print("taking the indices along the axis:",np.take(tam_arr,req_indices, axis=0))

#numpy.extract() => returns elements of input_array if they satisfy the condition
#numpy.extract(condition,array)
color_val=np.arange(10).reshape(5,2)
print("original value:",color_val)
mycond1=np.mod(color_val,4)!=0 
print("first conditional play:",mycond1)
#extracting the elements that satisfy the condition 
print("elements that satisfy the condition are:", np.extract(mycond1,color_val))

mycond2=color_val *3-2.5 >=4
#extracting the eements that satisfy the condition 
print("elements that satisfy the second condition are:", np.extract(mycond2,color_val))

#truncate np.trunc() - returns the truncated value of the elements of an array 
#numpy.trunc(x[,out])
trips_bangalore=[11.7,18.3,23.1,26.5,27.8,29.2,17.9]
roundoff=np.trunc(trips_bangalore)
print("truncated values are:", roundoff)

#put operation => replaces specific elements of an array with given values of another array 
#numpy.put(array, indices, p_array, mode='raise')
random_val = np.arange(5) 
np.put(random_val, [1, 3], [-37, -73])
print("new random values after modification:", random_val)
np.put(random_val,11,-97, mode='clip')
print("new random values after modification:", random_val)


#compress - returns the selected slices of an array along mentioned axies 
#numpy.compress(condition,array, axis=None, out=None)
myarr =np.arange(12).reshape(3,4)
print("original_array:",myarr)
compress_arr=np.compress([0,1],myarr, axis=0)
print("compressed array:",compress_arr)

#numpy.divide()=> array element from first array is divided by elements from second element.
#numpy.divide(arr1, arr2,out=None, where=True, casting='same_kind', order='K', dtype=None)
values_eins=[13,128,16,17,182]
values_zwei=[36,46,847,386,261]
out_divi=np.divide(values_eins,values_zwei)
print("output of division:",out_divi)

#apply_along_axis() = applys a required function to 1d slices of the given array
#numpy.apply_along_axis(1dfunc, axis,array, *args, **kwargs)

def inputargsfunction(inp1,inp2,inp3):
    print("input1:", inp1)
    print("input2:",inp2)
    print("input3:", inp3)


kwargs={"inp1": 127,"inp2":217,"inp3":712}
inputargsfunction(**kwargs)

def sumoftopbottomrows(inparray):
    return (inparray[0]+inparray[-1])


genvalues=np.array([[23,34,56],[23,11,33],[9,8,7]])
print("axis:0 addition:", np.apply_along_axis(sumoftopbottomrows,0,genvalues))
print("axis=1 addition:", np.apply_along_axis(sumoftopbottomrows,1,genvalues))

#np.rot90()= performs rotation of an array by 90 degrees in the placen
#np.rot90(array,k=1,axes=(0,1))
rotarr=np.arange(12).reshape(4,3)
print("rotating the array 3 times:", np.rot90(rotarr,3))
print("rotating the array once:", np.rot90(rotarr))
print("rotating twice:",np.rot90(rotarr,2))

#numpy.floor_divide()= array elements from the first array is divided by the elements from second array
#numpy.floor_divide(arr1,arr2, /, out=None, where=True, casting='same_kind', order='K',dtype=None)
flrone=[33,44,55,66,77,88,99]
flrtwo=[3,4,5,6,7,8,9]
outflr=np.floor_divide(flrone,flrtwo)
print("floor and divide output:",outflr)
print("alternative floor and divide using single divisor:", np.floor_divide(flrone,3))



