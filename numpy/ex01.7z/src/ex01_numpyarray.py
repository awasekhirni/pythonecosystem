##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 
#creating a numpy array 
import numpy as np 

#Creating a rank 1 Array in numpy 
myarray = np.array([23,45,67,28,18])
print("Array with Rank 1:\n", myarray)

#Creating a rank 2 Array in numpy 
secondarray = np.array([[11,22,33,44],
                        [55,66,77,88]])
print("Array with Rank 2: \n",secondarray)

#creating an array from tuple 
array2Tuple=np.array((23,34,56,78))
print("\n Converting a tuple to an array:\n",array2Tuple)

#access the array index 
sliced_array=secondarray[:2,::2]
print("Array with the first 2 rows and alternate column :\n", sliced_array)


#basic array operations on a single array 
calories_dimarr=np.array([[12,23,34,45], [90,80,70,60]])
ageweight_dimarr=np.array([[10,20,30,40],[24,56,89,93]])

#adding 10 calories to each array
print("Adding 10 calories to every element:", calories_dimarr+10)
#subtracting 10% from each element
print("Weight reduction by 10 percentage:",ageweight_dimarr-0.1*ageweight_dimarr)
#sum of all array elements 
print("total calories for all age groups:", calories_dimarr.sum())
#adding two matrices
print("addition of two matrices:", calories_dimarr+ageweight_dimarr)


#data type identification 
computed_values=ageweight_dimarr-0.1*ageweight_dimarr
print("the data type of caolories array is:", calories_dimarr.dtype)
print("the datatype of computed values is:", computed_values.dtype)
#forced conversion 
nv=np.array([67,49,39,28], dtype=np.int64)
print(nv.dtype)

#mathematical operations on Datatype array 
summary_ar=np.add(calories_dimarr,ageweight_dimarr)
print(summary_ar)
#summation 
summ_val=np.sum(calories_dimarr)
print(summ_val)
#Square root of an array 
iamsquarewithyou = np.sqrt(calories_dimarr)
print(iamsquarewithyou)
#transpose of an array 
invertit=iamsquarewithyou.T 
print("upside down Transpose:",invertit)

#All() funtion tests whether all array elements along the mentioned axis
#evaluate to true 
print("boolean value with axis=NONE:",np.all([[True,False],[True,True]]))
print("boolean value with axis=NONE:",np.all([[True,False],[True,True]], axis=0))

#arange() - returns an array with evenly spaced elements as per the interval
iterations = np.arange(4).reshape(2,2)
print(iterations)
alternate_days=np.arange(0,100,2)
print(alternate_days)
only_days_ofmonth=np.arange(11,19)
print("days of month to visit farm house:",only_days_ofmonth)
#step wise increment again 
bar_index=np.arange(0,10,0.5)
print("the step wise bar_index:",bar_index)

#dot product of two vectors 
simple_multiply=np.dot(183,2774)
print(simple_multiply)

#single dimensional array 
sin_vec_a=23+5j
cos_vec_a=27+8j 
tan_vec=np.dot(sin_vec_a,cos_vec_a)
print(tan_vec)

#two dimensional array product 
two_sin_vec=np.array([[11,22],[55,66]])
two_cos_vec=np.array([[1,3],[11,19]])
two_tan=np.dot(two_sin_vec,two_cos_vec)
print(two_tan)


#numpy.place() - makes changes in the array according to the parameters
#numpy.place(array,mask,vals)
placevalues=np.arange(8).reshape(2,4)
print(placevalues)
#replacing with new values 
score_val = np.arange(12).reshape(2, 6) 
print("Original array : \n", score_val) 
   
# Putting new elements 
rescore = np.place(score_val, score_val > 5, [15, 25]) 
print("\nPutting up elements to array: \n", rescore) 
  

