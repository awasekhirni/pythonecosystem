##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 
import numpy as np 
import random 

#randomly selecting a symbol from a list 
stocksymbols=["infy","wipro","reddy","hdfc","icici","sycliq"]
random.choice(stocksymbols)
print("selection choice randomly:",random.choice(stocksymbols))
print("shuffling:",random.shuffle(stocksymbols), stocksymbols)

#isreal() check if the elment is real 
bse_stockprices= np.random.randint(16,size=(4,4))
nasdaq_stockprices=np.random.randint(16,size=(4,4))
print("check if is real", np.isreal(bse_stockprices))
print("check if greater:", np.greater(nasdaq_stockprices,bse_stockprices))
print("check if greater or equal:", np.greater_equal(nasdaq_stockprices,bse_stockprices))

#fliplr() = flip array entries in each column in left-right direction, shape preserved.
# returns a flipped array in left-right direction 
print("original stock price:",bse_stockprices)
print("flipped array:", np.fliplr(bse_stockprices))

#numpy.flipud()=> function flips the array enteries in each column in up-down direction 
print("flipped up-down array:", np.flipud(bse_stockprices))

#isfortran() = a logical functiont that checks whether array is fortran contiguous or not 
# O- C-contiguous, F-contigous, A-contiguous; optional 

myseqorder=np.array([[23,34,46],[36,82,89]],order='C')
mytwosec=np.array([[23,34,46],[36,82,89]],order='F')
mythresec=np.array([[23,34,46],[36,82,89]],order='A')
print("isfortran-order-C:", np.isfortran(myseqorder))
print("isfortran-order-F",np.isfortran(mytwosec))
print("isfortran-order-A",np.isfortran(mythresec))

#prod() returns the product of array elements over a given axis
#numpy.prod(a, axis=Non, dtype=None, out=None, keepdims=)
resultant=np.prod(bse_stockprices)
resultant_axis=np.prod(bse_stockprices,axis=1)
print("producct of an array is:", resultant)
print("product along an axis is:", resultant_axis)

#numpy.triu() => returns a copy of array with upper part of the triangle w.r.t K
print("the main diagonal elements are:", np.triu(bse_stockprices))
print("Above diagonal elements are:", np.triu(bse_stockprices,1))
print("main diagonal elements are:", np.triu(bse_stockprices,-1))
#tril => returns copy of array with lower part of the triangle w.r.t. k 
print("lower diagonal elements are:", np.tril(bse_stockprices))


#compute the square of each element in the array 
#np.square(arr,out=None, ufunc'square')
print("squares of the array:", np.square(bse_stockprices))
cn= 4+7j 
print("square of a complex number:", np.square(cn))
#compute the 2**x of all the elements in an array 
#numpy.exp2(array, out=None,where=True, casting='same_kind', order='K',dtype=None)
print("exponential squares:", np.exp2(bse_stockprices))

#compute cube root of x for all x being the array elements
#np.cbrt(arr,out=None, ufunc 'cbrt')
pricepoint=[123,189893,9437,-28894]
print("cuberoot is:", np.cbrt(pricepoint))
#np.tri(R, C=None,k=0,dtype='float') creates an array with 1 at and below the given diagonal and 0s elsewhere

print("tri with k=1:,", np.tri(2,3,1, dtype=float))
print("tri with main diagonal:", np.tri(3,5,0))
print("tri with k=-1", np.tri(3,5,-1))
#numpy.fix() - rounds the elements of the array to the nearest integer twowards zero 

#logical_or() => find out hte logical value of arr1 and arr2 
arr1 = [2137, 2823, True, 4673] 
arr2 = [6236, 2823, True, False] 
output_v=np.logical_or(arr1, arr2)
print("logical_or check:", output_v)
#logical_and()
print("logical_and check:", np.logical_and(arr1, arr2))
#logical_not()
print("logical_not check:", np.logical_not(arr1),np.logical_not(arr2))
#logical_xor()
print("logical xor check:", np.logical_xor(arr1,arr2))


#numpy.empty()=> returns a new array of given shape and type with random values 
# numpy.empty(shape, dtype=float, order='C') C- Contiguous or F-Contiguous
earfull=np.empty(2,dtype=int)
beerfull=np.empty([2,2],dtype=int)
cheerfull=np.empty([3,3])
print("empty numpy array", earfull)
print('empty numpy 2d array', beerfull)
print('empty numpy 2d array', cheerfull)
#numpy.empty_like() - returns a new array with same shape and type as a given array 
housefull= np.empty_like(cheerfull)
print("generating similar array with shape:", housefull)

#numpy.absolute() - helps users to calculate absolute value of each element 
# for a complex input a+ib the absolute value is sqrt(a**2+b**2)
print("absolute value of beerful is:", np.absolute(beerfull))
#absolute value of a complex no is 
eq= 7+13j 
print("absolute value of complex no is:", np.absolute(eq))


#numpy.zeros() => returns a new array of given shape and type with zeros 
#numpy.zeros(shape,dtype=None, order='C')
genzero=np.zeros(3, dtype=int)
genone=np.zeros([3,3],dtype=int)
gentwo=np.zeros([4,4,4])
fourgen=np.zeros((4,), dtype=[('x','float'),('y','int')])
print("one dimensional zero:", genzero)
print("two dimensional zero:", genone)
print("three dimensional zero", gentwo)
print("fourth generation:",fourgen)
#numpy.zeros_like() - returns an array of given shape and type as given array with zeros
print("like fourth generation:", np.zeros_like(fourgen))
#numpy.ceil() - return the ceil of the elements of array 
print("ceil operation on cheerful array:", np.ceil(cheerfull))


#numpy.floor()=> returns the floor of the elements of an array
myprices=[253.46,3837.56,2726.75,36.03,3847.67]
shopprices=[283.46,4837.56,3726.75,96.03,6847.67]
print("flooring the values of myprices:", np.floor(myprices))

#numpy.hypot() = calculate the hypotenue of the right angle triangle 
#numpy.exp2(arr1, arr2[,out])
print("hypotenuse of a one dimensional array:", np.hypot(myprices,shopprices))
#two dimensional arrays 
triangleone =np.random.rand(3,4)
triangletwo=np.random.rand(3,4)
print("compute the hypotenuse:", np.hypot(triangleone, triangletwo))

#numpy.ones() => returns a new array of given shape and type with ones
#single dimension array 
simday=np.ones(3, dtype=int)
twoday=np.ones([3,3], dtype=float)
threeday=np.ones([3,3,3])
print("one dimensional array of 1s :",simday)
print("two dimensional array of 1s:",twoday)
print("three dimensional array of 1s:",threeday)
