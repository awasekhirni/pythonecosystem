##copyright 2015 Awase Khirni Syed 
##awasekhirni@gmail.com www.tpri.com www.sycliq.com 
import numpy as np 

#normalization using numpy 
# transformation of a vector, obtained y performing certain mathematical operations on it

a=np.array([123,3478,3737,2827,1827])
ar_norm=np.linalg.norm(a)
print("normalization of the array:", ar_norm)
#two dimensional array 
twodim = np.arange(9)-4
new2d=twodim.reshape(3,3)
print("two dimensional array original is", new2d)
new2d_normal=np.linalg.norm(new2d,axis=0)
print("Coloumn wise normalization:",new2d_normal)
# threedimnesional array 
arr3d=np.arange(27).reshape(3,3,3)
print("three dimensional array is:", arr3d)
#normalization along axis 
xn_arr3d=np.linalg.norm(arr3d,axis=0)
print("normalization of 3d array along axis",xn_arr3d)

#shortest path demo using djikstra algorithm 
from numpy import inf
graphdata = {'A': {'C': 5, 'D': 1, 'E': 2}, 'B': {'H': 1, 'G': 3}, 'C': {'I': 2, 'D': 3, 'A': 5},
         'D': {'C': 3, 'A': 1, 'H': 2}, 'E': {'A': 2, 'F': 3},
         'F': {'E': 3, 'G': 1}, 'G': {'F': 1, 'B': 3, 'H': 2}, 'H': {'I': 2, 'D': 2, 'B': 1, 'G': 2},
         'I': {'C': 2, 'H': 2}}

costs = {'A': 0, 'B': inf, 'C': inf, 'D': inf, 'E': inf, 'F': inf, 'G': inf, 'H': inf, 'I': inf}

parents={}

#search function 
def search(source,target,graph,costs, parents):
    nextNode=source
    while nextNode != target:
        for neighbor in graph[nextNode]:
            if graph[nextNode][neighbor] + costs[nextNode] < costs[neighbor]:
                costs[neighbor] = graph[nextNode][neighbor] + costs[nextNode]
                parents[neighbor] = nextNode
            del graph[neighbor][nextNode]
        del costs[nextNode]
        nextNode = min(costs, key=costs.get)
    return parents


result = search('A', 'B', graphdata, costs, parents)


def backpedal(source, target, searchResult):
    node = target
    backpath = [target]
    path = []
    while node != source:
        backpath.append(searchResult[node])
        node = searchResult[node]
    for i in range(len(backpath)):
        path.append(backpath[-i - 1])
    return path

print('parent dictionary={}'.format(result))

print('longest path={}'.format(backpedal('A', 'B', result)))

# filling in missing dates in an irregular series of numpy dates 
mydates = np.arange(np.datetime64("2015-03-01"),np.datetime64('2015-04-30'),2)
print("original dates data:",mydates)
#filling missing dataes 
missing_dates=np.array([np.arange(date, (date+d)) for date, d in zip(mydates, np.diff(mydates))]).reshape(-1)
#adding the last day 
output_dates=np.hstack([missing_dates, mydates[-1]])
print("outputdates are:",output_dates)
